rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
fs <- list.files('TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
cancers <- sapply(strsplit(sapply(strsplit(fs,'-'),"[",2),"[.]"),"[",1)
Gene <- "RARRES2"
Expression <- lapply(cancers,function(x){
    load(paste0('TCGAbiolinks-EXP/TCGA-',x,'-GeneSymbol.Rdata'))
    exprSet <- data.frame(Expression = log2(as.numeric(exp_TPM[Gene,]+1)),
                          ID = substr(colnames(exp_TPM),1,12),
                          SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
						  SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3),
                          Cancer = x)
    print(x)
    print(dim(exp_TPM))
    print(table(exprSet$SampleType))
    return(exprSet)
})
exprSet <- do.call(rbind,Expression)
exprSet$Group <- ifelse(exprSet$SampleType < 10,"Tumor","Normal")
exprSet$Group2 <- paste0(exprSet$Cancer,"-",exprSet$Group)
head(exprSet)
  # Expression           ID SampleType SampleType2 Cancer Group    Group2
# 1   3.705724 TCGA-OR-A5LD         01           A    ACC Tumor ACC-Tumor
# 2   9.929719 TCGA-OR-A5KO         01           A    ACC Tumor ACC-Tumor
# 3  11.719701 TCGA-OR-A5LA         01           A    ACC Tumor ACC-Tumor
# 4   6.281886 TCGA-OR-A5JW         01           A    ACC Tumor ACC-Tumor
# 5  11.200113 TCGA-PA-A5YG         01           A    ACC Tumor ACC-Tumor
# 6   9.221276 TCGA-OR-A5JD         01           A    ACC Tumor ACC-Tumor

table(exprSet$SampleType2)
table(exprSet$Group2,exprSet$SampleType2)
table(exprSet$SampleType)
  # 01   02   03   05   06   07   11 
# 9928   49  150   11  394    1  740 
##保留A：
exprSet <- exprSet[exprSet$SampleType2 %in% "A",]
##保留Primary/正常：
exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09","11"),]

table(exprSet$SampleType2)
##保留存在正常样本且数目大于3个的癌型：
exprSet <- exprSet[-which(exprSet$Group2 %in% names(which(table(exprSet$Group2) < 3))),]
Cancerlist <- sapply(strsplit(unique(exprSet$Group2)[grep("Normal",unique(exprSet$Group2))],"-"),"[",1)
exprSet <- exprSet[exprSet$Cancer %in% Cancerlist,]
exprSet$Cancer <- factor(exprSet$Cancer,levels = rev(unique(exprSet$Cancer)))
library(ggplot2)
exprSet$Group <- factor(exprSet$Group,levels = c("Normal","Tumor"))
theme <- theme_bw()+ 
         theme(axis.text = element_text(size = 20), 
               axis.title = element_text(size = 20), 
               #axis.line = element_line(size = 1),
               plot.title = element_text(hjust = 0.5,size =  20),
               #panel.grid = element_blank(), 
               legend.text = element_text(size = 20),
               legend.title = element_blank(),
               legend.position = "top")
range(exprSet$Expression)#0.114367 12.083151
p1 <- ggplot(exprSet,aes(x = Expression, y = Cancer,colour = Group)) + 
      #添加两端竖线
      # stat_boxplot(geom = "errorbar",size = 0.7,width = 0.75,position = position_dodge(0.9)) + 
      #boxplot本体
      # geom_boxplot(width = 0.75,position = position_dodge(0.9),size = 0.7,
                   # outlier.shape = NA,fill = "white",show.legend = FALSE) +
      scale_colour_manual(values = c("#0074b3","#ae202c")) +
      scale_x_continuous(expand = c(0,0),limits = c(0,13), 
                         breaks = seq(0,12,2),labels = seq(0,12,2))+
      labs(title = NULL, x = bquote("Relative Expression ("~Log[2]~" TPM)"),y = NULL) + 
      theme     
p1 <- p1 + guides(colour = guide_legend(override.aes = list(linewidth = 1.5)))
p1
##按照癌症分类添加背景：数量不是很多就不写循环了：
xmin <- 0
xmax <- 13
p2 <- p1 + annotate("rect", xmin = xmin, xmax = xmax, ymin = 1.5, ymax = 2.5, alpha = .3) +
           annotate("rect", xmin = xmin, xmax = xmax, ymin = 3.5, ymax = 4.5, alpha = .3) +
           annotate("rect", xmin = xmin, xmax = xmax, ymin = 5.5, ymax = 6.5, alpha = .3) +
           annotate("rect", xmin = xmin, xmax = xmax, ymin = 7.5, ymax = 8.5, alpha = .3) +
           annotate("rect", xmin = xmin, xmax = xmax, ymin = 9.5, ymax = 10.5, alpha = .3) +
           annotate("rect", xmin = xmin, xmax = xmax, ymin = 11.5, ymax = 12.5, alpha = .3) +
           annotate("rect", xmin = xmin, xmax = xmax, ymin = 13.5, ymax = 14.5, alpha = .3) +
           annotate("rect", xmin = xmin, xmax = xmax, ymin = 15.5, ymax = 16.5, alpha = .3) +
           annotate("rect", xmin = xmin, xmax = xmax, ymin = 17.5, ymax = 18.5, alpha = .3) +
           annotate("rect", xmin = xmin, xmax = xmax, ymin = 19.5, ymax = 20.5, alpha = .3)	  

p2 <- p2 + 
      #添加两端竖线
      stat_boxplot(geom = "errorbar",size = 0.7,width = 0.75,position = position_dodge(0.9)) + 
      #boxplot本体
      geom_boxplot(width = 0.75,position = position_dodge(0.9),size = 0.7,
                   outlier.shape = NA,fill = "white",show.legend = FALSE)
p2
library(tidyverse)
my_sum <- exprSet %>%
          group_by(Cancer,Group) %>%
          summarise(n = n(),
                    mean = mean(Expression), # 计算均值
                    sd = sd(Expression)) # 计算标准差
my_sum
FC <- my_sum$mean[seq(2,nrow(my_sum),by = 2)] - my_sum$mean[seq(1,nrow(my_sum),by = 2)]#Tumor-Normal
names(FC) <- unique(my_sum$Cancer)
FC

library(ggpubr)
Data_summary <- as.data.frame(compare_means(Expression~Group, exprSet, method = "wilcox.test", 
                              paired = FALSE,group.by = "Cancer"))    
rownames(Data_summary) <- Data_summary$Cancer
# p3 <- p2
# for (i in 1:length(unique(exprSet$Cancer))){ 
    # Pvalue <- Data_summary[unique(exprSet$Cancer)[i],"p"]
 # if(Pvalue < 0.00001){
     # Pvalue <- paste0("P = ",as.character(scales::scientific(Pvalue,2)))
 # }else{
     # Pvalue <- paste0("P = ",as.character(round(Pvalue,5)))
 # } 
 # p3 <- p3 + annotate("text",x = 6.5,y = i,label = Pvalue,size = 5,hjust = 0) 
# }
p3 <- p2
for (i in 1:length(unique(exprSet$Cancer))){ 
    Pvalue <- Data_summary[unique(exprSet$Cancer)[i],"p.signif"]
 if(Pvalue != "ns"){
     p3 <- p3 + annotate("text",x = 12,y = i,label = Pvalue,size = 10,hjust = 0.5)
 }
}
p3



###分成上调、下调、不显著三类：
Data_summary$Cancer <- factor(Data_summary$Cancer,levels = rev(unique(exprSet$Cancer)))
Data_summary$Group <- ifelse(FC[Data_summary$Cancer] < 0,"Down","Up")
Data_summary$Group[Data_summary$p >= 0.05] <- "Non-Sig"
Data_summary$Group <- factor(Data_summary$Group,levels = c("Up","Down","Non-Sig"))
###使用geom_tile绘制单行热图：去除所有横纵坐标轴
theme2 <- theme_void()+
          theme(panel.border = element_blank(),
                panel.grid = element_blank(),
                axis.text = element_blank(), 
                axis.title = element_blank(), 
                axis.ticks.y = element_blank(),
                legend.text = element_text(size = 20),
                legend.title = element_blank(),
                legend.position = "top")  
p4 <- ggplot(data = Data_summary,aes(x = 1,y = Cancer,fill = Group)) +
      geom_tile() +
      #scale_x_discrete(expand = c(0,0)) +
      scale_fill_manual(values = c("#ae202c","#0074b3","#b9bbbd")) + theme2
p4 
###拼图：
library(aplot)
p5 <- p3 %>% insert_right(p4,width = 0.04)

library(patchwork) 
pMerge <- (p3 + plot_spacer() + p4) + 
           plot_layout(width = c(1,-0.03,0.05),ncol = 3,guides = 'collect') & theme(legend.position = "top")
pMerge
pdf("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step1.TCGA-Pan-cancer.pdf",height = 10,width = 7.5)
pMerge
dev.off()	

####################火山图  
head(Data_summary)
head(my_sum)
FC <- my_sum$mean[seq(2,nrow(my_sum),by = 2)] - 
      my_sum$mean[seq(1,nrow(my_sum),by = 2)]#Tumor-Normal
names(FC) <- unique(my_sum$Cancer)
FC
sort(FC)
       # PCPG        CESC        UCEC        CHOL        LUSC        READ        BLCA 
# -6.30679101 -3.41519568 -2.12372984 -1.97342988 -1.59683548 -1.56819812 -1.53704486 
       # BRCA        LUAD        COAD        KICH        PRAD        THCA        PAAD 
# -1.43129677 -1.24391957 -0.98128444 -0.98046986 -0.91826894 -0.90169681 -0.34537432 
       # STAD        LIHC        ESCA        HNSC        KIRP        KIRC         GBM 
 # 0.02006629  0.13806770  0.19754860  0.64297064  0.91491029  1.40949184  1.44988939 
     # Cancer        .y. group1 group2            p   p.adj p.format p.signif   method   Group log2FoldChange
# BLCA   BLCA Expression Normal  Tumor 1.183208e-04 1.2e-03  0.00012      *** Wilcoxon    Down    -1.53704486
# BRCA   BRCA Expression Normal  Tumor 2.200055e-24 4.6e-23  < 2e-16     **** Wilcoxon    Down    -1.43129677
# CESC   CESC Expression Normal  Tumor 4.573478e-03 2.7e-02  0.00457       ** Wilcoxon    Down    -3.41519568
# CHOL   CHOL Expression Normal  Tumor 3.893188e-07 5.5e-06  3.9e-07     **** Wilcoxon    Down    -1.97342988
# COAD   COAD Expression Normal  Tumor 4.480439e-08 6.7e-07  4.5e-08     **** Wilcoxon    Down    -0.98128444
# ESCA   ESCA Expression Normal  Tumor 4.199036e-01 1.0e+00  0.41990       ns Wilcoxon Non-Sig     0.19754860
# GBM     GBM Expression Normal  Tumor 1.432321e-02 7.2e-02  0.01432        * Wilcoxon      Up     1.44988939
# HNSC   HNSC Expression Normal  Tumor 2.272994e-03 1.8e-02  0.00227       ** Wilcoxon      Up     0.64297064
# KICH   KICH Expression Normal  Tumor 9.727968e-02 3.9e-01  0.09728       ns Wilcoxon Non-Sig    -0.98046986
# KIRC   KIRC Expression Normal  Tumor 1.228760e-21 2.5e-20  < 2e-16     **** Wilcoxon      Up     1.40949184
# KIRP   KIRP Expression Normal  Tumor 3.252269e-06 4.2e-05  3.3e-06     **** Wilcoxon      Up     0.91491029
# LIHC   LIHC Expression Normal  Tumor 2.050323e-04 1.8e-03  0.00021      *** Wilcoxon      Up     0.13806770
# LUAD   LUAD Expression Normal  Tumor 2.264966e-17 4.1e-16  < 2e-16     **** Wilcoxon    Down    -1.24391957
# LUSC   LUSC Expression Normal  Tumor 3.137003e-21 6.0e-20  < 2e-16     **** Wilcoxon    Down    -1.59683548
# PAAD   PAAD Expression Normal  Tumor 5.550557e-01 1.0e+00  0.55506       ns Wilcoxon Non-Sig    -0.34537432
# PCPG   PCPG Expression Normal  Tumor 3.810458e-03 2.7e-02  0.00381       ** Wilcoxon    Down    -6.30679101
# PRAD   PRAD Expression Normal  Tumor 3.459568e-08 5.5e-07  3.5e-08     **** Wilcoxon    Down    -0.91826894
# READ   READ Expression Normal  Tumor 3.569872e-05 3.9e-04  3.6e-05     **** Wilcoxon    Down    -1.56819812
# STAD   STAD Expression Normal  Tumor 9.714907e-01 1.0e+00  0.97149       ns Wilcoxon Non-Sig     0.02006629
# THCA   THCA Expression Normal  Tumor 4.497198e-06 5.4e-05  4.5e-06     **** Wilcoxon    Down    -0.90169681
# UCEC   UCEC Expression Normal  Tumor 5.565228e-17 9.5e-16  < 2e-16     **** Wilcoxon    Down    -2.12372984

Data_summary$log2FoldChange <- FC[as.vector(Data_summary$Cancer)]
volcano <- ggplot(Data_summary, aes(x = log2FoldChange, y = -log10(p),color = Group)) +
           geom_point(alpha = 0.75, size = 8) +
           labs(x = bquote(~Log[2]~"(fold change)"), 
                y = bquote(~-Log[10]~italic("Adjust P-value")), 
                title = NULL) +
           scale_colour_manual(name = NULL, 
		                       values = c("#ae202c","#0074b3","#b9bbbd")) + 
           scale_x_continuous(expand = c(0,0.08),
		                      limits = c(-6.5,6.5),breaks = seq(-6,6,by = 1)) + 
           scale_y_continuous(expand = c(0,0.08),
		                      limits = c(-0.1,24),breaks = seq(0,24,by = 4)) + 
           geom_hline(yintercept = c(-log10(0.01)),size = 0.7,color = "black",lty = "dashed") + 
           geom_vline(xintercept = c(-1,1),size = 0.7,color = "black",lty = "dashed") + 
		   theme_bw()+ 
           theme(axis.text = element_text(size = 19), 
                 axis.title = element_text(size = 24), 
                 #axis.line = element_line(size = 1),
                 plot.title = element_text(hjust = 0.5,size =  24),
                 #panel.grid = element_blank(), 
                 legend.text = element_text(size = 22),
                 legend.title = element_blank(),
                 legend.position = c(0.2,0.8))#c(0.2,0.8)
volcano <- volcano + guides(colour = guide_legend(override.aes = list(size = 9)))
library(ggrepel)
##geom_text_repel()
p2 <- volcano + 
      geom_text_repel(data = Data_summary[c("GBM","KIRC",
	                                        "PCPG","CESC","UCEC"),],
	                  aes(x = log2FoldChange, y = -log10(p.adj), label = Cancer),
                      seed = 123456,color = 'black',show.legend = FALSE, 
                      min.segment.length = 0,#始终为标签添加指引线段；若不想添加线段，则改为Inf
                      segment.linetype = 1, #线段类型,1为实线,2-6为不同类型虚线
                      force = 2,#重叠标签间的排斥力
                      force_pull = 2,#标签和数据点间的吸引力
                      size = 10,
                      box.padding = unit(2, "lines"),
                      point.padding = unit(1, "lines"),#点到线的距离
                      max.overlaps = Inf)#排斥重叠过多标签，设置为Inf则可以保持始终显示所有标签
p2

pdf("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step1.TCGA-Pan-cancer-Volcaon.pdf",
     height = 6.5,width = 6)
p2
dev.off()	