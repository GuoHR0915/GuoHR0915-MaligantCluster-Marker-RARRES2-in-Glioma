rm(list=ls())
options(stringsAsFactors = F)
setwd("D:/data/TCGA/")
########################################################################
##############################计算相关性################################
########################################################################
fs <- list.files('./TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
fs
TISIDB <- read.table("D:/data/Immunity therapy response/TISIDB-Geneset.txt",
                      sep = '\t',quote = "",fill = T,comment.char = "#",
					  header = F,stringsAsFactors = F)
table(TISIDB$V2)
# chemokine  Immunoinhibitor Immunostimulator              MHC         receptor 
       # 41               24               46               21               18
GeneSet <- sort(c(as.character(TISIDB[TISIDB$V2 == "Immunoinhibitor","V3"])))
GeneSet
 # [1] "ADORA2A"  "BTLA"     "CD160"    "CD244"    "CD274"    "CD96"    
 # [7] "CSF1R"    "CTLA4"    "HAVCR2"   "IDO1"     "IL10"     "IL10RB"  
# [13] "KDR"      "KIR2DL1"  "KIR2DL3"  "LAG3"     "LGALS9"   "PDCD1"   
# [19] "PDCD1LG2" "PVRL2"    "TGFB1"    "TGFBR1"   "TIGIT"    "VTCN1"   

load("./TCGAbiolinks-EXP/TCGA-ACC-GeneSymbol.Rdata")
GeneSet <- GeneSet[GeneSet %in% rownames(exp_Count)]
GeneSet
Gene <- "RARRES2"

Correlation <- lapply(fs,function(x){
	pro <- gsub('-GeneSymbol.Rdata','',x)
	print(pro)
 
    ##导入TPM结果
	load(paste0("./TCGAbiolinks-EXP/",x))
	exprSet <- data.frame(ID = colnames(exp_TPM),
                          SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
						  SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3),
                          Cancer = pro)
    exprSet$Group <- ifelse(exprSet$SampleType < 10,"Tumor","Normal")
    exprSet$Group2 <- paste0(exprSet$Cancer,"-",exprSet$Group)
    head(exprSet)
	
	##保留A：
	exprSet <- exprSet[exprSet$SampleType2 %in% "A",]
	##保留Primary：
	exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]

	exp_TPM_x <- exp_TPM[,exprSet$ID]
	Data <- t(as.matrix(exp_TPM_x[c(GeneSet,Gene),]))
    library(Hmisc)
    Correlation <- rcorr(Data,type = "spearman")
    print(pro)
    print("R :")
    print(Correlation$r[1:length(GeneSet),nrow(Correlation$r)])
    print("Pvalue :")
    print(Correlation$P[1:length(GeneSet),nrow(Correlation$r)])
	return(c(Correlation$r[1:length(GeneSet),nrow(Correlation$r)],
             Correlation$P[1:length(GeneSet),nrow(Correlation$r)]))
})
Correlation <- do.call(rbind,Correlation)
rownames(Correlation) <- gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs))

##提取R与pvalue
m <- t(Correlation[,1:length(GeneSet)])
head(m)
p <- t(Correlation[,(length(GeneSet)+1):ncol(Correlation)])
head(p)
range(m)#[1]-0.5369540  0.6946149
library(dplyr)
tmp <- matrix(case_when(as.vector(p) < 0.001~"****",
                       as.vector(p) < 0.001~"***",
                       as.vector(p) < 0.01~"**",
                       as.vector(p) < 0.05~"*",
                       T~ ""),nrow = nrow(p))
# source("D:/bioinformatics/R/1 Basic plot in R/heatmap/pheatmap/modified_pheatmap.R")
# Correlation <- pheatmap(m,
                        # display_numbers  = tmp,
                        # angle_col = 45,fontsize_number = 15,fontsize_row = 15,fontsize_col = 15,fontsize = 20,
                        # color = colorRampPalette(c("#92b7d1", "white", "#d71e22"))(100),
                        # border_color = "white",
                        # cluster_row = FALSE,cluster_col = FALSE,
                        # treeheight_col = 0,
                        # treeheight_row = 0)
# Correlation
# pdf("D:/Temp/Pan-cancer/RARRES2-TCGAbiolinks/results/5 Immune infiltration/Correlation-MHC Geneset.pdf",height = 6,width = 15)
# print(Correlation)
# dev.off()


####################使用ggplot2重新绘制：
Data_Checkpoint <- data.frame(t(m))
Data_Checkpoint$Cancer <- rownames(Data_Checkpoint) 
library(tidyverse)
dft <- Data_Checkpoint %>% pivot_longer(-Cancer)

##处理相关性矩阵
colnames(tmp) <- colnames(m)
rownames(tmp) <- rownames(m)
Data_Checkpoint_P <- data.frame(t(tmp))
Data_Checkpoint_P$Cancer <- rownames(Data_Checkpoint_P) 
dft_P <- Data_Checkpoint_P %>% pivot_longer(-Cancer)

dft$Cancer <- factor(dft$Cancer,levels = c(gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs)))) 
dft_P$Cancer <- factor(dft_P$Cancer,levels = c(gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs)))) 
range(dft$value,na.rm = T)#[1]-0.5369540  0.6946149
head(dft)

dft$name <- gsub("[.]","-",dft$name)
dft_P$name <- gsub("[.]","-",dft_P$name)
dft$name <- factor(dft$name,levels = rev(GeneSet))
dft_P$name <- factor(dft_P$name,levels = rev(GeneSet))
library(ggplot2)
library(paletteer)
library(ggthemes)
theme1 <- theme_minimal()+
          theme(panel.border = element_rect(fill = NA,size = 1, linetype = "solid"),
                panel.grid = element_blank(),
                axis.ticks.y = element_blank(),
                plot.title = element_text(hjust = 0.5,size = 22),
                axis.text.x = element_text(angle = 45,hjust = 1,size = 20),
                axis.text.y = element_text(size = 20))
Heatmap <- ggplot(data = dft,aes(x = Cancer,y = name)) +
           geom_tile(aes(fill = value),color = "grey") +
           geom_tile(aes(fill = value),color = "grey") +
           geom_text(data = dft_P,aes(x = Cancer,y = name,label = value),size = 6) +
           scale_x_discrete(expand = c(0,0)) + 
           scale_y_discrete(expand = c(0,0)) +
		   scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        name = NULL,midpoint = 0,
		                        limits = c(-0.7,0.7),breaks = round(seq(-0.6,0.6,0.3),2)) + 
           # scale_fill_paletteer_c("ggthemes::Classic Red-Blue",
                                  # direction = -1,
                                  # name="Correlation level",
                                  # limits = c(-0.5,0.7),
							      # breaks = seq(-0.4,0.6,0.2)) +
		   labs(title = NULL, x = NULL, y = NULL) + theme1		 
# ####拉长图例
Heatmap2 <- Heatmap + theme(legend.position = "right",
                            legend.text = element_text(color = "black",size = 20),
                            legend.title = element_blank())+
            guides(fill = guide_colorbar(title.position = "top",title.hjust = 0.5,
                                         barwidth = 1.5,barheight = 10,ticks = TRUE))
Heatmap2                           
                           
pdf("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step4.1.Correlation-Immunoinhibitor Geneset.pdf",
     height = 7.5,width = 15)
print(Heatmap2)
dev.off()

####################Dotplot
Data_Checkpoint <- data.frame(t(m))
Data_Checkpoint$Cancer <- rownames(Data_Checkpoint) 
library(tidyverse)
dft <- Data_Checkpoint %>% pivot_longer(-Cancer)

Data_GSVA_P <- data.frame(t(p))
Data_GSVA_P$Term <- rownames(Data_GSVA_P) 
dft_P <- Data_GSVA_P %>% pivot_longer(-Term)
Plotdata <- dft
colnames(Plotdata)[3] <- "Correlation"
Plotdata$Pvalue <- dft_P$value
Plotdata$Pvalue[Plotdata$Pvalue < 10^(-10)] <- 10^(-10)
range(Plotdata$Correlation)
range(-log10(Plotdata$Pvalue))#
Plotdata$Pvalue <- -log10(Plotdata$Pvalue)
range(Plotdata$Pvalue)

Plotdata$name <- gsub("[.]","-",dft$name)
Plotdata$name <- factor(Plotdata$name,levels = rev(GeneSet))
library(cols4all)
Dotplot <- ggplot(data = Plotdata,aes(x = Cancer,y = name,size = Pvalue))+
           geom_point(shape = 21,aes(fill = Correlation),position = position_dodge(0))+
           scale_size_continuous(range = c(0,7.5), name = bquote("-"~Log[10]~" Pvalue"),
		                         limits = c(0,10),breaks = seq(0,10,2),labels = seq(0,10,2))+
           scale_fill_gradient(low = "#498EA4", high = "#E54924", name = "Correlation",
		                       limits = c(-0.7,0.7),breaks = round(seq(-0.6,0.6,0.3),2))+
		   # scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        # name = "Correlation",
		                        # limits = c(-0.8,0.82),midpoint = 0,breaks = seq(-0.8,0.8,0.4))+
		   labs(title = NULL, x = NULL, y = NULL) +
		   theme1	  
								  
####拉长图例
Dotplot2 <- Dotplot + theme(legend.position = "bottom",
                            legend.text = element_text(color = "black",size = 16),
                            legend.title = element_text(size = 18,color = "black")) +
            guides(fill = guide_colorbar(title.position = "left",title.hjust = 0.5,
                                         barwidth = 15,barheight = 1.5,ticks = TRUE))
Dotplot2

Dotplot <- ggplot(data = Plotdata,aes(x = Cancer,y = name,size = Pvalue))+
           geom_point(shape = 21,aes(fill = Correlation),position = position_dodge(0))+
           scale_size_continuous(range = c(0,7.5), name = bquote("-"~Log[10]~" Pvalue"),
		                         limits = c(0,10),breaks = seq(0,10,2),labels = seq(0,10,2))+
           scale_fill_gradient2(low = "#0074b3", mid = "white", high = "red", 
		                        name = "Correlation",midpoint = 0,
		                        limits = c(-0.7,0.7),breaks = round(seq(-0.6,0.6,0.3),2)) + 
		   labs(title = NULL, x = NULL, y = NULL) +
		   theme1		  								  
####拉长图例
Dotplot3 <- Dotplot + theme(legend.position = "bottom",
                            legend.text = element_text(color = "black",size = 16),
                            legend.title = element_text(size = 18,color = "black"))+
            guides(fill = guide_colorbar(title.position = "left",title.hjust = 0.5,
                                         barwidth = 15,barheight = 1.5,ticks = TRUE))
Dotplot3                         
pdf("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step4.1.Correlation-Immunoinhibitor Geneset-Dotplot.pdf",
     height = 7.5,width = 12.5)
Dotplot2
Dotplot3
dev.off()
