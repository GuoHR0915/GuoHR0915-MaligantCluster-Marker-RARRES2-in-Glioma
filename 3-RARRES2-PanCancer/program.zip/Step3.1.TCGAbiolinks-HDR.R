rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
###################################################################################
#####################################提取HRD#######################################
###################################################################################
Scores <- read.delim("D:/bioinformatics/8.Online database/TCGA/DDR/TCGA_DDR_Data_Resources/DDRscores.tsv",header = F)
Samples <- read.delim("D:/bioinformatics/8.Online database/TCGA/DDR/TCGA_DDR_Data_Resources/Samples.tsv",header = F)
head(Samples)
##                V1  V2
## 1 TCGA-OR-A5J1-01 ACC
## 2 TCGA-OR-A5J2-01 ACC
## 3 TCGA-OR-A5J3-01 ACC
## 4 TCGA-OR-A5J5-01 ACC
## 5 TCGA-OR-A5J6-01 ACC
## 6 TCGA-OR-A5J7-01 ACC
Colnames <- read.delim("D:/bioinformatics/8.Online database/TCGA/DDR/TCGA_DDR_Data_Resources/Scores.tsv",header = F)
rownames(Scores) <- Samples$V1
colnames(Scores) <- Colnames$V1
colnames(Scores)
##  [1] "mutLoad_silent"         "mutLoad_nonsilent"      "mutSig1"               
##  [4] "mutSig2"                "mutSig3"                "mutSig4"               
##  [7] "mutSig5"                "mutSig6"                "mutSig7"               
## [10] "mutSig8"                "mutSig9"                "mutSig10"              
## [13] "mutSig11"               "mutSig12"               "mutSig13"              
## [16] "mutSig14"               "mutSig15"               "mutSig16"              
## [19] "mutSig17"               "mutSig18"               "mutSig19"              
## [22] "mutSig20"               "mutSig21"               "CNA_n_segs"            
## [25] "CNA_frac_altered "      "CNA_n_focal_amp_del"    "aneuploidy_score"      
## [28] "aneuploidy_score_prime" "LOH_n_seg"              "LOH_frac_altered "     
## [31] "purity"                 "ploidy"                 "genome_doublings"      
## [34] "subclonal_frac"         "HRD_TAI"                "HRD_LST"               
## [37] "HRD_LOH"                "HRD_Score"              "eCARD"                 
## [40] "PARPi7"                 "PARPi7_bin"             "RPS"                   
## [43] "tp53_score"             "rppa_ddr_score"

# 提取HDR分数
HRD_Scores <- Scores[,35:38]
head(HRD_Scores)
##                 HRD_TAI HRD_LST HRD_LOH HRD_Score
## TCGA-OR-A5J1-01       3       2       2         7
## TCGA-OR-A5J2-01       4       2       3         9
## TCGA-OR-A5J3-01       0       0       0         0
## TCGA-OR-A5J5-01       2       2       4         8
## TCGA-OR-A5J6-01       3       1       1         5
## TCGA-OR-A5J7-01      10       8       3        21
dim(HRD_Scores)## [1] 9125 4

###################################################################################
###################################计算相关性######################################
###################################################################################
fs <- list.files('TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
Gene <- "RARRES2"
Correlation <- lapply(fs,function(x){
    pro <- gsub('-GeneSymbol.Rdata','',x)
    print(pro)
    load(paste0("./TCGAbiolinks-EXP/",x))
	SampleList <- intersect(substr(colnames(exp_TPM),1,15),
	                        rownames(HRD_Scores))
	
	TCGAHRD_x <- HRD_Scores[SampleList,]
	TCGAHRD_x$Tumor_Patient_Barcode <- substr(rownames(TCGAHRD_x),1,12)
	exp_TPM_x <- exp_TPM[,substr(colnames(exp_TPM),1,15) %in% SampleList]
	
	###过滤正常样本
	Group <- ifelse(as.numeric(substr(sapply(strsplit(colnames(exp_TPM_x),"-"),"[",4),1,2)) < 10,"Tumor","Normal")
	exp_TPM_x <- exp_TPM_x[,Group == "Tumor"]
	
	exprSet <- data.frame(Expression = as.numeric(exp_TPM_x[Gene,]),
                          Tumor_Patient_Barcode = substr(colnames(exp_TPM_x),1,12),
                          Tumor_Sample_Barcode = colnames(exp_TPM_x),
						  SampleType = substr(sapply(strsplit(colnames(exp_TPM_x),'-'),"[",4),1,2),
						  SampleType2 = substr(sapply(strsplit(colnames(exp_TPM_x),'-'),"[",4),3,3),
                          Group = strsplit(pro,"-")[[1]][2])
	table(exprSet$SampleType2)
	table(exprSet$SampleType)
    ##保留A：
	exprSet <- exprSet[exprSet$SampleType2 %in% "A",]
	##保留Primary/正常：
	exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
    
	dat <- merge(exprSet,TCGAHRD_x,by = "Tumor_Patient_Barcode")
    Data <- as.matrix(dat[,c("Expression","HRD_Score")])
    ###############计算
	library(Hmisc)
	#correlation <- rcorr(Data,type = "pearson")
    correlation <- rcorr(Data,type = "spearman")
	#rcorr(x = Data[,1],y = Data[,2],type = "spearman")

    print("R :")
    print(correlation$r["HRD_Score","Expression"])
    print("Pvalue :")
    print(correlation$P["HRD_Score","Expression"])
    return(c(correlation$r["HRD_Score","Expression"],correlation$P["HRD_Score","Expression"]))
})
Correlation <- do.call(rbind,Correlation)
rownames(Correlation) <- sapply(strsplit(sapply(strsplit(fs,'-'),"[",2),"[.]"),"[",1)
colnames(Correlation) <- c("R","Pvalue")
head(Correlation)
#                 R       Pvalue
# ACC   0.424754911 1.311286e-04
# BLCA  0.328303924 2.356271e-11
# BRCA  0.352512396 0.000000e+00
# CESC  0.133180893 2.808104e-02
# CHOL -0.374527383 2.664744e-02
# COAD  0.289047634 5.496766e-08
# DLBC  0.289327188 8.241024e-02
# ESCA  0.132586811 1.057887e-01
# GBM   0.243930907 7.256379e-03
# HNSC  0.254351127 1.487045e-08
# KICH  0.198126131 1.136318e-01
# KIRC  0.056015776 2.967046e-01
# KIRP -0.080360504 1.880192e-01
# LAML -0.058043506 5.868473e-01
# LGG   0.288912546 3.805156e-11
# LIHC  0.480003874 0.000000e+00
# LUAD  0.321722193 8.570922e-14
# LUSC  0.231874956 4.412118e-07
# MESO  0.291886632 8.611629e-03
# OV    0.025415699 7.399485e-01
# PAAD  0.105462941 2.149279e-01
# PCPG -0.040749682 6.089181e-01
# PRAD  0.232858263 3.604470e-07
# READ  0.084565221 3.625764e-01
# SARC  0.089159107 1.836517e-01
# SKCM -0.026428334 6.201950e-01
# STAD  0.291629097 8.711940e-09
# TGCT -0.008777571 9.168401e-01
# THCA  0.026065483 5.791953e-01
# THYM -0.409565792 1.579900e-05
# UCEC  0.220049338 5.197720e-07
# UCS   0.380262007 3.841439e-03
# UVM   0.206109431 6.661947e-02






###ggplot2绘图可视化：
library(ggsci)
library(ggplot2)
Color <- pal_npg(alpha = 0.7)(6)
Correlation <- data.frame(Correlation)
Correlation$Group <- rownames(Correlation)
Correlation <- Correlation[order(Correlation$Group),]
Correlation$Signature <- ifelse(Correlation$Pvalue < 0.05, 
                                 ifelse(Correlation$Pvalue < 0.01,
                                        ifelse(Correlation$Pvalue < 0.001,'***','**'),'*'),' ')
Correlation$Group <- paste0(Correlation$Group,"\n",Correlation$Signature)
range(Correlation$R)#[1] -0.4095658  0.4800039
Axis <- data.frame(Y = round(seq(-0.4,0.5,0.1),2),
                   X = 1) 
pHRD <- ggplot(data = Correlation,aes(x = Group, y = R,group = 1)) +
          geom_polygon(color = 'black', fill= Color[1],alpha=0.5)+ 
          scale_y_continuous(expand = c(0,0),
		                     limit = c(-0.41,0.5),
		                     breaks = seq(-0.4,0.5,0.1),
                             labels = round(seq(-0.4,0.5,0.1),2))+
          geom_point(size = 3,shape = 21,color = 'black',fill = "#E41A1C")+
          geom_text(data = Axis,aes(x = X, y = Y,label = Y),hjust = 1,size = 7)+
		  labs(title = "Homologous Recombination Deficiency (HRD)", x = NULL, y = NULL)+
          coord_polar() +
          theme_light()+
          theme(axis.text.x = element_text(size = 18), 
                axis.text.y = element_blank(),#element_text(size = 18),
                panel.grid.minor = element_blank(),
                panel.background = element_blank(),
                panel.border = element_blank(),
                axis.line = element_blank(),#element_line(colour = 'black'), 
                plot.title = element_text(hjust = 0.5,size = 20),
                legend.position = "none")
pHRD
pdf("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step3.1.HRD-ggplot2.pdf",width = 9,height = 9)
pHRD
dev.off()









