rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
##去除生存数据0天
##暴力删除生存时间>10年
###################################################################################
###################################合并TPM + OS####################################
###################################################################################
fs <- list.files('TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
cancers <- sapply(strsplit(sapply(strsplit(fs,'-'),"[",2),"[.]"),"[",1)
Gene <- "RARRES2"
#x <- "COAD"
OScoxSummary <- do.call(rbind,lapply(cancers, function(x){
    load(paste0('TCGAbiolinks-EXP/TCGA-',x,'-GeneSymbol.Rdata'))
	load(paste0('TCGAbiolinks-EXP/TCGA-',x,'-clinical.Rdata'))
	exprSet <- data.frame(Expression = log2(as.numeric(exp_TPM[Gene,]+1)),
                          ID = substr(colnames(exp_TPM),1,12),
                          SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
						  SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3),
                          Cancer = x)
    exprSet <- exprSet[as.numeric(exprSet$SampleType) < 10,]
	##仅保留A
	print(table(exprSet$SampleType2))
	exprSet <- exprSet[exprSet$SampleType2 == "A",]
	print(table(exprSet$SampleType2))
	##保留Primary：
	print(table(exprSet$SampleType))
	exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
    print(table(exprSet$SampleType))
	
	exprSet <- exprSet[exprSet$ID %in% meta$ID,]
    meta <- meta[meta$ID %in% exprSet$ID,]
    exprSet <- merge(exprSet,meta,by = "ID")
    
    library("survival")
	OS <- na.omit(exprSet[,c("time","status","Expression")])
	
	##去除生存数据小于30天
	# if(length(which(OS$time <= 30 & OS$status == 1)) > 0){
	   # OS <- OS[-which(OS$time <= 30 & OS$status == 1),]
	# }else{
	   # OS <- OS
	# }
	#去除生存数据0天
	# if(length(which(OS$time == 0)) > 0){
	   # OS <- OS[-which(OS$time == 0),]
	# }else{
	   # OS <- OS
	# }
	OS <- OS[OS$time < 365*10,]
	# OS$Group <- ifelse(OS$Expression > median(OS$Expression),"High","Low")
	# OS$Group <- factor(OS$Group,levels = c("Low","High"))
    # res.cox <- coxph(Surv(time,status)~Group, data = OS)
	res.cox <- coxph(Surv(time,status)~Expression, data = OS)
    OScoxSummary <- summary(res.cox)
    OScoxSummary <- data.frame(id = x,
	                           N = nrow(OS),
                               HR = OScoxSummary$conf.int[,"exp(coef)"],
                               HR_95L = OScoxSummary$conf.int[,"lower .95"],
                               HR_95H = OScoxSummary$conf.int[,"upper .95"],
                               C_index = OScoxSummary$concordance["C"],
                               C_index_se = OScoxSummary$concordance["se(C)"],                   
                               pvalue = OScoxSummary$coefficients[,"Pr(>|z|)"])
    return(OScoxSummary)
}))
OScoxSummary
OScoxSummary[OScoxSummary$pvalue < 0.05,]
      # id   N        HR    HR_95L    HR_95H   C_index C_index_se       pvalue
# C    ACC  75 0.8827773 0.7865470 0.9907809 0.5950966 0.05968897 3.423941e-02
# C8   GBM 145 1.2080321 1.0854353 1.3444759 0.5806902 0.03261450 5.372072e-04
# C11 KIRC 520 1.1565762 1.0131874 1.3202576 0.5840108 0.02371797 3.124329e-02
# C14  LGG 487 1.4365997 1.3199347 1.5635763 0.7128666 0.02965566 5.138204e-17
# C18 MESO  81 0.7447261 0.6057358 0.9156087 0.6070200 0.03746221 5.166157e-03
# C20 PAAD 178 1.2389156 1.0192349 1.5059452 0.5236620 0.03298399 3.145418e-02
# C26 STAD 404 1.1672924 1.0135954 1.3442953 0.5355467 0.02476661 3.175905e-02
# C32  UVM  77 1.7020880 1.1926284 2.4291753 0.6873706 0.05485277 3.382618e-03

###################################################################################
###################################森林图可视化####################################
###################################################################################
forest <- data.frame(Cancer = OScoxSummary$id,
                     N = OScoxSummary$N,
                     HR2 = paste0(sprintf("%0.2f", OScoxSummary$HR)," (",
                                 sprintf("%0.2f", OScoxSummary$HR_95L),"-",sprintf("%0.2f", OScoxSummary$HR_95H),")"),
                     P_value = sprintf("%0.3f", OScoxSummary$pvalue))
forest$HR_95L <- OScoxSummary$HR_95L
forest$HR_95H <- OScoxSummary$HR_95H
forest$HR <- OScoxSummary$HR
range(forest$HR_95H)
#[1]0.9156087 4.7490673
range(forest$HR_95L)
#[1]0.3076055 1.3199347
forest$P_value <- ifelse(as.numeric(forest$P_value) < 0.001,"<0.001",forest$P_value)
forest <- forest[order(forest$HR,decreasing = T),]
forest$Cancer <- factor(forest$Cancer,levels = rev(forest$Cancer))
forest$Color <- "black"
forest$Color[forest$HR > 1 & forest$P_value < 0.05] <- "red"
forest$Color[forest$HR < 1 & forest$P_value < 0.05] <- "#005496"


library(ggplot2)
#######################HR barplot	
p4 <-  ggplot(forest,aes(x = HR, y = Cancer))+
	   geom_errorbar(aes(xmin = HR_95L , xmax = HR_95H), 
                     position = position_dodge(0.8), 
					 width = 0.5, size = 0.5,
					 color = "black") +
	   geom_point(shape = 22,size = 5,color = forest$Color,fill = forest$Color) +
	   scale_x_continuous(expand = c(0,0),limits = c(0.25,5),
	                      breaks = c(0.25,0.5,1,2,4), 
	                      labels = c(0.25,0.5,1,2,4)) +
	   # scale_x_continuous(limits = c(0.0055,30),breaks = c(2^-7,0.015625,0.03125,0.0625,0.125,0.25,0.5,1,2,4,8,16,32),
	                                            # labels = c("","2e-6","","2e-4","",0.25,"",1,"",4,"",16,"")) +
	   geom_vline(aes(xintercept = 1), linetype = 'dashed', color = 'black')+
	   coord_trans(x = "log2") +
	   labs(title = "", x = "Hazard Ratio(HR)",y = NULL) +
	   theme_classic() +
	   theme(plot.title = element_text(hjust = 0.5,face = "bold"),
			 axis.text.x = element_text(angle = 30,hjust = 1,size = 17), 
             axis.text.y = element_blank(), 
			 axis.title.x = element_blank(), 
			 axis.title.y = element_blank(), 
			 axis.ticks.y = element_blank(),
			 axis.ticks.length.x = unit(0.4,"lines"), 
			 axis.line.x = element_line(size = 1),
			 axis.line.y = element_blank(),
			 panel.border = element_blank(),
			 legend.position = "none")
for (i in 1:nrow(forest)) 
    p4 <- p4 + annotate('rect', xmin = -Inf, xmax = Inf, ymin = i-0.5, ymax = i+0.5, 
                        fill = ifelse(i %% 2 == 0, 'white', 'gray95'), alpha = .5)			 
p4

#######################P value
p5 <-  ggplot(forest,aes(x = 1, y = Cancer))+
	   geom_text(aes(x = 1,y = Cancer),label = forest$P_value,
                 hjust = 0.5,inherit.aes = FALSE,size = 6,
				 color = forest$Color) +
	   labs(title = "P value", x = "",y = NULL) +
	   theme_classic() +
	   theme(plot.title = element_text(hjust = 0.5,face = "bold",size = 20),
			 axis.text.x = element_blank(), 
             axis.text.y = element_blank(),
			 axis.title.x = element_blank(), 
			 axis.title.y = element_blank(),
			 axis.ticks.x = element_blank(),			 
			 axis.ticks.y = element_blank(),
			 axis.line.x = element_blank(),
			 axis.line.y = element_blank())

#######################Cancer Type
p1 <-  ggplot(forest,aes(x = 1, y = Cancer))+
	   geom_text(aes(x = 1,y = Cancer),label = forest$Cancer,
                 hjust = 0.5,inherit.aes = FALSE,size = 6,color = forest$Color) +
	   labs(title = "Cancer", x = "",y = NULL) +
	   theme_classic() +
	   theme(plot.title = element_text(hjust = 0.5,face = "bold",size = 20),
			 axis.text.x = element_blank(), 
             axis.text.y = element_blank(),
			 axis.title.x = element_blank(), 
			 axis.title.y = element_blank(),
			 axis.ticks.x = element_blank(),			 
			 axis.ticks.y = element_blank(),
			 axis.line.x = element_blank(),
			 axis.line.y = element_blank())
#######################N of Dataset
p2 <-  ggplot(forest,aes(x = 1, y = Cancer))+
	   geom_text(aes(x = 1,y = Cancer),label = forest$N,
                 hjust = 0.5,inherit.aes = FALSE,size = 6,color = forest$Color) +
	   labs(title = "N", x = "",y = NULL) +
	   theme_classic() +
	   theme(plot.title = element_text(hjust = 0.5,face = "bold",size = 20),
			 axis.text.x = element_blank(), 
             axis.text.y = element_blank(),
			 axis.title.x = element_blank(), 
			 axis.title.y = element_blank(),
			 axis.ticks.x = element_blank(),			 
			 axis.ticks.y = element_blank(),
			 axis.line.x = element_blank(),
			 axis.line.y = element_blank())
#######################95% HR2
p3 <-  ggplot(forest,aes(x = 1, y = Cancer))+
	   geom_text(aes(x = 1,y = Cancer),label = forest$HR2,
                 hjust = 0.5,inherit.aes = FALSE,size = 6,color = forest$Color) +
	   labs(title="HR (95% CI)", x = "",y = NULL) +
	   theme_classic() +
	   theme(plot.title = element_text(hjust = 0.5,face = "bold",size = 20),
			 axis.text.x = element_blank(), 
             axis.text.y = element_blank(),
			 axis.title.x = element_blank(), 
			 axis.title.y = element_blank(),
			 axis.ticks.x = element_blank(),			 
			 axis.ticks.y = element_blank(),
			 axis.line.x = element_blank(),
			 axis.line.y = element_blank())			 
library(patchwork)
p1 + p2 + p3 + p4 + p5 + plot_layout(widths = c(0.8,0.5,1.5,2.5,1),nrow = 1)
pdf("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step2.TCGA-Pan-cancer-Cox-OS-2.pdf",width = 10,height = 10)
p1 + p2 + p3 + p4 + p5 + plot_layout(widths = c(0.8,0.5,1.8,2.8,0.8),nrow = 1)
dev.off()
library(openxlsx)
write.xlsx(OScoxSummary,file = "D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/singleCox-OS.xlsx",
           colNames = TRUE,rowNames = TRUE)		 
	 
