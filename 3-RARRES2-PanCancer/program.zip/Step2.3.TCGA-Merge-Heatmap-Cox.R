rm(list = ls()) 
setwd("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks")
library(readxl)
MergeCox <- as.data.frame(read_excel("./results/Step2.TCGA-Pan-cancer-Cox-Merge.xlsx",sheet =1))
rownames(MergeCox) <- MergeCox[,1]
MergeCox <- MergeCox[,-1]
MergeCox$OSGroup <- ifelse(as.numeric(MergeCox$OSHR) > 1,"Risky","Protective")
MergeCox$DSSGroup <- ifelse(as.numeric(MergeCox$DSSHR) > 1,"Risky","Protective")
MergeCox$DFIGroup <- ifelse(as.numeric(MergeCox$DFIHR) > 1,"Risky","Protective")
MergeCox$PFIGroup <- ifelse(as.numeric(MergeCox$PFIHR) > 1,"Risky","Protective")

MergeCox$OSGroup[as.numeric(MergeCox$OSPvalue) > 0.05] <- "Nonsense"
MergeCox$DSSGroup[as.numeric(MergeCox$DSSPvalue) > 0.05] <- "Nonsense"
MergeCox$DFIGroup[as.numeric(MergeCox$DFIPvalue) > 0.05] <- "Nonsense"
MergeCox$PFIGroup[as.numeric(MergeCox$PFIPvalue) > 0.05] <- "Nonsense"

grep("Group",colnames(MergeCox))
A <- MergeCox[,grep("Group",colnames(MergeCox))]
A$Cancer <- rownames(MergeCox)
######################################ggplot2######################################
library(tidyverse)
dft <- A %>% pivot_longer(-Cancer)
dft$value[is.na(dft$value)] <- "NA"
dft$value <- factor(dft$value,levels = c("Risky","Protective","Nonsense","NA"))
dft$Cancer <- factor(dft$Cancer,levels = rownames(MergeCox[order(MergeCox$OSHR),]))
dft$name <- factor(dft$name,levels = c("OSGroup","DSSGroup","DFIGroup","PFIGroup"))

theme <- theme_minimal()+
           theme(panel.border = element_rect(fill=NA,size=1,linetype="solid"),
                 panel.grid = element_blank(),
                 legend.position = "right",
                 legend.text = element_text(size = 18),
                 legend.title = element_text(size = 18),
                 axis.ticks.y = element_blank(),
                 axis.title = element_blank(),
                 axis.text.x = element_blank(),
                 axis.text.y = element_text(size = 18))
library(ggplot2)
ggplot2 <- ggplot(data = dft,aes(x = name,y = Cancer))+
           geom_tile(aes(fill = value),color = "grey")+
           scale_x_discrete(expand = c(0,0)) +
           scale_y_discrete(expand = c(0,0)) + 
		   #scale_fill_manual(values = c("#0074b3",'white','grey60'))+
           scale_fill_manual(values = c("#c74546","#0074b3",'white','grey60'))+
		   theme +
           labs(fill = "Prognostic Role")
ggplot2
 

################绘制组间色块
Survival_Type <- c("OS","DSS","DFI","PFI")
Group <- data.frame(Sample_id = c("OSGroup","DSSGroup","DFIGroup","PFIGroup"),
                    Yaxis = "Annotation",
                    SurvivalType = factor(Survival_Type,levels = unique(Survival_Type)))
Group$Sample_id <- factor(Group$Sample_id,levels = c("OSGroup","DSSGroup","DFIGroup","PFIGroup"))
Group
theme <- theme_void()+
         theme(panel.border = element_blank(),
		       # plot.margin=unit(c(0.4,0.4,0.4,0.4),units=,"cm"),
		       panel.grid = element_blank(),
               legend.position = "none")  
library(RColorBrewer)
Group1 <- ggplot(data = Group,aes(Sample_id,Yaxis,fill = SurvivalType)) +
          geom_tile(show.legend = FALSE) +
		  geom_text(aes(Sample_id,Yaxis,label = SurvivalType),
		            color = "black",
                    hjust = 0.5,inherit.aes = FALSE,size = 6) +
		  scale_x_discrete(expand=c(0,0)) +
          scale_y_discrete(expand=c(0,0)) +
          scale_fill_manual(values = alpha(brewer.pal(9, "Set2")[c(1,2,3,5)],0.95)) +
		  theme
# library(aplot)
# ggplot2 %>% insert_top(Group2,height = 0.04) %>% insert_top(Group1,height = 0.04) 
library(patchwork) 
pMerge <- (Group1 + plot_spacer() + ggplot2) + 
           plot_layout(heights = c(0.04,-0.025,1),ncol = 1,guides = 'collect') & 
		               theme(legend.position = "bottom")
pMerge

pdf("./Step2.TCGA-Pan-cancer-Cox-Heatmap.pdf",height = 9,width = 4)
pMerge
dev.off()
pdf("./Step2.TCGA-Pan-cancer-Cox-Heatmap2.pdf",height = 10.5,width = 12.5)
ggplot2 + p2 + p3 + p4 + p5 + plot_layout(widths = c(1.8,0.4,1.8,2.5,0.6),nrow = 1)& 
		               theme(legend.position = "bottom")
dev.off()
