rm(list=ls())
options(stringsAsFactors = F)
setwd("D:/data/TCGA/")
fs <- list.files('./TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
fs
set.seed(123456)
###################################################################################
####################################CIBERSORT######################################
###################################################################################
dat_list <- lapply(fs[19:24], function(x){
                      pro <- gsub('-GeneSymbol.Rdata','',x)
                      print(pro)
                      load(paste0("./TCGAbiolinks-EXP/",x))
                      #去除低表达基因
                      minRow <- rowMeans(exp_Count) > 1  #按平均数筛选 
                      minNum <- rowSums(exp_Count > 0) > (0.8*ncol(exp_Count)) #表达量不为0的样品个数筛选 
                      #minNum <- rowSums(exp_Count > 0) >= (1*ncol(exp_Count))
                      exp_Count <- exp_Count[minRow & minNum,]
                      print(dim(exp_Count))
					  
                      mixed_expr <- exp_TPM[rownames(exp_Count),colnames(exp_Count)]
  
                      library(CIBERSORT)
                      #读取包自带的LM22文件（免疫细胞特征基因文件）
                      #sig_matrix <- system.file("extdata", "LM22.txt", package = "CIBERSORT")
                      data(LM22)
                      print(LM22[1:4,1:4])
                      CIBERSORT_ES <- cibersort(sig_matrix = LM22, mixture_file = mixed_expr,perm = 1000,QN = F)

                      save(CIBERSORT_ES,pro,file = paste0("./TCGAbiolinks-CIBERSORT/CIBERSORT-",pro,".Rdata"))
                      rm(mixed_expr)
                      rm(exp_TPM)
                      rm(exp_FPKM)
                      rm(exp_FPKM_UQ)
                      rm(exp_Count)
                      gc()
                      return(CIBERSORT_ES)
})


###################################################################################
######################################差异细胞#####################################
###################################################################################
rm(list = ls())
gc()
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
fs <- list.files('TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
Gene <- "RARRES2"
#############
#############添加了M1/M2
#############
Cor <- lapply(fs,function(x){
      pro <- gsub('-GeneSymbol.Rdata','',x)
      print(pro)
	  load(paste0("./TCGAbiolinks-EXP/",x))
	  exprSet <- data.frame(Expression = as.numeric(exp_TPM[Gene,]),
                            Tumor_Patient_Barcode = substr(colnames(exp_TPM),1,12),
                            Tumor_Sample_Barcode = colnames(exp_TPM),
						    SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
						    SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3))
	  table(exprSet$SampleType2)
	  table(exprSet$SampleType)
	  ##保留A：
	  exprSet <- exprSet[exprSet$SampleType2 %in% "A",]
	  ##保留Primary：
	  exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
	  #exprSet$Group <- ifelse(exprSet$Expression > median(exprSet$Expression),"High","Low")
	  #table(exprSet$Group)
	  
      load(paste0("./TCGAbiolinks-CIBERSORT/CIBERSORT-",pro,".Rdata"))
	  SampleList <- intersect(exprSet$Tumor_Sample_Barcode,rownames(CIBERSORT_ES))
	  CIBERSORT_ES_x <- data.frame(CIBERSORT_ES[SampleList,1:22])
	  CIBERSORT_ES_x$M1.2 <- as.numeric(CIBERSORT_ES_x[,"Macrophages.M1"])/as.numeric(CIBERSORT_ES_x[,"Macrophages.M2"])
	  CIBERSORT_ES_x$Gene <- as.numeric(exp_TPM[Gene,exprSet$Tumor_Sample_Barcode])
	  
	  Data <- as.matrix(CIBERSORT_ES_x)
	  library(Hmisc)
	  tmp <- as.numeric(Data[,23])
	  tmp[tmp == Inf] <- NA
	  Data[,23] <- tmp
	  Correlation <- rcorr(Data,type = "spearman")
	  print(pro)
	  print("R :")
	  print(Correlation$r[1:23,"Gene"])
	  print("Pvalue :")
	  print(Correlation$P[1:23,"Gene"])
	  return(c(Correlation$r[1:23,"Gene"],
               Correlation$P[1:23,"Gene"]))
})

Correlation <- do.call(rbind,Cor)
rownames(Correlation) <- gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs))

##提取R与pvalue
m <- t(Correlation[,1:23])
head(m)
p <- t(Correlation[,24:46])
head(p)
range(m,na.rm = T)#[1]-0.4248664  0.5749306
library(dplyr)
tmp <- matrix(case_when(as.vector(p) < 0.001~"****",
                       as.vector(p) < 0.001~"***",
                       as.vector(p) < 0.01~"**",
                       as.vector(p) < 0.05~"*",
                       T~ ""),nrow = nrow(p))
# source("D:/bioinformatics/R/1 Basic plot in R/heatmap/pheatmap/modified_pheatmap.R")
# Correlation <- pheatmap(m,
                        # display_numbers  = tmp,
                        # angle_col = 45,fontsize_number = 15,fontsize_row = 15,fontsize_col = 15,fontsize = 20,
                        # color = colorRampPalette(c("#92b7d1", "white", "#d71e22"))(100),
                        # border_color = "white",
                        # cluster_row = FALSE,cluster_col = FALSE,
                        # treeheight_col = 0,
                        # treeheight_row = 0)
# Correlation
# pdf("D:/Temp/Pan-cancer/RARRES2-TCGAbiolinks/results/5 Immune infiltration/Correlation-MHC Geneset.pdf",height = 6,width = 15)
# print(Correlation)
# dev.off()


####################使用ggplot2重新绘制：
Data_Checkpoint <- data.frame(t(m))
Data_Checkpoint$Cancer <- rownames(Data_Checkpoint) 
library(tidyverse)
dft <- Data_Checkpoint %>% pivot_longer(-Cancer)

##处理相关性矩阵
colnames(tmp) <- colnames(m)
rownames(tmp) <- rownames(m)
Data_Checkpoint_P <- data.frame(t(tmp))
Data_Checkpoint_P$Cancer <- rownames(Data_Checkpoint_P) 
dft_P <- Data_Checkpoint_P %>% pivot_longer(-Cancer)

dft$Cancer <- factor(dft$Cancer,levels = c(gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs)))) 
dft_P$Cancer <- factor(dft_P$Cancer,levels = c(gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs)))) 
range(dft$value,na.rm = T)#[1]-0.4248664  0.5749306
head(dft)
 
dft$name <- gsub("[.]"," ",dft$name)
dft_P$name <- gsub("[.]"," ",dft_P$name)
dft$name <- factor(dft$name,levels = rev(sort(unique(dft$name))))
dft_P$name <- factor(dft_P$name,levels = rev(sort(unique(dft$name))))
library(ggplot2)
library(paletteer)
library(ggthemes)
theme1 <- theme_minimal()+
          theme(panel.border = element_rect(fill = NA,size = 1, linetype = "solid"),
                panel.grid = element_blank(),
                axis.ticks.y = element_blank(),
                plot.title = element_text(hjust = 0.5,size = 20),
                axis.text.x = element_text(angle = 45,hjust = 1,size = 15),
                axis.text.y = element_text(size = 15))
Heatmap <- ggplot(data = dft,aes(x = Cancer,y = name)) +
           geom_tile(aes(fill = value),color = "grey") +
           geom_text(data = dft_P,aes(x = Cancer,y = name,label = value),size = 4.5) +
           scale_x_discrete(expand = c(0,0)) + 
           scale_y_discrete(expand = c(0,0)) +
		   scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        name = NULL,midpoint = 0,
		                        limits = c(-0.58,0.58),breaks = seq(-0.4,0.4,0.2)) + 
           # scale_fill_paletteer_c("ggthemes::Classic Red-Blue",
                                  # direction = -1,
                                  # name="Correlation level",
                                  # limits = c(-0.5,0.7),
							      # breaks = seq(-0.4,0.6,0.2)) +
		   labs(title = NULL, x = NULL, y = NULL) + theme1		 
# ####拉长图例
Heatmap2 <- Heatmap + theme(legend.position = "bottom",
                            legend.text = element_text(color = "black",size = 18),
                            legend.title = element_text(size = 18,color = "black")) +
            guides(fill = guide_colorbar(title.position = "right",title.hjust = 0.5,
                                         barwidth = 15,barheight = 1.5,ticks = TRUE))
Heatmap2                           
                           
pdf("D:/Temp/3-Pan-cancer/2-RARRES2-TCGAbiolinks-2/results/Step4.3.CIBERSORT.pdf",
     height = 8,width = 12)
print(Heatmap2)
dev.off()

# Celltype <- c("T cells CD8","NK cells resting","NK cells activated",
              # "Monocytes","Macrophages M0","Macrophages M1","Macrophages M2",
			  # "Dendritic cells resting","Dendritic cells activated")
Celltype <- c("Macrophages M0","Macrophages M1","Macrophages M2")
dft <- dft[dft$name %in%Celltype,]
dft_P <- dft_P[dft_P$name %in%Celltype,]
range(dft$value,na.rm = T)#[1]-0.3256311  0.5749306
Heatmap <- ggplot(data = dft,aes(x = Cancer,y = name)) +
           geom_tile(aes(fill = value),color = "grey") +
           geom_text(data = dft_P,aes(x = Cancer,y = name,label = value),size = 4.5) +
           scale_x_discrete(expand = c(0,0)) + 
           scale_y_discrete(expand = c(0,0)) +
		   scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        name = NULL,midpoint = 0,
		                        limits = c(-0.58,0.58),breaks = seq(-0.4,0.4,0.2)) + 
           # scale_fill_paletteer_c("ggthemes::Classic Red-Blue",
                                  # direction = -1,
                                  # name="Correlation level",
                                  # limits = c(-0.5,0.7),
							      # breaks = seq(-0.4,0.6,0.2)) +
		   labs(title = NULL, x = NULL, y = NULL) + theme1		 
# ####拉长图例
Heatmap2 <- Heatmap + theme(legend.position = "bottom",
                            legend.text = element_text(color = "black",size = 18),
                            legend.title = element_text(size = 18,color = "black")) +
            guides(fill = guide_colorbar(title.position = "right",title.hjust = 0.5,
                                         barwidth = 15,barheight = 1.5,ticks = TRUE))
Heatmap2  
 
pdf("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step4.3.CIBERSORT-Macrophages.pdf",
     height = 3,width = 15)
print(Heatmap2)
dev.off()


####################Dotplot
Data_Checkpoint <- data.frame(t(m))
Data_Checkpoint$Cancer <- rownames(Data_Checkpoint) 
library(tidyverse)
dft <- Data_Checkpoint %>% pivot_longer(-Cancer)

Data_GSVA_P <- data.frame(t(p))
Data_GSVA_P$Term <- rownames(Data_GSVA_P) 
dft_P <- Data_GSVA_P %>% pivot_longer(-Term)
Plotdata <- dft
colnames(Plotdata)[3] <- "Correlation"
Plotdata$Pvalue <- dft_P$value
Plotdata$Pvalue[Plotdata$Pvalue < 10^(-10)] <- 10^(-10)
range(Plotdata$Correlation,na.rm = T)#-0.5850684  0.6723800
range(-log10(Plotdata$Pvalue),na.rm = T)#
Plotdata$Pvalue <- -log10(Plotdata$Pvalue)
range(Plotdata$Pvalue,na.rm = T)

Plotdata$name <- gsub("[.]"," ",dft$name)
Plotdata$name <- factor(Plotdata$name,levels = rev(sort(unique(Plotdata$name))))

Plotdata <- Plotdata[Plotdata$name %in%Celltype,]

Dotplot <- ggplot(data = Plotdata,aes(x = Cancer,y = name,size = Pvalue))+
           geom_point(shape = 21,aes(fill = Correlation),position = position_dodge(0))+
           scale_size_continuous(range = c(0,7.5), name = "-log10 Pvalue",
		                         limits = c(0,10),breaks = seq(0,10,2),labels = seq(0,10,2))+
           scale_fill_gradient(low = "#498EA4", high = "#E54924", name = "Correlation",
		                       limits = c(-0.58,0.58),breaks = seq(-0.4,0.4,0.2))+
		   # scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        # name = "Correlation",
		                        # limits = c(-0.8,0.82),midpoint = 0,breaks = seq(-0.8,0.8,0.4))+
		   labs(title = NULL, x = NULL, y = NULL) +
		   theme1		  
								  
####拉长图例
Dotplot2 <- Dotplot + theme(legend.position = "bottom",
                            legend.text = element_text(color = "black",size = 16),
                            legend.title = element_text(size = 18,color = "black")) +
            guides(fill = guide_colorbar(title.position = "left",title.hjust = 0.5,
                                         barwidth = 15,barheight = 1.5,ticks = TRUE))
Dotplot2

Dotplot <- ggplot(data = Plotdata,aes(x = Cancer,y = name,size = Pvalue))+
           geom_point(shape = 21,aes(fill = Correlation),position = position_dodge(0))+
           scale_size_continuous(range = c(0,7.5), name = "-log10 Pvalue",
		                         limits = c(0,10),breaks = seq(0,10,2),labels = seq(0,10,2))+
           scale_fill_gradient2(low = "#0074b3", mid = "white", high = "red", 
		                        name = "Correlation",midpoint = 0,
		                        limits = c(-0.58,0.58),breaks = seq(-0.4,0.4,0.2)) + 
		   labs(title = NULL, x = NULL, y = NULL) +
		   theme1		  								  
####拉长图例
Dotplot3 <- Dotplot + theme(legend.position = "bottom",
                            legend.text = element_text(color = "black",size = 16),
                            legend.title = element_text(size = 18,color = "black"))+
            guides(fill = guide_colorbar(title.position = "left",title.hjust = 0.5,
                                         barwidth = 15,barheight = 1.5,ticks = TRUE))
Dotplot3                         
pdf("D:/Temp/3-Pan-cancer/2-RARRES2-TCGAbiolinks-2/results/Step4.3.CIBERSORT-Dotplot.pdf",
     height = 8,width = 12)
Dotplot2
Dotplot3
dev.off()
