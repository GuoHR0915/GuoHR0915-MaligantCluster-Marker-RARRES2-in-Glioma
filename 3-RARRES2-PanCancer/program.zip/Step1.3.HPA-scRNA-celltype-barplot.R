rm(list=ls())
options(stringsAsFactors = F)
library(Seurat)
library(ggplot2)
library(cowplot)
library(dplyr)
setwd("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks")
library(data.table)
cell_data_mean <- data.frame(fread("D:/data/Normal tissues/scRNA(HPA)/rna_single_cell_type.tsv"))
cell_data_mean <- cell_data_mean[cell_data_mean$Gene.name == "RARRES2",]

cell_data_annotation <- data.frame(fread("D:/data/Normal tissues/scRNA(HPA)/rna_single_cell_cluster_description.tsv"))
cell_data_annotation <- unique(cell_data_annotation[,c("Cell.type","Cell.type.group")])

plotData <- merge(cell_data_mean,cell_data_annotation,by = "Cell.type")
plotData <- plotData[order(plotData$nTPM,decreasing = T),]
plotData$Cell.type <- factor(plotData$Cell.type,levels = unique(plotData$Cell.type))
range(plotData$nTPM)

library(ggplot2)
library(ggsci)
Color <- pal_nejm()(8)
Color <- c('#E5D2DD', '#53A85F', '#F1BB72', '#F3B1A0', '#D6E7A3', '#57C3F3', 
           '#476D87', '#E95C59', '#E59CC4', '#AB3282', '#23452F', '#BD956A', 
           '#8C549C', '#585658', '#9FA3A8', '#E0D4CA', '#5F3D69', '#C5DEBA', 
           '#58A4C3', '#E4C755', '#F7F398', '#AA9A59', '#E63863', '#E39A35', 
           '#C1E6F3', '#6778AE', '#91D0BE', '#B53E2B', '#712820', '#DCC1DD', 
           '#CCE0F5',  '#CCC9E6', '#625D9E', '#68A180', '#3A6963', '#968175')#颜色设置  
mytheme <- theme_bw()+ 
            theme(legend.position = "bottom",
			      legend.title = element_blank(),
                  legend.text = element_text(size = 12),
                  plot.title = element_text(hjust = 0.5),
                  axis.text.x = element_text(angle = 45,hjust = 1,size = 12), 
                  axis.text.y = element_text(size = 14),  
                  axis.title.y = element_text(size = 16), 
                  axis.line = element_line(colour = "black",size = 1))
pbarplot <- ggplot(plotData,aes(x = Cell.type,y = nTPM,fill = Cell.type.group)) +
            geom_col(position = position_dodge(width = 0.9), width = 0.7) +
            scale_color_manual(values = Color) +
            scale_fill_manual(values = Color) +
			mytheme + 
            scale_y_continuous(expand = c(0,0),limits = c(0,2600),
                               breaks = seq(0,2500,500),labels = seq(0,2500,500)) +
            labs(title = "Human Protein Atlas", y = "RARRES2 Relative Expression (nTPM)",x = NULL)
pbarplot   
# pdf(file = "./results/Step1.3.HPA-scRNA.pdf",width = 17.5)
# pbarplot
# dev.off()
mytheme <- theme_bw()+ 
            theme(legend.position = "bottom",
			      legend.title = element_blank(),
                  legend.text = element_text(size = 18),
                  plot.title = element_text(hjust = 0.5),
                  axis.text.x = element_text(size = 18), 
                  axis.text.y = element_text(size = 16),  
				  axis.title.x = element_text(size = 18), 
                  axis.title.y = element_text(size = 18), 
                  axis.line = element_line(colour = "black",size = 1))

plotData$Cell.type <- factor(plotData$Cell.type,levels = rev(plotData$Cell.type))
pbarplot <- ggplot(plotData,aes(x = Cell.type,y = nTPM,fill = Cell.type.group)) +
            geom_col(position = position_dodge(width = 0.9), width = 0.7) +
            scale_color_manual(values = Color) +
            scale_fill_manual(values = Color) +
			mytheme + 
            scale_y_continuous(expand = c(0,0),limits = c(0,2600),
                               breaks = seq(0,2500,500),labels = seq(0,2500,500)) +
            labs(title = NULL, y = "RARRES2 Relative Expression (nTPM)",
			     x = NULL)
pbarplot   

pdf(file = "./results/Step1.3.HPA-scRNA-2.pdf",height = 16,width = 8.5)
pbarplot + coord_flip() + theme(legend.position = c(0.5,0.5))
dev.off()
