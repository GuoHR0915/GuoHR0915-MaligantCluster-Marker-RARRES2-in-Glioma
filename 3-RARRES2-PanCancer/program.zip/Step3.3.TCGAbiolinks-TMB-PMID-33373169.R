rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
###################################################################################
#####################################计算TMB#######################################
###################################################################################
##使用PMID-33373169结果

###################################################################################
###################################计算相关性######################################
###################################################################################
rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
library(readxl)
TCGAtmb <- as.data.frame(read_excel("D:/data/TCGA/PMID-33373169/TMB.xlsx",sheet =1))
TCGAtmb$Tumor_Patient_Barcode <- substr(TCGAtmb$id,1,12)
head(TCGAtmb)#[1] 10114     4
#                 id       TMB CancerType Tumor_Patient_Barcode
# 1 TCGA-B8-5550-01A 3.0000000       KIRC          TCGA-B8-5550
# 2 TCGA-BP-4998-01A 1.0000000       KIRC          TCGA-BP-4998
# 3 TCGA-CZ-5456-01A 1.8684211       KIRC          TCGA-CZ-5456
# 4 TCGA-DV-A4VZ-01A 0.3421053       KIRC          TCGA-DV-A4VZ
# 5 TCGA-GK-A6C7-01A 3.3157895       KIRC          TCGA-GK-A6C7
# 6 TCGA-A3-3372-01A 1.7631579       KIRC          TCGA-A3-3372


fs <- list.files('TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
Gene <- "RARRES2"
Correlation <- lapply(fs,function(x){
    pro <- gsub('-GeneSymbol.Rdata','',x)
    print(pro)
    load(paste0("./TCGAbiolinks-EXP/",x))
	SampleList <- intersect(substr(colnames(exp_TPM),1,12),
	                        TCGAtmb$Tumor_Patient_Barcode)
	
	TCGAtmb_x <- TCGAtmb[TCGAtmb$Tumor_Patient_Barcode %in% SampleList,]
	exp_TPM_x <- exp_TPM[,substr(colnames(exp_TPM),1,12) %in% SampleList]
	
	###过滤正常样本
	Group <- ifelse(as.numeric(substr(sapply(strsplit(colnames(exp_TPM_x),"-"),"[",4),1,2)) < 10,"Tumor","Normal")
	exp_TPM_x <- exp_TPM_x[,Group == "Tumor"]
	
	exprSet <- data.frame(Expression = as.numeric(exp_TPM_x[Gene,]),
                          Tumor_Patient_Barcode = substr(colnames(exp_TPM_x),1,12),
                          Tumor_Sample_Barcode = colnames(exp_TPM_x),
						  SampleType = substr(sapply(strsplit(colnames(exp_TPM_x),'-'),"[",4),1,2),
						  SampleType2 = substr(sapply(strsplit(colnames(exp_TPM_x),'-'),"[",4),3,3),
                          Group = strsplit(pro,"-")[[1]][2])
	table(exprSet$SampleType2)
	table(exprSet$SampleType)
    ##保留A：
	exprSet <- exprSet[exprSet$SampleType2 %in% "A",]
	##保留Primary/正常：
	exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
    
	dat <- merge(exprSet,TCGAtmb_x,by = "Tumor_Patient_Barcode")
    Data <- as.matrix(dat[,c("Expression","TMB")])
    ###############计算
	library(Hmisc)
	#correlation <- rcorr(Data,type = "pearson")
    correlation <- rcorr(Data,type = "spearman")
	#rcorr(x = Data[,1],y = Data[,2],type = "spearman")

    print("R :")
    print(correlation$r["TMB","Expression"])
    print("Pvalue :")
    print(correlation$P["TMB","Expression"])
    return(c(correlation$r["TMB","Expression"],correlation$P["TMB","Expression"]))
})
Correlation <- do.call(rbind,Correlation)
rownames(Correlation) <- sapply(strsplit(sapply(strsplit(fs,'-'),"[",2),"[.]"),"[",1)
colnames(Correlation) <- c("R","Pvalue")
head(Correlation)
               # R       Pvalue
# ACC  -0.42481541 9.532271e-05
# BLCA -0.06278223 2.068149e-01
# BRCA -0.04086606 2.011750e-01
# CESC -0.15299131 1.035654e-02
# CHOL -0.07541883 6.667637e-01
# COAD -0.11909818 1.648770e-02
# DLBC -0.01158301 9.465439e-01
# ESCA -0.13907521 6.883414e-02
# GBM   0.04590229 5.902057e-01
# HNSC -0.12931655 4.026349e-03
# KICH  0.13720622 2.719529e-01
# KIRC  0.14565183 7.672838e-03
# KIRP  0.13269932 2.666583e-02
# LAML  0.19889425 4.842671e-02
# LGG   0.15553076 5.084377e-04
# LIHC  0.19662877 1.811183e-04
# LUAD -0.08516646 5.364856e-02
# LUSC -0.12616511 5.443088e-03
# MESO -0.22252108 5.500273e-02
# OV   -0.08210468 1.609851e-01
# PAAD -0.27704744 5.495491e-04
# PCPG -0.30425212 4.248990e-05
# PRAD -0.31501708 2.749356e-12
# READ -0.21649048 1.373104e-02
# SARC -0.05308173 4.189662e-01
# SKCM -0.16724739 9.130072e-02
# STAD -0.26677545 5.606736e-08
# TGCT -0.06501436 4.388171e-01
# THCA -0.16223010 3.587789e-04
# THYM  0.32988665 2.642798e-04
# UCEC -0.08645124 4.750982e-02
# UCS   0.20307385 1.297617e-01
# UVM  -0.11363076 3.251212e-01

###ggplot2绘图可视化：
library(ggsci)
library(ggplot2)
Color <- pal_npg(alpha = 0.7)(6)
Correlation <- data.frame(Correlation)
Correlation$Group = rownames(Correlation)
Correlation <- Correlation[order(Correlation$Group),]
Correlation$Signature = ifelse(Correlation$Pvalue < 0.05, 
                                 ifelse(Correlation$Pvalue < 0.01,
                                        ifelse(Correlation$Pvalue < 0.001,'***','**'),'*'),' ')
Correlation$Group <- paste0(Correlation$Group,"\n",Correlation$Signature)
range(Correlation$R)#[1]-0.4248154  0.3298866
Axis <- data.frame(Y = round(seq(-0.4,0.4,0.1),2),
                   X = 1) 
pTMB <- ggplot(data = Correlation,aes(x = Group, y = R,group = 1)) +
        #geom_polygon(color = 'black', fill= Color[2],alpha=0.5) + 
        geom_line(color = Color[1], fill = Color[1],alpha = 0.5,size = 2)+ 
		scale_y_continuous(expand = c(0,0),
		                   limit = c(-0.45,0.4),
		                   breaks = seq(-0.4,0.4,0.1),
                           labels = round(seq(-0.4,0.4,0.1),2)) +
        geom_point(size = 6,shape = 21,color = Color[1],fill = Color[1])+
        geom_text(data = Axis,aes(x = X, y = Y,label = Y),hjust = 1,size = 7)+
		labs(title = NULL, x = NULL, y = NULL)+
        coord_polar() +
        theme_light() +
        theme(axis.text.x = element_text(size = 18), 
              axis.text.y = element_blank(),#element_text(size = 18),
              panel.grid.minor = element_blank(),
              panel.background = element_blank(),
              panel.border = element_blank(),
              axis.line = element_blank(),#element_line(colour = 'black'), 
              plot.title = element_text(hjust = 0.5,size = 20),
              legend.position = "none")
pTMB
pdf("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step3.3.TMB-ggplot2.pdf",
    width = 9,height = 9)
pTMB
dev.off()









