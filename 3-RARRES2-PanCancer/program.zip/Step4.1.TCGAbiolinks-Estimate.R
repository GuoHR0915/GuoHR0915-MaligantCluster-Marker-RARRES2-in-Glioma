rm(list=ls())
options(stringsAsFactors = F)
setwd("D:/data/TCGA/")
library(estimate)
estimate_RNAseq <- function(dat,pro){
  input.f <- paste0(pro,'_estimate_input.txt')
  output.f <- paste0(pro,'_estimate_gene.gct')
  output.ds <- paste0(pro,'_estimate_score.gct')
  write.table(dat,file = input.f,sep = '\t',quote = F)
  library(estimate)
  filterCommonGenes(input.f = input.f,
                    output.f = output.f ,
                    id = "GeneSymbol")
  estimateScore(input.ds = output.f,
                output.ds = output.ds,
                platform = "illumina")   ## 注意platform
  scores <- read.table(output.ds,skip = 2,header = T)
  rownames(scores) <- scores[,1]
  scores <- t(scores[,3:ncol(scores)])
  return(scores)
}

fs <- list.files('./TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
fs
lapply(fs, function(x){
  pro <- gsub('-GeneSymbol.Rdata','',x)
  print(pro)
  load(paste0("./TCGAbiolinks-EXP/",x))
  dat <- log2(edgeR::cpm(exp_Count)+1)
  
  set.seed(12345)
  Scores <- estimate_RNAseq(dat,pro)
  head(Scores)
  Group <- ifelse(as.numeric(substring(rownames(Scores),14,15)) < 10,'tumor','normal')
  table(Group) 
  save(Scores,file = paste0('TCGAbiolinks-Estimate/Estimate-score-for-',pro,'.Rdata'))
  
  rm(dat)
  rm(exp_TPM)
  rm(exp_FPKM)
  rm(exp_FPKM_UQ)
  rm(exp_Count)
  gc()
})

###################################################################################
###################################计算相关性######################################
###################################################################################
rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
fs <- list.files('TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
Gene <- "RARRES2"
Correlation <- lapply(fs,function(x){
      pro <- gsub('-GeneSymbol.Rdata','',x)
      print(pro)
	  load(paste0("./TCGAbiolinks-EXP/",x))
      load(paste0("./TCGAbiolinks-Estimate/Estimate-score-for-",pro,".Rdata"))
	  #Scores <- data.frame(Scores)
	  rownames(Scores) <- gsub("[.]","-",rownames(Scores))
	
	  SampleList <- intersect(rownames(Scores),colnames(exp_TPM))
	
	  Scores_x <- Scores[SampleList,]
	  exp_TPM_x <- exp_TPM[,SampleList]
	
	  exprSet <- data.frame(Expression = as.numeric(exp_TPM_x[Gene,]),
                            StromalScore = as.numeric(Scores_x[,"StromalScore"]),
                            ImmuneScore = as.numeric(Scores_x[,"ImmuneScore"]),
						    ESTIMATEScore = as.numeric(Scores_x[,"ESTIMATEScore"]),
							SampleType = substr(sapply(strsplit(colnames(exp_TPM_x),'-'),"[",4),1,2),
						    SampleType2 = substr(sapply(strsplit(colnames(exp_TPM_x),'-'),"[",4),3,3),
                            Group = strsplit(pro,"-")[[1]][2])
	
	  table(exprSet$SampleType2)
	  table(exprSet$SampleType)
      ##保留A：
	  exprSet <- exprSet[exprSet$SampleType2 %in% "A",]
	  ##保留Primary/正常：
	  exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
	
      Data <- as.matrix(exprSet[,1:4])
      ###############计算
	  library(Hmisc)
	  #correlation <- rcorr(Data,type = "pearson")
      correlation <- rcorr(Data,type = "spearman")
	  #rcorr(x = Data[,1],y = Data[,2],type="spearman")
      results <- t(data.frame(R = correlation$r[-1,"Expression"],
	                          Pvalue = correlation$P[-1,"Expression"]))
    return(results)
})
Correlation <- data.frame(do.call(rbind,Correlation))
StromalScore_Correlation <- data.frame(R = Correlation$StromalScore[seq(1,nrow(Correlation),2)],
                                       Pvalue =  Correlation$StromalScore[seq(2,nrow(Correlation),2)])
ImmuneScore_Correlation <- data.frame(R = Correlation$ImmuneScore[seq(1,nrow(Correlation),2)],
                                       Pvalue =  Correlation$ImmuneScore[seq(2,nrow(Correlation),2)])
ESTIMATEScore_Correlation <- data.frame(R = Correlation$ESTIMATEScore[seq(1,nrow(Correlation),2)],
                                       Pvalue =  Correlation$ESTIMATEScore[seq(2,nrow(Correlation),2)])
rownames(StromalScore_Correlation) <- sapply(strsplit(sapply(strsplit(fs,'-'),"[",2),"[.]"),"[",1)
rownames(ImmuneScore_Correlation) <- sapply(strsplit(sapply(strsplit(fs,'-'),"[",2),"[.]"),"[",1)
rownames(ESTIMATEScore_Correlation) <- sapply(strsplit(sapply(strsplit(fs,'-'),"[",2),"[.]"),"[",1)

StromalScore_Correlation[StromalScore_Correlation$Pvalue < 0.05,]
ImmuneScore_Correlation[ImmuneScore_Correlation$Pvalue < 0.05,]
ESTIMATEScore_Correlation[ESTIMATEScore_Correlation$Pvalue < 0.05,]



# #######StromalScore
# Correlation <- StromalScore_Correlation
# ###ggplot2绘图可视化：
# library(ggsci)
# library(ggplot2)
# Color = pal_npg(alpha = 0.7)(6)
# Correlation <- data.frame(Correlation)
# Correlation$Group = rownames(Correlation)
# Correlation <- Correlation[order(Correlation$Group),]
# Correlation$Signature = ifelse(Correlation$Pvalue < 0.05, 
                                 # ifelse(Correlation$Pvalue < 0.01,
                                        # ifelse(Correlation$Pvalue < 0.001,'***','**'),'*'),' ')
# Correlation$Group <- paste0(Correlation$Group,"\n",Correlation$Signature)
# range(Correlation$R)#[1] -0.3684971  0.2317975
# Axis <- data.frame(Y = round(seq(-0.4,0.2,0.1),2),
                   # X = 1) 

# pStromal <- ggplot(data = Correlation,aes(x = Group, y = R,group = 1)) +
            # geom_polygon(color = 'black', fill = Color[2],alpha = 0.5)+ 
            # scale_y_continuous(expand = c(0,0),
		                       # limit = c(-0.45,0.24),
		                       # breaks = seq(-0.4,0.2,0.1),
                               # labels = round(seq(-0.4,0.2,0.1),2))+
            # geom_point(size = 3,shape = 21,color = 'black',fill = "#E41A1C")+
		    # geom_text(data = Axis,aes(x = X, y = Y,label = Y),hjust = 1,size = 7)+
            # labs(title = "Stromal Score", x = NULL, y = NULL)+
            # coord_polar() +
            # theme_light()+
            # theme(axis.text.x = element_text(size = 18), 
                  # axis.text.y = element_blank(),
                  # panel.grid.minor = element_blank(),
                  # panel.background = element_blank(),
                  # panel.border = element_blank(),
                  # axis.line = element_blank(),#element_line(colour = 'black'), 
                  # plot.title = element_text(hjust = 0.5,size = 20),
                  # legend.position = "none")
# pStromal
# pdf("C:/Users/Administrator/Desktop/Pan-cancer/RARRES2/results/5 Immune infiltration/Stromal-ggplot2.pdf",width = 9,height = 9)
# pStromal
# dev.off()




#######ImmuneScore
Correlation <- ImmuneScore_Correlation
###ggplot2绘图可视化：
library(ggsci)
library(ggplot2)
Color <- pal_npg(alpha = 0.7)(6)
Correlation <- data.frame(Correlation)
Correlation$Group <- rownames(Correlation)
Correlation <- Correlation[order(Correlation$Group),]
Correlation$Signature <- ifelse(Correlation$Pvalue < 0.05, 
                                 ifelse(Correlation$Pvalue < 0.01,
                                        ifelse(Correlation$Pvalue < 0.001,'***','**'),'*'),' ')
Correlation$Group <- paste0(Correlation$Group,"\n",Correlation$Signature)
range(Correlation$R)#[1]-0.1821238  0.5540648		
Axis <- data.frame(Y = round(seq(-0.2,0.6,0.2),2),
                   X = 1) 	  
pImmune <- ggplot(data = Correlation,aes(x = Group, y = R,group = 1)) +
           #geom_polygon(color = 'black', fill = Color[4],alpha = 0.5)+ 
           geom_line(color = Color[4], fill = Color[4],alpha = 0.5,size = 2)+ 
		   scale_y_continuous(expand = c(0,0),
		                      limit = c(-0.2,0.6),
		                      breaks = seq(-0.2,0.6,0.2),
                              labels = round(seq(-0.2,0.6,0.2),2))+
           geom_point(size = 6,shape = 21,color = Color[4],fill = Color[4])+
		   geom_text(data = Axis,aes(x = X, y = Y,label = Y),hjust = 1,size = 7)+
           labs(title = NULL, x = NULL, y = NULL)+
           coord_polar() +
           theme_light() +
           theme(axis.text.x = element_text(size = 18), 
                 axis.text.y = element_blank(),
                 panel.grid.minor = element_blank(),
                 panel.background = element_blank(),
                 panel.border = element_blank(),
                 axis.line = element_blank(),#element_line(colour = 'black'), 
                 plot.title = element_text(hjust = 0.5,size = 20),
                 legend.position = "none")
pImmune
pdf("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step4.1.Immune-ggplot2.pdf",
     width = 9,height = 9)
pImmune
dev.off()



#######ESTIMATEScore
Correlation <- ESTIMATEScore_Correlation
###ggplot2绘图可视化：
library(ggsci)
library(ggplot2)
Color = pal_npg(alpha = 0.7)(6)
Correlation <- data.frame(Correlation)
Correlation$Group = rownames(Correlation)
Correlation <- Correlation[order(Correlation$Group),]
Correlation$Signature = ifelse(Correlation$Pvalue < 0.05, 
                                 ifelse(Correlation$Pvalue < 0.01,
                                        ifelse(Correlation$Pvalue < 0.001,'***','**'),'*'),' ')
Correlation$Group <- paste0(Correlation$Group,"\n",Correlation$Signature)
range(Correlation$R)#[1]-0.4365684  0.2272467
Axis <- data.frame(Y = round(seq(-0.5,0.2,0.1),2),
                   X = 1) 

pESTIMATE <- ggplot(data = Correlation,aes(x = Group, y = R,group = 1)) +
          geom_polygon(color = 'black', fill = Color[1],alpha = 0.5)+ 
          scale_y_continuous(expand = c(0,0),
		                     limit = c(-0.5,0.23),
		                     breaks = seq(-0.5,0.2,0.1),
                             labels = round(seq(-0.5,0.2,0.1),2))+
          geom_point(size = 3,shape = 21,color = 'black',fill = "#E41A1C")+
		  geom_text(data = Axis,aes(x = X, y = Y,label = Y),hjust = 1,size = 7)+
          labs(title = "ESTIMATE Score", x = NULL, y = NULL)+
          coord_polar(theta = "x", start = 0, direction = 1, clip = "on") +
          theme_light()+
          theme(axis.text.x = element_text(size = 18), 
                axis.text.y = element_blank(),
                panel.grid.minor = element_blank(),
                panel.background = element_blank(),
                panel.border = element_blank(),
                axis.line = element_blank(),#element_line(colour = 'black'), 
                plot.title = element_text(hjust = 0.5,size = 20),
                legend.position = "none")
pESTIMATE
pdf("C:/Users/Administrator/Desktop/Pan-cancer/RARRES2/results/5 Immune infiltration/ESTIMATE-ggplot2.pdf",width = 9,height = 9)
pESTIMATE
dev.off()

#######Merge
Correlation <- rbind(ESTIMATEScore_Correlation,StromalScore_Correlation,ImmuneScore_Correlation)
Correlation$Group <- c(rep("ESTIMATE Score",nrow(ESTIMATEScore_Correlation)),
                       rep("Stromal Score",nrow(StromalScore_Correlation)),
                       rep("Immune Score",nrow(ImmuneScore_Correlation)))
Correlation$Cancer = rep(rownames(ESTIMATEScore_Correlation),3)
Correlation <- data.frame(Correlation)
Correlation <- Correlation[order(Correlation$Cancer),]
# Correlation$Signature = ifelse(Correlation$Pvalue < 0.05, 
                                 # ifelse(Correlation$Pvalue < 0.01,
                                        # ifelse(Correlation$Pvalue < 0.001,'***','**'),'*'),' ')
# Correlation$Group <- paste0(Correlation$Group,"\n",Correlation$Signature)
range(Correlation$R)#[1]-0.5021441  0.2426905
Axis <- data.frame(Y = round(seq(-0.5,0.2,0.1),2),
                   X = 1) 

pMerge <- ggplot() +
          geom_polygon(data = Correlation,aes(x = Cancer, y = R,group = Group,fill = Group),
		               color = 'black', alpha = 0.5) + 
		  scale_fill_manual(name = NULL,values = Color[c(2,4,1)]) +			   
		  geom_point(data = Correlation,aes(x = Cancer, y = R,group = Group,fill = Group),
		             size = 3,shape = 21,color = 'black',fill = "#E41A1C") +
          scale_y_continuous(expand = c(0,0),
		                     limit = c(-0.6,0.25),
		                     breaks = seq(-0.6,0.2,0.2),
                             labels = round(seq(-0.6,0.2,0.2),2)) +
		  geom_text(data = Axis,aes(x = X, y = Y,label = Y),hjust = 1,size = 7) +
          labs(title = "ESTIMATE Score", x = NULL, y = NULL) +
          coord_polar(theta = "x", start = 0, direction = 1, clip = "on") +
          theme_light()+
          theme(axis.text.x = element_text(size = 18), 
                axis.text.y = element_blank(),
                panel.grid.minor = element_blank(),
                panel.background = element_blank(),
                panel.border = element_blank(),
                axis.line = element_blank(),#element_line(colour = 'black'), 
                plot.title = element_text(hjust = 0.5,size = 20),
                legend.position = "none")
pMerge
pdf("C:/Users/Administrator/Desktop/Pan-cancer/RARRES2/results/5 Immune infiltration/Merge-ggplot2.pdf",width = 9,height = 9)
pMerge
dev.off()

