rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
###################################################################################
#####################################计算MSI#######################################
###################################################################################
##使用PMID-33373169结果

###################################################################################
###################################计算相关性######################################
###################################################################################
rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
library(readxl)
TCGAMSI <- as.data.frame(read_excel("D:/data/TCGA/PMID-33373169/MSI.xlsx",sheet =1))
TCGAMSI$Tumor_Patient_Barcode <- substr(TCGAMSI$id,1,12)
head(TCGAMSI)#[1]10415     4
 #                id    MSI CancerType Tumor_Patient_Barcode
# 1 TCGA-OR-A5J1-01A 0.2750        ACC          TCGA-OR-A5J1
# 2 TCGA-OR-A5J2-01A 0.3236        ACC          TCGA-OR-A5J2
# 3 TCGA-OR-A5J3-01A 0.3434        ACC          TCGA-OR-A5J3
# 4 TCGA-OR-A5J4-01A 0.2997        ACC          TCGA-OR-A5J4
# 5 TCGA-OR-A5J5-01A 0.5224        ACC          TCGA-OR-A5J5
# 6 TCGA-OR-A5J6-01A 0.2894        ACC          TCGA-OR-A5J6



fs <- list.files('TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
Gene <- "RARRES2"
Correlation <- lapply(fs,function(x){
    pro <- gsub('-GeneSymbol.Rdata','',x)
    print(pro)
    load(paste0("./TCGAbiolinks-EXP/",x))
	SampleList <- intersect(substr(colnames(exp_TPM),1,12),
	                        TCGAMSI$Tumor_Patient_Barcode)
	
	TCGAMSI_x <- TCGAMSI[TCGAMSI$Tumor_Patient_Barcode %in% SampleList,]
	exp_TPM_x <- exp_TPM[,substr(colnames(exp_TPM),1,12) %in% SampleList]
	
	###过滤正常样本
	Group <- ifelse(as.numeric(substr(sapply(strsplit(colnames(exp_TPM_x),"-"),"[",4),1,2)) < 10,"Tumor","Normal")
	exp_TPM_x <- exp_TPM_x[,Group == "Tumor"]
	
	exprSet <- data.frame(Expression = as.numeric(exp_TPM_x[Gene,]),
                          Tumor_Patient_Barcode = substr(colnames(exp_TPM_x),1,12),
                          Tumor_Sample_Barcode = colnames(exp_TPM_x),
						  SampleType = substr(sapply(strsplit(colnames(exp_TPM_x),'-'),"[",4),1,2),
						  SampleType2 = substr(sapply(strsplit(colnames(exp_TPM_x),'-'),"[",4),3,3),
                          Group = strsplit(pro,"-")[[1]][2])
	table(exprSet$SampleType2)
	table(exprSet$SampleType)
    ##保留A：
	exprSet <- exprSet[exprSet$SampleType2 %in% "A",]
	##保留Primary/正常：
	exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
	
	dat <- merge(exprSet,TCGAMSI_x,by = "Tumor_Patient_Barcode")
    Data <- as.matrix(dat[,c("Expression","MSI")])
    ###############计算
	library(Hmisc)
	#correlation <- rcorr(Data,type="pearson")
    correlation <- rcorr(Data,type="spearman")
	#rcorr(x = Data[,1],y = Data[,2],type="spearman")

    print("R :")
    print(correlation$r["MSI","Expression"])
    print("Pvalue :")
    print(correlation$P["MSI","Expression"])
    return(c(correlation$r["MSI","Expression"],correlation$P["MSI","Expression"]))
})
Correlation <- do.call(rbind,Correlation)
rownames(Correlation) <- sapply(strsplit(sapply(strsplit(fs,'-'),"[",2),"[.]"),"[",1)
colnames(Correlation) <- c("R","Pvalue")
head(Correlation)
                # R       Pvalue
# ACC  -0.166287321 1.430152e-01
# BLCA  0.005830959 9.067576e-01
# BRCA  0.019598673 5.286157e-01
# CESC -0.123559974 3.419978e-02
# CHOL -0.209243697 2.276808e-01
# COAD -0.013380646 7.805468e-01
# DLBC  0.385960856 7.374054e-03
# ESCA -0.101317111 1.860090e-01
# GBM   0.040902678 6.276514e-01
# HNSC -0.067962282 1.302665e-01
# KICH  0.335194832 5.938030e-03
# KIRC  0.121669301 2.551225e-02
# KIRP  0.109015447 6.561642e-02
# LAML -0.144623655 1.410311e-01
# LGG  -0.015460258 7.296811e-01
# LIHC  0.019407476 7.105867e-01
# LUAD -0.110309850 1.167086e-02
# LUSC -0.202855158 6.142647e-06
# MESO -0.192597840 9.114818e-02
# OV    0.057510915 3.257455e-01
# PAAD -0.110027312 1.460313e-01
# PCPG -0.125107310 9.804302e-02
# PRAD -0.007539849 8.687250e-01
# READ -0.089902539 2.755511e-01
# SARC -0.129064479 4.063658e-02
# SKCM -0.027166243 7.853201e-01
# STAD -0.239732254 9.335265e-07
# TGCT  0.103698007 2.081998e-01
# THCA  0.106064744 1.897281e-02
# THYM -0.019279116 8.351433e-01
# UCEC -0.074876882 8.242732e-02
# UCS   0.136023335 3.130222e-01
# UVM   0.064823153 5.754067e-01

###ggplot2绘图可视化：
library(ggplot2)
Correlation <- data.frame(Correlation)
Correlation$Group <- rownames(Correlation)
Correlation <- Correlation[order(Correlation$Group),]
Correlation$Signature <- ifelse(Correlation$Pvalue < 0.05, 
                                 ifelse(Correlation$Pvalue < 0.01,
                                        ifelse(Correlation$Pvalue < 0.001,'***','**'),'*'),' ')
Correlation$Group <- paste0(Correlation$Group,"\n",Correlation$Signature)
Correlation <- rbind(Correlation,Correlation[1,])
range(Correlation$R)#[1] -0.2397323  0.3859609
Axis <- data.frame(Y = round(seq(-0.2,0.5,0.1),2),
                   X = 1) 
pMSI <- ggplot(data = Correlation,aes(x = Group, y = R,group = 1)) +
        #geom_polygon(color = 'black', fill= Color[1],alpha=0.5)+ 
        geom_line(color = "#4d97cd", fill = "#4d97cd",alpha = 0.5,size = 2)+ 
		scale_y_continuous(expand = c(0,0),
		                     limit = c(-0.25,0.4),
		                     breaks = seq(-0.2,0.4,0.1),
                             labels = round(seq(-0.2,0.4,0.1),2))+
        geom_point(size = 6,shape = 21,color = "#4d97cd",fill = "#4d97cd")+
        geom_text(data = Axis,aes(x = X, y = Y,label = Y),hjust = 1,size = 7)+
		labs(title = NULL, x = NULL, y = NULL)+
        coord_polar() +
        theme_light()+
        theme(axis.text.x = element_text(size = 18), 
              axis.text.y = element_blank(),#element_text(size = 18),
              panel.grid.minor = element_blank(),
              panel.background = element_blank(),
              panel.border = element_blank(),
              axis.line = element_blank(),#element_line(colour = 'black'), 
              plot.title = element_text(hjust = 0.5,size = 20),
              legend.position = "none")
pMSI
pdf('D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step3.4.MSI-ggplot2.pdf',width = 9,height = 9)
pMSI
dev.off()









