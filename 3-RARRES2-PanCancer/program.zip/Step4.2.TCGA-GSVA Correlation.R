rm(list=ls())
options(stringsAsFactors = F)
setwd("D:/data/TCGA/")
########################################################################
##############################计算相关性################################
########################################################################
TISIDB <- read.table("D:/data/Immunity therapy response/TISIDB-Geneset.txt",
                      sep = '\t',quote = "",fill = T,comment.char = "#",
					  header = F,stringsAsFactors = F)
table(TISIDB$V2)
# chemokine  Immunoinhibitor Immunostimulator              MHC         receptor 
       # 41               24               46               21               18

load("./TCGAbiolinks-EXP/TCGA-ACC-GeneSymbol.Rdata")
TISIDB <- TISIDB[TISIDB$V3 %in% rownames(exp_Count),]
TISIDB <- TISIDB[,c(2:3)]
colnames(TISIDB) <- c("term","gene")


TISIDB_list <- split(TISIDB$gene,TISIDB$term)
lapply(TISIDB_list[1:3], head)

fs <- list.files('./TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
fs
library(GSVA)
set.seed(123456)
########################################################################
##################################GSVA##################################
########################################################################
dat_list <- lapply(fs, function(x){
        ##################
		###########数据整理
		##################
        pro <- gsub('-GeneSymbol.Rdata','',x)
        print(pro)
        load(paste0("./TCGAbiolinks-EXP/",x))
		
		exprSet <- data.frame(Tumor_Patient_Barcode = substr(colnames(exp_TPM),1,12),
                              Tumor_Sample_Barcode = colnames(exp_TPM),
                              SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
                              SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3))
		table(exprSet$SampleType2)
		table(exprSet$SampleType)
		##保留A：
		exprSet <- exprSet[exprSet$SampleType2 %in% "A",]
		##保留Primary：
		exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
		#去除低表达基因
        minRow <- rowMeans(exp_Count) > 1  #按平均数筛选 
        minNum <- rowSums(exp_Count > 0) > (0.8*ncol(exp_Count)) #表达量不为0的样品个数筛选 
        #minNum <- rowSums(exp_Count > 0) >= (1*ncol(exp_Count))
        exp_Count <- exp_Count[minRow & minNum,]
        print(dim(exp_Count))

        ###样本对齐
        exp_Count <- exp_Count[,exprSet$Tumor_Sample_Barcode]
        ###GSVA
		gsvaPar <- gsvaParam(exprData = log2(as.matrix(exp_TPM[rownames(exp_Count),colnames(exp_Count)]) + 1), 
                             geneSets = TISIDB_list,
                             kcdf = "Gaussian")
        TISIDB_Score <- gsva(gsvaPar, verbose = FALSE)

        save(TISIDB_Score,pro,file = paste0("./TCGAbiolinks-GSVA/TISIDB-",pro,".Rdata"))
        rm(TISIDB_Score)
        rm(exp_Count)
        rm(exp_FPKM)
        rm(exp_FPKM_UQ)
        gc()
})




########################################################################
##############################计算相关性################################
########################################################################
rm(list=ls())
options(stringsAsFactors = F)
setwd("D:/data/TCGA/")
fs <- list.files('./TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
fs
GeneSet <- c("CMKLR1","GPR1","CCRL2")
Term <- c("Immunoinhibitor","Immunostimulator")
load("./TCGAbiolinks-EXP/TCGA-ACC-GeneSymbol.Rdata")
GeneSet <- GeneSet[GeneSet %in% rownames(exp_Count)]
GeneSet
Gene <- "RARRES2"

#x <- fs[1]
Correlation <- lapply(fs,function(x){
	pro <- gsub('-GeneSymbol.Rdata','',x)
	print(pro)
 
    ##导入TPM结果
	load(paste0("./TCGAbiolinks-EXP/",x))
	exprSet <- data.frame(ID = colnames(exp_TPM),
                          SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
						  SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3),
                          Cancer = pro)
    exprSet$Group <- ifelse(exprSet$SampleType < 10,"Tumor","Normal")
    exprSet$Group2 <- paste0(exprSet$Cancer,"-",exprSet$Group)
    head(exprSet)
	
	##保留A：
	exprSet <- exprSet[exprSet$SampleType2 %in% "A",]
	##保留Primary：
	exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]

	exp_TPM_x <- exp_TPM[c(GeneSet,Gene),exprSet$ID]
	
	##导入GSVA score
	load(paste0("./TCGAbiolinks-GSVA/TISIDB-",pro,".Rdata"))
	TISIDB_Score_x <- TISIDB_Score[Term,exprSet$ID]
	identical(colnames(TISIDB_Score_x),colnames(exp_TPM_x))
	
	
	Data <- t(as.matrix(rbind(TISIDB_Score_x,exp_TPM_x)))
    library(Hmisc)
    Correlation <- rcorr(Data,type = "spearman")
    print(pro)
    print("R :")
    print(Correlation$r[1:(nrow(Correlation$r)-1),nrow(Correlation$r)])
    print("Pvalue :")
    print(Correlation$P[1:(nrow(Correlation$r)-1),nrow(Correlation$r)])
	return(c(Correlation$r[1:(nrow(Correlation$r)-1),nrow(Correlation$r)],
             Correlation$P[1:(nrow(Correlation$r)-1),nrow(Correlation$r)]))
})
Correlation <- do.call(rbind,Correlation)
rownames(Correlation) <- gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs))

##提取R与pvalue
m <- t(Correlation[,1:length(c(GeneSet,Term))])
head(m)
p <- t(Correlation[,(length(c(GeneSet,Term))+1):ncol(Correlation)])
head(p)
range(m)#[1]-0.2736695  0.6150152

library(dplyr)
tmp <- matrix(case_when(as.vector(p) < 0.001~"****",
                       as.vector(p) < 0.001~"***",
                       as.vector(p) < 0.01~"**",
                       as.vector(p) < 0.05~"*",
                       T~ ""),nrow = nrow(p))

####################使用ggplot2重新绘制：
Data_Checkpoint <- data.frame(t(m))
Data_Checkpoint$Cancer <- rownames(Data_Checkpoint) 
library(tidyverse)
dft <- Data_Checkpoint %>% pivot_longer(-Cancer)

##处理相关性矩阵
colnames(tmp) <- colnames(m)
rownames(tmp) <- rownames(m)
Data_Checkpoint_P <- data.frame(t(tmp))
Data_Checkpoint_P$Cancer <- rownames(Data_Checkpoint_P) 
dft_P <- Data_Checkpoint_P %>% pivot_longer(-Cancer)

dft$Cancer <- factor(dft$Cancer,levels = rev(c(gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs)))))
dft_P$Cancer <- factor(dft_P$Cancer,levels = rev(c(gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs))))) 
range(dft$value,na.rm = T)#[1]-0.2736695  0.6150152

head(dft)

library(ggplot2)
theme1 <- theme_minimal()+
          theme(panel.border = element_rect(fill = NA,size = 1, linetype = "solid"),
                panel.grid = element_blank(),
                axis.ticks.y = element_blank(),
                plot.title = element_text(hjust = 0.5,size = 22),
                axis.text.x = element_text(angle = 45,hjust = 1,size = 18.5),
                axis.text.y = element_text(size = 18.5))
Heatmap <- ggplot(data = dft,aes(x = name,y = Cancer)) +
           geom_tile(aes(fill = value),color = "grey") +
           geom_tile(aes(fill = value),color = "grey") +
           geom_text(data = dft_P,aes(x = name,y = Cancer,label = value),size = 9) +
           scale_x_discrete(expand = c(0,0),labels = function(dat) str_wrap(dat,width = 30)) +
           scale_y_discrete(expand = c(0,0)) +
		   scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        name = NULL,midpoint = 0,
		                        limits = c(-0.62,0.62),breaks = seq(-0.6,0.6,0.3)) + 
           # scale_fill_paletteer_c("ggthemes::Classic Red-Blue",
                                  # direction = -1,
                                  # name="Correlation level",
                                  # limits = c(-0.5,0.7),
							      # breaks = seq(-0.4,0.6,0.2)) +
		   labs(title = NULL, x = NULL, y = NULL) + theme1		 
# ####拉长图例
Heatmap2 <- Heatmap + theme(legend.position = "bottom",
                            legend.text = element_text(color = "black",size = 20),
                            legend.title = element_blank())+
            guides(fill = guide_colorbar(title.position = "left",title.hjust = 0.5,
                                         barwidth = 18,barheight = 1.5,ticks = TRUE))
Heatmap2 

pdf("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step4.2.Correlation-TISIDB.pdf",
     height = 15,width = 6)
print(Heatmap2)
dev.off()                          