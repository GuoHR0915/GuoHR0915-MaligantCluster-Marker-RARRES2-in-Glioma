###################################################################################
################################下载UCSC Xena TCGA ################################
###################################################################################
# perl -alne '{/\((.*?)\)/;print $1}' cancer_list.txt |while read id;
# do
   # echo ${id}
   # wget  https://tcga-xena-hub.s3.us-east-1.amazonaws.com/download/survival%2F${id}_survival.txt
   # mv survival%2F${id}_survival.txt ./TCGA-${id}.survival2.tsv 
# done

##去除生存数据0天
##暴力删除生存时间>10年
###################################################################################
##################################DFS + DSS + PFS##################################
###################################################################################
rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
fs <- list.files('TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
cancers <- sapply(strsplit(sapply(strsplit(fs,'-'),"[",2),"[.]"),"[",1)
Gene <- "RARRES2"
#x <- cancers[1]
###################################################################################
###################################合并TPM + DSS###################################
###################################################################################
DSScoxSummary <- do.call(rbind,lapply(cancers, function(x){
    load(paste0('TCGAbiolinks-EXP/TCGA-',x,'-GeneSymbol.Rdata'))
	Survival <- read.table(paste0("./UCSC Xena/TCGA-",x,".survival2.tsv"),header = T,sep = "\t")
	meta <- Survival[,c("X_PATIENT","DSS","DSS.time")]
	colnames(meta) <- c("ID","status","time")
	meta <- na.omit(meta)
	meta <- unique(meta)
	
	exprSet <- data.frame(Expression = log2(as.numeric(exp_TPM[Gene,]+1)),
                          ID = substr(colnames(exp_TPM),1,12),
                          SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
						  SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3),
                          Cancer = x)
    exprSet <- exprSet[as.numeric(exprSet$SampleType) < 10,]
	#仅保留A
	exprSet <- exprSet[as.numeric(exprSet$SampleType) < 10 & exprSet$SampleType2 == "A",]
	##保留Primary：
	print(table(exprSet$SampleType))
	exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
    print(table(exprSet$SampleType))
	
    exprSet <- exprSet[exprSet$ID %in% meta$ID,]
    meta <- meta[meta$ID %in% exprSet$ID,]
    exprSet <- merge(exprSet,meta,by = "ID")
    
    library("survival")
	DSS <- na.omit(exprSet[,c("time","status","Expression")])
	#去除生存数据0天
	# if(length(which(DSS$time == 0)) > 0){
	   # DSS <- DSS[-which(DSS$time == 0),]
	# }else{
	   # DSS <- DSS
	# }
	DSS <- DSS[DSS$time < 365*10,]
	# DSS$Group <- ifelse(DSS$Expression > median(DSS$Expression),"High","Low")
	# DSS$Group <- factor(DSS$Group,levels = c("Low","High"))
	
	print(c(x,dim(DSS)))

    if((!is.na(exprSet[1,1])) && (dim(exprSet)[1] > 5)){
	
       #res.cox <- coxph(Surv(time,status)~Group, data=DSS)
	   res.cox <- coxph(Surv(time,status)~Expression, data=DSS)
       DSScoxSummary <- summary(res.cox)
       DSScoxSummary <- data.frame(id = x,
	                               N = nrow(DSS),
	                               HR = DSScoxSummary$conf.int[,"exp(coef)"],
	                               HR_95L = DSScoxSummary$conf.int[,"lower .95"],
	                               HR_95H = DSScoxSummary$conf.int[,"upper .95"],
	                               C_index = DSScoxSummary$concordance["C"],
	                               C_index_se = DSScoxSummary$concordance["se(C)"],                   
	                               pvalue = DSScoxSummary$coefficients[,"Pr(>|z|)"])
    }else{
      print(paste0(x," has no data."))
      DSScoxSummary <- data.frame(id = x,N = NA,HR = NA,HR_95L = NA,HR_95H = NA,
                                  C_index = NA,C_index_se = NA,pvalue = NA)
    }
    return(DSScoxSummary)
}))
DSScoxSummary
DSScoxSummary <- na.omit(DSScoxSummary)
DSScoxSummary
DSScoxSummary[DSScoxSummary$pvalue < 0.05,]
      # id   N        HR    HR_95L    HR_95H   C_index C_index_se       pvalue
# C    ACC  73 0.8854132 0.7858606 0.9975772 0.5925325 0.06215764 4.551925e-02
# C6  DLBC  43 0.4283052 0.1911792 0.9595466 0.8640777 0.07674838 3.936963e-02
# C8   GBM 133 1.2116246 1.0824309 1.3562383 0.5914535 0.03445390 8.473429e-04
# C11 KIRC 509 1.3137611 1.0993105 1.5700462 0.6157802 0.03082746 2.688390e-03
# C12 KIRP 280 0.8412349 0.7111828 0.9950694 0.5643932 0.06809127 4.362786e-02
# C13  LGG 480 1.4521608 1.3308018 1.5845868 0.7175291 0.03122115 5.376515e-17
# C14 LIHC 359 0.8349935 0.7104954 0.9813070 0.5667100 0.03507935 2.859508e-02
# C15 LUAD 472 0.8341543 0.7029630 0.9898292 0.5768879 0.03312116 3.779622e-02
# C19 PAAD 172 1.2708070 1.0210298 1.5816877 0.5436907 0.03589458 3.184450e-02
# C31  UVM  77 1.8309131 1.2339484 2.7166799 0.6912088 0.05647425 2.663451e-03
library(openxlsx)
write.xlsx(DSScoxSummary,file = "D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step2.TCGA-Pan-cancer-Cox-DSS.xlsx",
           colNames = TRUE,rowNames = TRUE)		 
			 
###################################################################################
###################################合并TPM + DFI###################################
###################################################################################
DFIcoxSummary <- do.call(rbind,lapply(cancers, function(x){
    load(paste0('TCGAbiolinks-EXP/TCGA-',x,'-GeneSymbol.Rdata'))
	Survival <- read.table(paste0("./UCSC Xena/TCGA-",x,".survival2.tsv"),header = T,sep = "\t")
	meta <- Survival[,c("X_PATIENT","DFI","DFI.time")]
	colnames(meta) <- c("ID","status","time")
	meta <- na.omit(meta)
	meta <- unique(meta)
	
	exprSet <- data.frame(Expression = log2(as.numeric(exp_TPM[Gene,]+1)),
                          ID = substr(colnames(exp_TPM),1,12),
                          SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
						  SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3),
                          Cancer = x)
    exprSet <- exprSet[as.numeric(exprSet$SampleType) < 10,]
	#仅保留A
	exprSet <- exprSet[as.numeric(exprSet$SampleType) < 10 & exprSet$SampleType2 == "A",]
	##保留Primary：
	print(table(exprSet$SampleType))
	exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
    print(table(exprSet$SampleType))
	
    exprSet <- exprSet[exprSet$ID %in% meta$ID,]
    meta <- meta[meta$ID %in% exprSet$ID,]
    exprSet <- merge(exprSet,meta,by = "ID")
    
    library("survival")
	DFI <- na.omit(exprSet[,c("time","status","Expression")])
	# #去除生存数据0天
	# if(length(which(DFI$time == 0)) > 0){
	   # DFI <- DFI[-which(DFI$time == 0),]
	# }else{
	   # DFI <- DFI
	# }
	DFI <- DFI[DFI$time < 365*10,]
	# DFI$Group <- ifelse(DFI$Expression > median(DFI$Expression),"High","Low")
	# DFI$Group <- factor(DFI$Group,levels = c("Low","High"))
	
	print(c(x,dim(DFI)))

    if((!is.na(exprSet[1,1])) && (dim(exprSet)[1] > 5)){
       #res.cox <- coxph(Surv(time,status)~Group, data=DFI)
	   res.cox <- coxph(Surv(time,status)~Expression, data=DFI)
       DFIcoxSummary <- summary(res.cox)
       DFIcoxSummary <- data.frame(id = x,
	                               N = nrow(DFI),
	                               HR = DFIcoxSummary$conf.int[,"exp(coef)"],
	                               HR_95L = DFIcoxSummary$conf.int[,"lower .95"],
	                               HR_95H = DFIcoxSummary$conf.int[,"upper .95"],
	                               C_index = DFIcoxSummary$concordance["C"],
	                               C_index_se = DFIcoxSummary$concordance["se(C)"],                   
	                               pvalue = DFIcoxSummary$coefficients[,"Pr(>|z|)"])
    }else{
      print(paste0(x," has no data."))
      DFIcoxSummary <- data.frame(id = x,N = NA,HR = NA,HR_95L = NA,HR_95H = NA,
                                  C_index = NA,C_index_se = NA,pvalue = NA)
    }
    return(DFIcoxSummary)
}))
DFIcoxSummary
DFIcoxSummary <- na.omit(DFIcoxSummary)
DFIcoxSummary[DFIcoxSummary$pvalue < 0.05,]
      # id   N        HR    HR_95L    HR_95H   C_index C_index_se     pvalue
# C1  BLCA 183 0.7625183 0.6166609 0.9428751 0.5805673 0.05785763 0.01231497
# C17   OV 186 1.1527898 1.0133580 1.3114065 0.5562940 0.02637861 0.03064072
# C18 PAAD  69 1.4508963 1.0038691 2.0969866 0.6239814 0.06227600 0.04764589

library(openxlsx)
write.xlsx(DFIcoxSummary,file = "D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step2.TCGA-Pan-cancer-Cox-DFI.xlsx",
           colNames = TRUE,rowNames = TRUE)		 

###################################################################################
###################################合并TPM + PFI###################################
###################################################################################
PFIcoxSummary <- do.call(rbind,lapply(cancers, function(x){
    load(paste0('TCGAbiolinks-EXP/TCGA-',x,'-GeneSymbol.Rdata'))
	Survival <- read.table(paste0("./UCSC Xena/TCGA-",x,".survival2.tsv"),header = T,sep = "\t")
	meta <- Survival[,c("X_PATIENT","PFI","PFI.time")]
	colnames(meta) <- c("ID","status","time")
	meta <- na.omit(meta)
	meta <- unique(meta)
	
	exprSet <- data.frame(Expression = log2(as.numeric(exp_TPM[Gene,]+1)),
                          ID = substr(colnames(exp_TPM),1,12),
                          SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
						  SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3),
                          Cancer = x)
    ##仅保留A
	exprSet <- exprSet[as.numeric(exprSet$SampleType) < 10 & exprSet$SampleType2 == "A",]
	##保留Primary：
	print(table(exprSet$SampleType))
	exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
    print(table(exprSet$SampleType))
	
    exprSet <- exprSet[exprSet$ID %in% meta$ID,]
    meta <- meta[meta$ID %in% exprSet$ID,]
    exprSet <- merge(exprSet,meta,by = "ID")
    
    library("survival")
	PFI <- na.omit(exprSet[,c("time","status","Expression")])
	# #去除生存数据0天
	# if(length(which(PFI$time == 0)) > 0){
	   # PFI <- PFI[-which(PFI$time == 0),]
	# }else{
	   # PFI <- PFI
	# }
	PFI <- PFI[PFI$time < 365*10,]
	# PFI$Group <- ifelse(PFI$Expression > median(PFI$Expression),"High","Low")
	# PFI$Group <- factor(PFI$Group,levels = c("Low","High"))
	
	print(c(x,dim(PFI)))

    if((!is.na(exprSet[1,1])) && (dim(exprSet)[1] > 5)){
	
       #res.cox <- coxph(Surv(time,status)~Group, data=PFI)
	   res.cox <- coxph(Surv(time,status)~Expression, data=PFI)
       PFIcoxSummary <- summary(res.cox)
       PFIcoxSummary <- data.frame(id = x,
	                               N = nrow(PFI),
	                               HR = PFIcoxSummary$conf.int[,"exp(coef)"],
	                               HR_95L = PFIcoxSummary$conf.int[,"lower .95"],
	                               HR_95H = PFIcoxSummary$conf.int[,"upper .95"],
	                               C_index = PFIcoxSummary$concordance["C"],
	                               C_index_se = PFIcoxSummary$concordance["se(C)"],                   
	                               pvalue = PFIcoxSummary$coefficients[,"Pr(>|z|)"])
    }else{
      print(paste0(x," has no data."))
      PFIcoxSummary <- data.frame(id=x,N=NA,HR=NA,HR_95L=NA,HR_95H=NA,
                                  C_index = NA,C_index_se = NA,pvalue=NA)
    }
    return(PFIcoxSummary)
}))
PFIcoxSummary
PFIcoxSummary <- na.omit(PFIcoxSummary)
PFIcoxSummary[PFIcoxSummary$pvalue < 0.05,]
      # id   N        HR    HR_95L    HR_95H   C_index C_index_se       pvalue
# C6  DLBC  43 0.5409178 0.3130644 0.9346066 0.7265625 0.08099519 2.764049e-02
# C11 KIRC 523 1.2875594 1.1087351 1.4952257 0.5996794 0.02602677 9.232452e-04
# C13  LGG 497 1.2955424 1.2089645 1.3883205 0.6272751 0.02457944 2.177990e-13
# C18   OV 395 1.1070108 1.0131911 1.2095180 0.5406848 0.01847723 2.444901e-02
# C19 PAAD 178 1.2609519 1.0521431 1.5112009 0.5534010 0.03386731 1.206442e-02
# C31  UVM  76 1.5485993 1.1558796 2.0747486 0.6563574 0.05682736 3.382222e-03

library(openxlsx)
write.xlsx(PFIcoxSummary,file = "D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step2.TCGA-Pan-cancer-Cox-PFI.xlsx",
           colNames = TRUE,rowNames = TRUE)		 

merge(merge(DSScoxSummary,DFIcoxSummary,by = "id", all=TRUE),PFIcoxSummary,by = "id", all=TRUE)
write.table(merge(merge(DSScoxSummary,DFIcoxSummary,by = "id", all = TRUE),PFIcoxSummary,by = "id", all=TRUE),
            file = "D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step2.TCGA-Pan-cancer-Cox-Merge.txt",sep = "\t",quote = F)			 