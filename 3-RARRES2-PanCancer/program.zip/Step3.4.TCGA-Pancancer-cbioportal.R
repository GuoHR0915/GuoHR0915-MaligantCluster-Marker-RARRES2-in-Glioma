rm(list=ls())
options(stringsAsFactors = F)
setwd("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results")
##TCGA PanCancer Altas Studies
df1 <- read.table("cancer_types_summary-Cancer Study.txt",header = T,sep = "\t")
df1$Cancer.Study <- factor(df1$Cancer.Study,
                           levels = c("Adrenocortical Carcinoma (TCGA, PanCancer Atlas)",
                                      "Bladder Urothelial Carcinoma (TCGA, PanCancer Atlas)",
                                      "Breast Invasive Carcinoma (TCGA, PanCancer Atlas)",
                                      "Cervical Squamous Cell Carcinoma (TCGA, PanCancer Atlas)",
                                      "Cholangiocarcinoma (TCGA, PanCancer Atlas)",
                                      "Colorectal Adenocarcinoma (TCGA, PanCancer Atlas)",
                                      "Diffuse Large B-Cell Lymphoma (TCGA, PanCancer Atlas)",
                                      "Esophageal Adenocarcinoma (TCGA, PanCancer Atlas)",
                                      "Glioblastoma Multiforme (TCGA, PanCancer Atlas)",
                                      "Head and Neck Squamous Cell Carcinoma (TCGA, PanCancer Atlas)",
                                      "Kidney Chromophobe (TCGA, PanCancer Atlas)",
                                      "Kidney Renal Clear Cell Carcinoma (TCGA, PanCancer Atlas)",
                                      "Kidney Renal Papillary Cell Carcinoma (TCGA, PanCancer Atlas)",
                                      "Acute Myeloid Leukemia (TCGA, PanCancer Atlas)",
                                      "Brain Lower Grade Glioma (TCGA, PanCancer Atlas)",
                                      "Liver Hepatocellular Carcinoma (TCGA, PanCancer Atlas)",
                                      "Lung Adenocarcinoma (TCGA, PanCancer Atlas)",
                                      "Lung Squamous Cell Carcinoma (TCGA, PanCancer Atlas)",
                                      "Mesothelioma (TCGA, PanCancer Atlas)",
                                      "Ovarian Serous Cystadenocarcinoma (TCGA, PanCancer Atlas)",
                                      "Pancreatic Adenocarcinoma (TCGA, PanCancer Atlas)",
                                      "Pheochromocytoma and Paraganglioma (TCGA, PanCancer Atlas)",
                                       "Prostate Adenocarcinoma (TCGA, PanCancer Atlas)",
                                      "Sarcoma (TCGA, PanCancer Atlas)",
                                      "Skin Cutaneous Melanoma (TCGA, PanCancer Atlas)",
                                      "Stomach Adenocarcinoma (TCGA, PanCancer Atlas)",
                                      "Testicular Germ Cell Tumors (TCGA, PanCancer Atlas)",
                                      "Thyroid Carcinoma (TCGA, PanCancer Atlas)",
                                      "Thymoma (TCGA, PanCancer Atlas)",
                                      "Uterine Corpus Endometrial Carcinoma (TCGA, PanCancer Atlas)",
                                      "Uterine Carcinosarcoma (TCGA, PanCancer Atlas)",
                                      "Uveal Melanoma (TCGA, PanCancer Atlas)"),
                           labels = c("ACC","BLCA","BRCA","CESC","CHOL","CRC","DLBC","ESCA","GBM","HNSC",
                                      "KICH","KIRC","KIRP","LAML","LGG","LIHC","LUAD","LUSC","MESO",
                                      "OV","PAAD","PCPG","PRAD","SARC","SKCM","STAD",
                                      "TGCT","THCA","THYM","UCEC","UCS","UVM"))
tmp <- data.frame(Cancer.Study = levels(df1$Cancer.Study),
                  Alteration.Frequency = 0,
                  Alteration.Type = "amp",
                  Alteration.Count = 0)
df2 <- rbind(df1,tmp)
df2$Cancer.Type <- factor(df2$Cancer.Study,levels = levels(df1$Cancer.Study))
df2$Alteration.Type <- factor(df2$Alteration.Type,
                              levels = c("mutated","amp","homdel","multiple"),
                              labels = c("Mutation","Amplification",
                                         "Deep Deletion","Multiple Alteration"))
										 
library(ggplot2)
mytheme <- theme_bw() +
           theme(axis.text.x = element_text(angle = 40,hjust = 1,vjust = 1,size = 20),
                 axis.text.y = element_text(size = 20), 
                 axis.title.x = element_text(size = 20), 
                 axis.title.y = element_text(size = 20), 
                 plot.title = element_text(hjust = 0.5,size =  20),
                 plot.margin = margin(t = 10,  # 顶部边缘距离
                                      r = 40,  # 右边边缘距离
                                      b = 10,  # 底部边缘距离
                                      l = 10), # 左边边缘距离
                 legend.key = element_rect(fill = 'transparent'), 
                 legend.background = element_rect(fill = 'transparent'), 
                 legend.position = c(0.6,0.9),
                 legend.title = element_blank(),
                 legend.text = element_text(size = 20))
range(df2$Alteration.Frequency)
p <- ggplot(df2, aes(x = Cancer.Type,y = Alteration.Frequency, fill = Alteration.Type)) +
     geom_col(position = 'stack', width = 0.6) +
     scale_y_continuous(expand = c(0,0),limits = c(0,8), 
                     breaks = seq(0,7.5,1.5),labels = seq(0,7.5,1.5)) +
     scale_fill_manual(values = c("#459943","#db6968","#4d97cd","#606f8a"))+
     labs(title = NULL, x = NULL, y = "Alteration Frequency") +
     mytheme + guides(fill = guide_legend(nrow = 1, byrow = TRUE)) #调整图例为1行

df3 <- df2
df3$Cancer.Type <- factor(df3$Cancer.Type,
                          levels = c(as.character(unique(df1$Cancer.Study)),
                                    c("CESC","CHOL","DLBC","KICH","MESO",
									  "PCPG","TGCT","THCA","THYM")))
p2 <- ggplot(df3, aes(x = Cancer.Type,y = Alteration.Frequency, fill = Alteration.Type)) +
      geom_col(position = 'stack', width = 0.6) +
      scale_y_continuous(expand = c(0,0),limits = c(0,8), 
                         breaks = seq(0,7.5,1.5),labels = seq(0,7.5,1.5)) +
      scale_fill_manual(values = c("#459943","#db6968","#4d97cd","#606f8a"))+
      labs(title = NULL, x = NULL, y = "Alteration Frequency") +
      mytheme + guides(fill = guide_legend(nrow = 1, byrow = TRUE)) #调整图例为1行


pdf('./Step3.4.cbioportal-ggplot2.pdf',width = 12.5,height = 4)
p
p2
dev.off()
