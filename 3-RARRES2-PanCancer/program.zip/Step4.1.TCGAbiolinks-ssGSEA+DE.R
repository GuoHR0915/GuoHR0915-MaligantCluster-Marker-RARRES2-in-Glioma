rm(list=ls())
options(stringsAsFactors = F)
setwd("D:/data/TCGA/")
fs <- list.files('./TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
fs
library(GSVA)
set.seed(123456)
library(clusterProfiler)
###################################################################################
######################################ssGSEA#######################################
###################################################################################
Geneset <- rio::import("D:/bioinformatics/R/7 Immune cell infiltration/data/ssGSEA-PMID28052254-Signature-28.xlsx",skip = 2)
Geneset <- split(Geneset$Metagene,Geneset$`Cell type`)
lapply(Geneset[1:3], head)
set.seed(12345)
dat_list <- lapply(fs, function(x){
                      pro <- gsub('-GeneSymbol.Rdata','',x)
                      print(pro)
                      load(paste0("./TCGAbiolinks-EXP/",x))
                      dat <- log2(exp_TPM + 1)
                      print(dim(dat))
                      # mRNA_list <- ids_Gene[ids_Gene$gene_type %in% "protein_coding",]
                      # mRNA_int <- unique(intersect(rownames(dat),mRNA_list$gene_name))
                      # dat <- dat[mRNA_int,]
                      # print(dim(dat))
                      ##过滤正常样本
                      # Group = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2)
                      # print(table(Group))   
                      # exp_TPM <- exp_TPM[,as.numeric(Group) < 10]
  
                      ssGSEA_ES <- gsva(expr = dat, gset.idx.list = Geneset, 
                                        parallel.sz = 10, verbose = TRUE,
										method = 'ssgsea',kcdf = 'Gaussian') 
                      save(ssGSEA_ES,pro,file = paste0("./TCGAbiolinks-ssGSEA/ssGSEA-",pro,".Rdata"))
                      rm(dat)
                      rm(exp_TPM)
                      rm(exp_FPKM)
                      rm(exp_FPKM_UQ)
                      rm(exp_Count)
                      gc()
                      return(ssGSEA_ES)
})

Geneset <- rio::import("D:/bioinformatics/R/7 Immune cell infiltration/data/ssGSEA-PMID30594216-Signature-16+13.xlsx",skip = 1)
Geneset <- apply(Geneset,2,function(x){return(as.character(na.omit(as.character(x))))})
lapply(Geneset[1:3], head)
set.seed(12345)
dat_list <- lapply(fs, function(x){
                      pro <- gsub('-GeneSymbol.Rdata','',x)
                      print(pro)
                      load(paste0("./TCGAbiolinks-EXP/",x))
                      dat <- log2(exp_TPM + 1)
                      print(dim(dat))
                      # mRNA_list <- ids_Gene[ids_Gene$gene_type %in% "protein_coding",]
                      # mRNA_int <- unique(intersect(rownames(dat),mRNA_list$gene_name))
                      # dat <- dat[mRNA_int,]
                      # print(dim(dat))
                      ##过滤正常样本
                      # Group = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2)
                      # print(table(Group))   
                      # exp_TPM <- exp_TPM[,as.numeric(Group) < 10]
  
                      ssGSEA_ES <- gsva(expr = dat, gset.idx.list = Geneset, 
                                        parallel.sz = 10, verbose = TRUE,
										method = 'ssgsea',kcdf = 'Gaussian') 
                      save(ssGSEA_ES,pro,file = paste0("./TCGAbiolinks-ssGSEA/ssGSEA-2-",pro,".Rdata"))
                      rm(dat)
                      rm(exp_TPM)
                      rm(exp_FPKM)
                      rm(exp_FPKM_UQ)
                      rm(exp_Count)
                      gc()
                      return(ssGSEA_ES)
})

###################################################################################
######################################差异细胞#####################################
###################################################################################
rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
fs <- list.files('TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
Gene <- "RARRES2"
DEG <- lapply(fs,function(x){
      pro <- gsub('-GeneSymbol.Rdata','',x)
      print(pro)
	  load(paste0("./TCGAbiolinks-EXP/",x))
	  exprSet <- data.frame(Expression = as.numeric(exp_TPM[Gene,]),
                            Tumor_Patient_Barcode = substr(colnames(exp_TPM),1,12),
                            Tumor_Sample_Barcode = colnames(exp_TPM),
						    SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
						    SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3))
	  table(exprSet$SampleType2)
	  table(exprSet$SampleType)
	  ##保留A：
	  exprSet <- exprSet[exprSet$SampleType2 %in% "A",]
	  ##保留Primary：
	  exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
	  #exprSet$Group <- ifelse(exprSet$Expression > median(exprSet$Expression),"High","Low")
	  #table(exprSet$Group)
	  exprSet$Group <- "Median"
	  exprSet$Group[exprSet$Expression > quantile(exprSet$Expression,0.7)] <- "High"
	  exprSet$Group[exprSet$Expression < quantile(exprSet$Expression,0.3)] <- "Low"
	  exprSet <- exprSet[exprSet$Group != "Median",]
	  print(table(exprSet$Group))
	  exprSet$Group <- factor(exprSet$Group,levels = c("Low","High"))
      load(paste0("./TCGAbiolinks-ssGSEA/ssGSEA-",pro,".Rdata"))
	  SampleList <- intersect(colnames(ssGSEA_ES),exprSet$Tumor_Sample_Barcode)
	  ssGSEA_ES <- ssGSEA_ES[,SampleList]
	  
	  library(limma)
	  design <- model.matrix(~exprSet$Group)
	  fit <- lmFit(ssGSEA_ES, design)
	  fit <- eBayes(fit)
	  DEG <- topTable(fit, coef = 2, number = Inf)
	  DEG$Cancer <- strsplit(pro,"-")[[1]][2]
	  DEG$Celltype <- rownames(DEG)
	  head(DEG)
      return(DEG)
})

DEG_Merge <- data.frame(do.call(rbind,DEG))
head(DEG_Merge)
                                 # logFC   AveExpr        t      P.Value  adj.P.Val
# Natural killer cell         0.04702203 0.7314655 3.626647 0.0006793799 0.01055487
# Activated B cell            0.15755332 0.2976964 3.536754 0.0008922925 0.01055487
# Activated CD8 T cell        0.08847814 0.7477214 3.457720 0.0011308793 0.01055487
# Effector memeory CD8 T cell 0.05248810 0.7040107 3.207054 0.0023552626 0.01648684
# Type 1 T helper cell        0.04785174 0.6236091 2.949719 0.0048516960 0.02716950
# Central memory CD4 T cell   0.02793255 0.9078116 2.845667 0.0064372638 0.03004056
                                     # B Cancer                    Celltype
# Natural killer cell         -0.7340011    ACC         Natural killer cell
# Activated B cell            -0.9881308    ACC            Activated B cell
# Activated CD8 T cell        -1.2084671    ACC        Activated CD8 T cell
# Effector memeory CD8 T cell -1.8869369    ACC Effector memeory CD8 T cell
# Type 1 T helper cell        -2.5485994    ACC        Type 1 T helper cell
# Central memory CD4 T cell   -2.8053052    ACC   Central memory CD4 T cell
table(DEG_Merge$Cancer)
DEG_Merge$Pvalue <- -log10(DEG_Merge$P.Value)
range(DEG_Merge$logFC)#-0.08124482  0.22390563
#DEG_Merge$Celltype <- factor(DEG_Merge$Celltype,levels = rev(unique(DEG_Merge$Celltype)))
DEG_Merge$Celltype <- factor(DEG_Merge$Celltype,levels = rev(sort(unique(DEG_Merge$Celltype))))

library(ggplot2)
Dotplot <- ggplot(data = DEG_Merge,
                  aes(x = Cancer,y = Celltype,size = Pvalue)) +
           geom_point(shape = 21,aes(fill = logFC)) +
           scale_size_continuous(range = c(0,8), 
                                 name = bquote(" "~Log[10]~" Pvalue"),
                                 limits = c(0,30),
								 breaks = seq(0,30,10),
								 labels = seq(0,30,10)) +
           scale_fill_gradient2(low = "#0074b3", mid = "white", high = "red", 
                                name = bquote(" "~Log[2]~" Fold Change"),
                                limits = c(-0.224,0.224),
								midpoint = 0,
								breaks = round(seq(-0.2,0.2,0.1),2))+
           labs(title = NULL, x = NULL, y = NULL) +
           theme_minimal()+
           theme(panel.border = element_rect(fill = NA,color = "black", size = 1, linetype = "solid"),
                 panel.grid = element_blank(),
                 plot.title = element_text(hjust = 0.5,size = 20),
                 axis.ticks.y = element_blank(),
                 axis.title = element_blank(),
                 axis.text.x = element_text(angle = 45,hjust = 1, colour = 'black', size = 15),
                 axis.text.y = element_text(colour = 'black', size = 15),
                 plot.margin = unit(c(0.4,0.4,0.4,0.4),units = "cm"))      
Dotplot2 <- Dotplot + theme(legend.position = "bottom",
                            legend.text = element_text(color = "black",size = 18),
                            legend.title = element_text(size = 18,color = "black")) +
            guides(fill = guide_colorbar(title.position = "left",title.hjust = 0.5,
                                         barwidth = 15,barheight = 1.5,ticks = TRUE))
Dotplot2


DEG_Merge$Group <- ifelse(DEG_Merge$logFC > 0,"Up","Down")
library(ggplot2)
Dotplot <- ggplot(data = DEG_Merge,
                  aes(x = Cancer,y = Celltype,size = Pvalue,fill = Group)) +
           geom_point(shape = 21,color = "black") +
           scale_size_continuous(range = c(0,8), 
                                 name = bquote(" "~Log[10]~" Pvalue"),
                                 limits = c(0,30),
								 breaks = seq(0,30,10),
								 labels = seq(0,30,10)) +
           scale_fill_manual(values = alpha(c("#4d97cd","#c74546"),0.8)) +
           scale_color_manual(values = alpha(c("#4d97cd","#c74546"),0.8)) +
           labs(title = NULL, x = NULL, y = NULL) +
           theme_minimal()+
           theme(panel.border = element_rect(fill = NA,color = "black", size = 1, linetype = "solid"),
                 panel.grid = element_blank(),
                 plot.title = element_text(hjust = 0.5,size = 20),
                 axis.ticks.y = element_blank(),
                 axis.title = element_blank(),
                 axis.text.x = element_text(angle = 45,hjust = 1, colour = 'black', size = 15),
                 axis.text.y = element_text(colour = 'black', size = 15),
                 plot.margin = unit(c(0.4,0.4,0.4,0.4),units = "cm"))      
Dotplot3 <- Dotplot + theme(legend.position = "bottom",
                            legend.text = element_text(color = "black",size = 18),
                            legend.title = element_text(size = 18,color = "black"))
Dotplot3 +  guides(fill = guide_legend(override.aes = list(size = 7.5)))

pdf('D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step4.2.ssGSEA.pdf',
     width = 12,height = 10)
Dotplot2
Dotplot3 +  guides(fill = guide_legend(override.aes = list(size = 7.5)))
dev.off()




###Anti-tumor immunity vs. Pro-tumor suppression——计算score加和后

rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/data/TCGA") 
fs <- list.files('TCGAbiolinks-EXP/',pattern = 'GeneSymbol.Rdata')
Gene <- "RARRES2"
anti_tumor <- c('Activated CD4 T cell', 'Activated CD8 T cell', 'Central memory CD4 T cell', 
                'Central memory CD8 T cell', 'Effector memeory CD4 T cell', 'Effector memeory CD8 T cell',
                'Type 1 T helper cell', 'Type 17 T helper cell', 'Activated dendritic cell',
                'CD56bright natural killer cell', 'Natural killer cell', 'Natural killer T cell')
pro_tumor <- c('Regulatory T cell', 'Type 2 T helper cell', 'CD56dim natural killer cell',
               'Immature dendritic cell', 'Macrophage', 'MDSC', 'Neutrophil', 'Plasmacytoid dendritic cell')

Correlation <- lapply(fs,function(x){
      pro <- gsub('-GeneSymbol.Rdata','',x)
      print(pro)
	  load(paste0("./TCGAbiolinks-EXP/",x))
	  exprSet <- data.frame(Expression = as.numeric(exp_TPM[Gene,]),
                            Tumor_Patient_Barcode = substr(colnames(exp_TPM),1,12),
                            Tumor_Sample_Barcode = colnames(exp_TPM),
						    SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
						    SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3))
	  table(exprSet$SampleType2)
	  table(exprSet$SampleType)
	  ##保留A：
	  exprSet <- exprSet[exprSet$SampleType2 %in% "A",]
	  ##保留Primary：
	  exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09"),]
	  #exprSet$Group <- ifelse(exprSet$Expression > median(exprSet$Expression),"High","Low")
	  #table(exprSet$Group)
      load(paste0("./TCGAbiolinks-ssGSEA/ssGSEA-",pro,".Rdata"))
	  anti <- rownames(ssGSEA_ES) %in% anti_tumor
	  pro <- rownames(ssGSEA_ES) %in% pro_tumor

	  SampleList <- intersect(colnames(ssGSEA_ES),exprSet$Tumor_Sample_Barcode)
	  ssGSEA_ES <- ssGSEA_ES[,SampleList]
	  
	  anti <- as.data.frame(ssGSEA_ES[rownames(ssGSEA_ES) %in% anti_tumor,])
	  pro <- as.data.frame(ssGSEA_ES[rownames(ssGSEA_ES) %in% pro_tumor,])
	  anti_n <- apply(anti,2,sum)
	  pro_n <- apply(pro,2,sum)
      identical(names(anti_n),names(pro_n))
	  identical(exprSet$Tumor_Sample_Barcode,names(pro_n))
	  cor(anti_n,pro_n)
	  cor(exprSet$Expression,pro_n)
	  exprSet$anti_n <- as.numeric(anti_n)
	  exprSet$pro_n <- as.numeric(pro_n)
	  library(Hmisc)
	  Correlation <- rcorr(as.matrix(exprSet[,c("anti_n","pro_n","Expression")]),type = "spearman")
	  Correlation
	  print(pro)
	  print("R :")
	  print(Correlation$r[1:2,3])
	  print("Pvalue :")
	  print(Correlation$P[1:2,3])
	  return(c(Correlation$r[1:2,3],
               Correlation$P[1:2,3]))

})


Correlation <- do.call(rbind,Correlation)
rownames(Correlation) <- gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs))

##提取R与pvalue
m <- t(Correlation[,1:2])
head(m)
p <- t(Correlation[,3:4])
head(p)
range(m)#[1]  -0.1857143  0.5780083
library(dplyr)
tmp <- matrix(case_when(as.vector(p) < 0.001~"****",
                       as.vector(p) < 0.001~"***",
                       as.vector(p) < 0.01~"**",
                       as.vector(p) < 0.05~"*",
                       T~ ""),nrow = nrow(p))

####################使用ggplot2重新绘制：
Data_Checkpoint <- data.frame(t(m))
Data_Checkpoint$Cancer <- rownames(Data_Checkpoint) 
library(tidyverse)
dft <- Data_Checkpoint %>% pivot_longer(-Cancer)

##处理相关性矩阵
colnames(tmp) <- colnames(m)
rownames(tmp) <- rownames(m)
Data_Checkpoint_P <- data.frame(t(tmp))
Data_Checkpoint_P$Cancer <- rownames(Data_Checkpoint_P) 
dft_P <- Data_Checkpoint_P %>% pivot_longer(-Cancer)

dft$Cancer <- factor(dft$Cancer,levels = c(gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs)))) 
dft_P$Cancer <- factor(dft_P$Cancer,levels = c(gsub("TCGA-",'',gsub('-GeneSymbol.Rdata','',fs)))) 
range(dft$value,na.rm = T)#[1] -0.1857143  0.5780083
head(dft)


dft$name <- gsub("[.]","-",dft$name)
dft_P$name <- gsub("[.]","-",dft_P$name)
dft$name <- factor(dft$name,
                   levels = c("anti_n","pro_n"),
                   labels = c("Anti-tumor\nimmunity","Pro-tumor\nsuppression"))
dft_P$name <- factor(dft_P$name,
                     levels = c("anti_n","pro_n"),
                     labels = c("Anti-tumor\nimmunity","Pro-tumor\nsuppression"))
library(ggplot2)
library(paletteer)
library(ggthemes)
theme1 <- theme_minimal()+
          theme(panel.border = element_rect(fill = NA,size = 1, linetype = "solid"),
                panel.grid = element_blank(),
                axis.ticks.y = element_blank(),
                plot.title = element_text(hjust = 0.5,size = 22),
                axis.text.x = element_text(angle = 45,hjust = 1,size = 20),
                axis.text.y = element_text(size = 20))
Heatmap <- ggplot(data = dft,aes(x = Cancer,y = name)) +
           geom_tile(aes(fill = value),color = "grey") +
           geom_tile(aes(fill = value),color = "grey") +
           geom_text(data = dft_P,aes(x = Cancer,y = name,label = value),size = 6) +
           scale_x_discrete(expand = c(0,0)) + 
           scale_y_discrete(expand = c(0,0)) +
		   scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        name = NULL,midpoint = 0,
		                        limits = c(-0.58,0.58),breaks = seq(-0.4,0.4,0.2)) + 
           # scale_fill_paletteer_c("ggthemes::Classic Red-Blue",
                                  # direction = -1,
                                  # name="Correlation level",
                                  # limits = c(-0.5,0.7),
							      # breaks = seq(-0.4,0.6,0.2)) +
		   labs(title = NULL, x = NULL, y = NULL) + theme1		 
# ####拉长图例
Heatmap2 <- Heatmap + theme(legend.position = "right",
                            legend.text = element_text(color = "black",size = 20),
                            legend.title = element_blank())+
            guides(fill = guide_colorbar(title.position = "top",title.hjust = 0.5,
                                         barwidth = 1.5,barheight = 10,ticks = TRUE))
Heatmap2                           
                           
pdf("D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step4.1.Correlation-Immune Statue.pdf",
     height = 2.5,width = 15)
print(Heatmap2)
dev.off()



# gg <- ggplot(data,aes(x = anti, y = pro)) + 
      # xlim(-20,15) + ylim(-15,10) +
      # labs(x="Anti-tumor immunity", y="Pro-tumor suppression") +
      # geom_point(aes(color = patient),size=3) +
      # geom_smooth(method='lm') +
      # stat_cor(method = "spearman",size = 8) +
      # scale_colour_manual(values = RColorBrewer::brewer.pal(12, "Set3")) +
      # theme_bw() + 
      # theme(axis.text.x = element_text(size = 18), 
            # axis.text.y = element_text(size = 18), 
            # axis.title.x = element_text(size = 20), 
            # axis.title.y = element_text(size = 20),
            # legend.title = element_blank(),
            # legend.text=element_text(size=19))
# gg
