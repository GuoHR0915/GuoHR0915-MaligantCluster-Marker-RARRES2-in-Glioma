##cd /D/data/GTEx/RNA-seq
##head -3 GTEx_Analysis_2017-06-05_v8_RNASeQCv1.1.9_gene_tpm.gct >> RARRES2.txt
##grep "ENSG00000106538" GTEx_Analysis_2017-06-05_v8_RNASeQCv1.1.9_gene_tpm.gct >> RARRES2.txt
rm(list = ls())
options(stringsAsFactors = FALSE)
library(RColorBrewer)
library(ggplot2)
mytheme <- theme(axis.line = element_line(size = 1),
                 axis.title.x = element_text(size = 20),
				 axis.title.y = element_text(size = 20),
                 axis.text.x = element_text(size = 20),
                 axis.text.y = element_text(size = 20),
                 legend.position = "none",
                 #panel.grid = element_blank(),#删去网格线
                 #panel.border = element_blank(),panel.background = element_blank(),#删去外框
                 plot.title = element_text(size = 24,hjust = 0.5))
###########################################################################
###################################GTEx####################################
###########################################################################
setwd("D:/data/GTEx") 
library(data.table)
GTE_anno <- read.table("./phenotype/GTEx_Analysis_v8_Annotations_SampleAttributesDS.txt", header = TRUE, sep = "\t",quote = "")#GTE注释文件
#[1] 22951    63
table(GTE_anno$SMTS) 
table(GTE_anno$SMTSD) 

RARRES2_tpm <- read.table("./RNA-seq/RARRES2.txt", header = TRUE, sep = "\t",
                          quote = "",check.names = F)#,skip = 2
RARRES2_tpm <- data.frame(t(RARRES2_tpm))#[1]     1 17384
RARRES2_tpm$SAMPID <- rownames(RARRES2_tpm)
RARRES2_tpm <- RARRES2_tpm[-c(1:2),]
colnames(RARRES2_tpm)[1] <- "TPM"
RARRES2_tpm$TPM <- as.numeric(RARRES2_tpm$TPM)

GTEx_Plotdata <- merge(RARRES2_tpm,GTE_anno,by = "SAMPID")#[1] 17382    64
GTEx_Plotdata$TPM <- log2(GTEx_Plotdata$TPM+1)

p <- ggplot(GTEx_Plotdata, aes(x = SMTSD, y = TPM,fill = SMTS)) + 
	   geom_violin(position = position_dodge(width = 1), scale = 'width') +
	   geom_boxplot(position = position_dodge(width = 1), outlier.shape=NA, width = 0.25, alpha = 0.2)+
	   # scale_y_continuous(limits = c(0.5,7.5), breaks = seq(1,7,1),
	                      # labels = seq(1,7,1),expand = c(0,0)) +
	   scale_fill_manual(values = c(brewer.pal(9, "Set1") ,brewer.pal(12, "Paired"),
	                                brewer.pal(10, "Set3")))+
	   theme_bw()+
       mytheme+
	   labs(x = '',y = bquote("Relative Expression ("~Log[2]~" TPM)"),
	        title = "The Genotype-Tissue Expression")
p

# pdf('D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step1.2.GTEx.pdf',
    # width = 22,height = 12)
# p
# dev.off()	


p2 <- ggplot(GTEx_Plotdata, aes(x = SMTS, y = TPM,fill = SMTS)) + 
	   geom_violin(position = position_dodge(width = 1), scale = 'width') +
	   geom_boxplot(position = position_dodge(width = 1), outlier.shape=NA, width = 0.25, alpha = 0.2)+
	   scale_y_continuous(limits = c(-0.1,12), breaks = seq(0,12,2),
	                      labels = seq(0,12,2),expand = c(0,0)) +
	   scale_fill_manual(values = c(brewer.pal(9, "Set1") ,brewer.pal(12, "Paired"),
	                                brewer.pal(10, "Set3"))) +
	   theme_bw() +
       mytheme + 
	   labs(x = NULL,y = bquote("Relative Expression ("~Log[2]~" TPM)"),
	        title = "The Genotype-Tissue Expression")
p2 + coord_flip()


###########################################################################
####################################HAP####################################
###########################################################################
setwd("D:/data/Normal tissues/E-MTAB-1733(HPA)")
exprSet <- read.table("./FPKM_allsamples.txt", header = T,sep = "\t",check.names = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]
colnames(exprSet) <- gsub("[FPKM(]","",colnames(exprSet))
colnames(exprSet) <- gsub("[)]","",colnames(exprSet))
fpkmToTpm <- function(fpkm)
{
    exp(log(fpkm) - log(sum(fpkm)) + log(1e6))
}
TPMMatric <- apply(exprSet,2,function(x){fpkmToTpm(x)})


HPA_Plotdata <- data.frame(Expr = c(log2(as.numeric(TPMMatric["ENSG00000106538",])+1)),
				   Tissue = sapply(strsplit(colnames(exprSet),"_"),"[",1))
HPA_Plotdata$Tissue[HPA_Plotdata$Tissue == "lymphnode"] <- "lymph node"
HPA_Plotdata$Tissue[HPA_Plotdata$Tissue == "smallintestine"] <- "small intestine"
HPA_Plotdata$Tissue[HPA_Plotdata$Tissue == "urinarybladder"] <- "urinary bladder"
HPA_Plotdata$Tissue[HPA_Plotdata$Tissue == "bonemarrow"] <- "bone marrow"
HPA_Plotdata$Tissue[HPA_Plotdata$Tissue == "salivarygland"] <- "salivary gland"

library(stringr)
HPA_Plotdata$Tissue <- str_to_title(HPA_Plotdata$Tissue)
HPA_Plotdata$Tissue[HPA_Plotdata$Tissue == "Urinary Bladder"] <- "Bladder"
HPA_Plotdata$Tissue[HPA_Plotdata$Tissue == "Fat"] <- "Adipose Tissue"
HPA_Plotdata$Tissue[HPA_Plotdata$Tissue == "Adrenal"] <- "Adrenal Gland"

Tissue <- sort(unique(c(unique(HPA_Plotdata$Tissue),unique(GTEx_Plotdata$SMTS))))
HPA_Plotdata$Tissue <- factor(HPA_Plotdata$Tissue,levels = Tissue)
GTEx_Plotdata$SMTS <- factor(GTEx_Plotdata$SMTS,levels = Tissue)

Color <- alpha(c(brewer.pal(9, "Set1"),brewer.pal(8, "Set2"),
                 brewer.pal(10, "Set3"),brewer.pal(12, "Paired")),0.75)
as.numeric(sort(unique(GTEx_Plotdata$SMTS)))
as.numeric(sort(unique(HPA_Plotdata$Tissue)))

pHPA <- ggplot(HPA_Plotdata,aes(x = Tissue,y = Expr,fill = Tissue)) +
  stat_summary(fun = mean,geom = 'col',
               position = position_dodge2(),
               width = 0.9) +
  scale_fill_manual(values = Color[as.numeric(sort(unique(HPA_Plotdata$Tissue)))])+ 
  # 添加误差线
  stat_summary(fun = mean,geom = 'errorbar',
               color = 'black',
               position = position_dodge(width = 0.9),
               fun.max = function(x) mean(x) + sd(x) / sqrt(length(x)),
               fun.min = function(x) mean(x) - sd(x) / sqrt(length(x)),
               width = 0.3,size = 0.8) +
  # 添加抖动点
  geom_point(aes(color = Tissue),show.legend = F, # 不显示图例
             position = position_jitterdodge(seed = 123,jitter.width = 5.5,dodge.width = 0.9),
             shape = 21,size = 1.5,fill = 'white') +
  scale_color_manual(values = rep('black',27)) +
  scale_y_continuous(expand = c(0,0),limits = c(-0.1,12),breaks = seq(0,12,2)) +#
  labs(x = NULL, y = bquote("Relative Expression ("~Log[2]~" TPM)"),
       title = "Human Protein Atlas")+
  theme_bw() + mytheme
pHPA

pGTEx <- ggplot(GTEx_Plotdata, aes(x = SMTS, y = TPM,fill = SMTS)) + 
	     geom_violin(position = position_dodge(width = 1), scale = 'width') +
	     geom_boxplot(position = position_dodge(width = 1), outlier.shape=NA, width = 0.25, alpha = 0.2)+
	     scale_y_continuous(expand = c(0,0),limits = c(-0.1,12),breaks = seq(0,12,2)) +#
	     scale_fill_manual(values = Color[as.numeric(sort(unique(GTEx_Plotdata$SMTS)))])+
	     theme_bw() +
	     mytheme +
	     labs(x = NULL,y = bquote("Relative Expression ("~Log[2]~" TPM)"),
	          title = "The Genotype-Tissue Expression")
pGTEx


pdf('D:/Temp/3-Pan-cancer/4-RARRES2-TCGAbiolinks/results/Step1.2.GTEx + HPA Normal-2.pdf',
    height = 12,width = 7.5)
pHPA + coord_flip()
pGTEx + coord_flip()
dev.off()	
