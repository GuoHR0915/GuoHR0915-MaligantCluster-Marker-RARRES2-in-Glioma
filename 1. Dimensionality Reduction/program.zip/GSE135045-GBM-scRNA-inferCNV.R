rm(list = ls())
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
##########################################################################################
######################################数据准备############################################
##########################################################################################
library(Seurat)##4.1.3
sce.all <- readRDS("./data/GSE135045_RAW/sce.all_Annotation.rds")
Idents(sce.all) <- 'Cluster'

expFile <- 'expFile.txt'
groupFiles <- 'groupFiles.txt'
geneFile <- 'geneFile.txt'
#####提取表达矩阵
dat <- GetAssayData(sce.all,slot = 'counts',assay = 'RNA')
dat[1:4,1:4]
dat[grep("HLA-",rownames(dat)),1:4]
dat <- dat[-grep("HLA-",rownames(dat)),]
#####提取细胞分组
groupinfo <- data.frame(v1 = colnames(dat),
                        v2 = Idents(sce.all))
head(groupinfo)
#groupinfo <- groupinfo[groupinfo$v2 %in% c("C2","C3","C4","C5","C6","C8","C7"),]
table(groupinfo$v2)
head(groupinfo)

dat <- dat[,colnames(dat) %in% groupinfo$v1]
dat[1:4,1:4]

#####提取基因位置
#从gtf 文件提取
load("D:/data/RefGene/Huamn.GRCh38.hg38.v38.Rdata")
#load("Huamn.GRCh38.hg38.v38.Rdata")
geneInfor <- geneInfor[geneInfor$SYMBOL %in% rownames(dat),]
geneInfor <- geneInfor[order(geneInfor$chr, geneInfor$start,geneInfor$end),]
geneInfor <- geneInfor[!duplicated(geneInfor[,1]),]

dat <- dat[rownames(dat) %in% geneInfor[,1],]
dat <- dat[match(geneInfor[,1], rownames(dat)),] 
dim(dat)
head(groupinfo)
dat[1:4,1:4]
as_matrix <- function(mat){
# mat, Matrix obj
  tmp <- matrix(data=0L, nrow = mat@Dim[1], ncol = mat@Dim[2])
  
  row_pos <- mat@i+1
  col_pos <- findInterval(seq(mat@x)-1,mat@p[-1])+1
  val <- mat@x
    
  for (i in seq_along(val)){
      tmp[row_pos[i],col_pos[i]] <- val[i]
  }
    
  row.names(tmp) <- mat@Dimnames[[1]]
  colnames(tmp) <- mat@Dimnames[[2]]
  return(tmp)
}
Rawcount <- as_matrix(dat)
Rawcount[1:4,1:4]

ls()
rm(dat)
rm(sce.all)
gc()

setwd("./results/scRNA-GSE135045/infercnv_output")
write.table(Rawcount,file = expFile,sep = '\t',quote = F)

write.table(groupinfo,file = groupFiles,sep = '\t',quote = F,col.names = F,row.names = F)
write.table(geneInfor,file = geneFile,sep = '\t',quote = F,col.names = F,row.names = F)
rm(groupinfo)
rm(geneInfor)
gc()
##########################################################################################
####################################二步法分析############################################
##########################################################################################
rm(list = ls())
library(infercnv)###R  4.1.0
packageVersion("infercnv")###[1] ‘1.10.1’
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
setwd("./results/scRNA-GSE135045/infercnv_output")
expFile='expFile.txt'
groupFiles='groupFiles.txt'
geneFile='geneFile.txt'

infercnv_obj <- CreateInfercnvObject(raw_counts_matrix = expFile,
                                     annotations_file = groupFiles,
                                     delim = "\t",
                                     gene_order_file = geneFile,
                                     ref_group_names = c("C7"))
# cutoff=1 works well for Smart-seq2, and 
# cutoff=0.1 works well for 10x Genomics
infercnv_obj2 <- infercnv::run(infercnv_obj,
                               cutoff = 1,#对于Smart-seq最优cutoff=1，对于10X数据，最优cutoff=0.1 
                               denoise = TRUE,#去噪
                               out_dir = "./",  
                               cluster_by_groups = T,   # cluster
                               hclust_method = "ward.D2",
                               HMM = FALSE)# 是否基于HMM预测CNV

# outdir="/home/weixiangyu/20204250053/scRNA-seq/inferCNV/infercnv_output/"
# infercnv_obj2 = infercnv::run(infercnv_obj,
                              # cutoff=1,#对于Smart-seq最优cutoff=1，对于10X数据，最优cutoff=0.1 
                              # denoise=TRUE,#去噪
                              # out_dir=outdir,  
                              # cluster_by_groups=TRUE,   # cluster
                              # hclust_method="ward.D2",
							  # analysis_mode = "samples",
							  # num_threads=5,#默认为4
							  # write_expr_matrix=TRUE,#‘1.10.1’没有此参数
                              # HMM=FALSE)# 是否基于HMM预测CNV


#################################################################################
####################################结果可视化###################################
#################################################################################
###############################CNV score-5分类系统###############################
##读取infercnv.observations.txt文件来计算CNV score——非官方教程
rm(list=ls())
options(stringsAsFactors = F)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
tmp=read.table("./results/scRNA-GSE135045/infercnv_output/infercnv.references.txt", header = T)
down = mean(rowMeans(tmp)) - 2 * mean( apply(tmp, 1, sd))
up = mean(rowMeans(tmp)) + 2 * mean( apply(tmp, 1, sd))
oneCopy = up-down
oneCopy#
a1 = down- 2*oneCopy
a2 = down- 1*oneCopy
down;up#
a3 = up +  1*oneCopy 
a4 = up + 2*oneCopy 

cnv_table <- read.table("./results/scRNA-GSE135045/infercnv_output/infercnv.observations.txt", header=T)
# Score cells based on their CNV scores 
# Replicate the table 
cnv_score_table <- as.matrix(cnv_table)
cnv_score_mat <- as.matrix(cnv_table)
# Scoring
# CNV的5分类系统
cnv_score_table[cnv_score_mat > 0 & cnv_score_mat < a2] <- "A" #complete loss. 2pts
cnv_score_table[cnv_score_mat >= a2 & cnv_score_mat < down] <- "B" #loss of one copy. 1pts
cnv_score_table[cnv_score_mat >= down & cnv_score_mat <  up ] <- "C" #Neutral. 0pts
cnv_score_table[cnv_score_mat >= up  & cnv_score_mat <= a3] <- "D" #addition of one copy. 1pts
cnv_score_table[cnv_score_mat > a3  & cnv_score_mat <= a4 ] <- "E" #addition of two copies. 2pts
cnv_score_table[cnv_score_mat > a4] <- "F" #addition of more than two copies. 2pts

# Check
table(cnv_score_table[,1])
# Replace with score 
cnv_score_table_pts <- cnv_table
rm(cnv_score_mat)
#  把5分类调整为 3分类系统
cnv_score_table_pts[cnv_score_table == "A"] <- 2
cnv_score_table_pts[cnv_score_table == "B"] <- 1
cnv_score_table_pts[cnv_score_table == "C"] <- 0
cnv_score_table_pts[cnv_score_table == "D"] <- 1
cnv_score_table_pts[cnv_score_table == "E"] <- 2
cnv_score_table_pts[cnv_score_table == "F"] <- 2

# Scores are stored in “cnv_score_table_pts”. Use colSums to add up scores for each cell and store as vector 
cell_scores_CNV <- as.data.frame(colSums(cnv_score_table_pts))
colnames(cell_scores_CNV) <- "cnv_score"
head(cell_scores_CNV)

#write.csv(x = cell_scores_CNV, file = "inferCNV-scores.csv")

##与Seurat对象合并画图：
# 除去了reference后的走inferCNV的细胞
library(data.table)
sce.meta <- data.frame(fread("./results/scRNA-GSE135045/metadata.txt"))
head(sce.meta)
table(sce.meta$celltype)

sce.meta <- sce.meta[sce.meta$celltype %in% c("Malignant cell","Oligodendrocyte"),]
rownames(sce.meta) <- sce.meta$V1
table(sce.meta$celltype)

phe <- sce.meta
head(rownames(phe))
head(rownames(cell_scores_CNV)) 

phe=phe[rownames(phe) %in% rownames(cell_scores_CNV),]
phe = phe[match(rownames(cell_scores_CNV),rownames(phe)),]
identical(rownames(phe),rownames(cell_scores_CNV))

CNVScore <- data.frame(Cluster = phe$Cluster,
                       Celltype = phe$celltype,
					   CNV_score = cell_scores_CNV$cnv_score)
rownames(CNVScore) <- rownames(phe)						 
library(ggsci)
library(ggplot2)
theme <- theme_bw()+ #背景变为白色
         theme(plot.title = element_text(hjust = 0.5),
		       axis.text.x=element_text(hjust = 0.5,colour="black",size=14), 
		       axis.text.y=element_text(size=14),
		       axis.title.y=element_text(size = 16), 
		       axis.line = element_line(colour = "black",size=1), 
		       legend.text=element_text(colour="black",size=14),
		       legend.title=element_text(colour="black",size=15),
		       legend.position="none")
table(CNVScore$Cluster)
p_CNVScore <- 
     ggplot(CNVScore,aes(x=Cluster, y=CNV_score,fill=Cluster)) + 
     geom_violin(trim=FALSE,color="white") + 
	 geom_boxplot(width=0.2,position=position_dodge(0.9),outlier.shape=NA)+
     #scale_fill_nejm() + 
     scale_y_continuous(limits = c(0,350),expand = c(0,0),breaks = seq(0,350,50))+
	 scale_fill_lancet(alpha = 0.6) + 
	 theme + 
     labs(title="",x="", y = "CNV Scores (inferCNV)")
p_CNVScore
plevel <- p_CNVScore+ggpubr::stat_compare_means(method = "anova",label.x = 4.6,label.y = 300,size = 6)
plevel

# pdf("Boxplot-CNVScore-inferCNV.pdf",width = 6,height= 6)
# p2
# dev.off()

#################################CNV score-平方和##############################
##读取infercnv.observations.txt文件来计算CNV score——非官方教程
rm(list = ls())
options(stringsAsFactors = F)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
references <- read.table("./results/scRNA-GSE135045/infercnv_output/infercnv.references.txt", header=T)
referencesMeans <- mean(rowMeans(references))

cnv_table <- read.table("./results/scRNA-GSE135045/infercnv_output/infercnv.observations.txt", header=T)
# Score cells based on their CNV scores 
CNVscore <- apply(cnv_table,2,function(x){sum(unlist(lapply(x,function(i)(i-referencesMeans)^2)))})
CNVscore <- data.frame(CNVscore = as.numeric(CNVscore),
                       CellName = names(CNVscore))
##与Seurat对象合并画图：
# 除去了reference后的走inferCNV的细胞
library(data.table)
sce.meta <- data.frame(fread("./results/scRNA-GSE135045/metadata.txt"))
head(sce.meta)
table(sce.meta$celltype)

sce.meta <- sce.meta[sce.meta$celltype %in% c("Malignant cell","Oligodendrocyte"),]
rownames(sce.meta) <- sce.meta$V1
table(sce.meta$celltype)

phe <- sce.meta
head(phe)
identical(rownames(phe),CNVscore$CellName)
table(rownames(phe) %in% CNVscore$CellName)
table(CNVscore$CellName %in% rownames(phe))
CNVscore <- CNVscore[which(CNVscore$CellName %in% rownames(phe)),]
phe <- phe[rownames(phe) %in% CNVscore$CellName,]
phe <- phe[match(CNVscore$CellName,rownames(phe)),]
identical(rownames(phe),CNVscore$CellName)

CNVScore <- cbind(phe,CNVscore)
table(CNVScore$Cluster)
CNVScore$Cluster <- factor(CNVScore$Cluster,levels = paste0("C",0:10))
my36colors <-c('#E5D2DD', '#53A85F', '#F1BB72', '#F3B1A0', '#D6E7A3', '#57C3F3', 
               '#476D87', '#E95C59', '#E59CC4', '#AB3282', '#23452F', '#BD956A', 
               '#8C549C', '#585658', '#9FA3A8', '#E0D4CA', '#5F3D69', '#C5DEBA', 
               '#58A4C3', '#E4C755', '#F7F398', '#AA9A59', '#E63863', '#E39A35', 
               '#C1E6F3', '#6778AE', '#91D0BE', '#B53E2B', '#712820', '#DCC1DD', 
               '#CCE0F5',  '#CCC9E6', '#625D9E', '#68A180', '#3A6963', '#968175')

library(ggsci)
library(ggplot2)
theme <- theme_bw()+ #背景变为白色
         theme(plot.title = element_text(hjust = 0.5),
		       axis.text.x = element_text(hjust = 0.5,size = 18), 
		       axis.text.y = element_text(size = 16),
		       axis.title.y = element_text(size = 18), 
		       axis.line = element_line(size = 1), 
		       legend.text = element_text(size = 14),
		       legend.title = element_text(size = 15),
		       legend.position = "none")
p_CNVScore <- ggplot(CNVScore,aes(x = Cluster, y = CNVscore,fill = Cluster)) + 
              geom_violin(trim = FALSE,scale = "width",color = "white") + 
              geom_boxplot(width = 0.3,
			               position = position_dodge(0.9),
			               outlier.shape = NA)+
              scale_fill_manual(values = my36colors[-c(10:11)])+ 
              scale_y_continuous(expand = c(0,0),limits = c(-0.5,31),
			                     breaks = seq(0,30,3))+
              #scale_fill_lancet(alpha = 0.6) + 
              theme + 
              labs(title = NULL,x = NULL, y = "CNV Score")
p_CNVScore
psquare <- p_CNVScore + ggpubr::stat_compare_means(method = "anova",label.x = 4.6,label.y = 24,size = 6)
psquare

pdf("./results/scRNA-GSE135045/Boxplot-CNVScore-inferCNV.pdf",width = 7.5,height = 4)
p_CNVScore
dev.off()

