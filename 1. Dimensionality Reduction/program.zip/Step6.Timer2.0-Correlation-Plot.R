rm(list = ls())
options(stringsAsFactors = F)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
library(readxl) 
CorrelationMerge <- read_excel("./results/step6.Timer2.0.xlsx")
CorrelationMerge$x <- paste0(CorrelationMerge$Gene,CorrelationMerge$DataSet)
CorrelationMerge$R <- as.numeric(CorrelationMerge$R)
CorrelationMerge$Pvalue <- as.numeric(CorrelationMerge$Pvalue)

CorrelationMerge$Pvalue[CorrelationMerge$Pvalue < 10^(-10)] <- 10^(-10)
range(CorrelationMerge$R)#-0.4502107  0.5085536
range(-log10(CorrelationMerge$Pvalue))# 5.629373e-04 1.000000e+01
CorrelationMerge$Pvalue <- -log10(CorrelationMerge$Pvalue)
range(CorrelationMerge$Pvalue)# 5.629373e-04 1.000000e+01

Example1 <- c("B cell","T CD8+ cell","T CD4+ cell","Treg","Tfh","yδT","NK")
Example2 <- c("Neutrophil","Eosinophil","Dendritic cell",
              "Monocyte","M1 Macrophage","M2 Macrophage","Mast cell")
library(ggplot2)
Dotplot <- ggplot(data = CorrelationMerge[CorrelationMerge$CellType %in% Example1,],
                  aes(x = x,y = CellName,size = Pvalue)) +
           geom_point(shape = 21,aes(fill = R),position = position_dodge(0)) +
           scale_size_continuous(range = c(0,7.5), name = "-log10 Pvalue",
		                         limits = c(0,10),breaks = seq(0,10,2),labels = seq(0,10,2)) +
           scale_fill_gradient(low = "#498EA4", high = "#E54924", name = "Correlation",
		                       limits = c(-0.6,0.6),breaks = seq(-0.6,0.6,0.3)) +
		   # scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        # name = "Correlation",
		                        # limits = c(-0.8,0.82),midpoint = 0,breaks = seq(-0.8,0.8,0.4))+
		   labs(title = NULL, x = NULL, y = NULL) +
		   theme_minimal()+
		   theme(panel.border = element_rect(fill = NA,size = 1, linetype = "solid"),
                 panel.grid = element_blank(),
				 plot.title = element_text(hjust = 0.5,size = 20),
                 axis.ticks.y = element_blank(),
                 axis.title = element_blank(),
                 axis.text.x = element_blank(),
                 axis.text.y = element_text(colour = 'black', size = 14))					  
								  
####拉长图例
Dotplot1 <- Dotplot + theme(legend.position = "right",
                            legend.text = element_text(color = "black",size = 14),
                            legend.title = element_text(size = 16,color = "black")) +
            guides(fill = guide_colorbar(title.position = "top",title.hjust = 0.5,
                                         barwidth = 1.5,barheight = 15,ticks = TRUE))
Dotplot1
	
Dotplot <- ggplot(data = CorrelationMerge[CorrelationMerge$CellType %in% Example2,],
                  aes(x = x,y = CellName,size = Pvalue)) +
           geom_point(shape = 21,aes(fill = R),position = position_dodge(0)) +
           scale_size_continuous(range = c(0,7.5), name = "-log10 Pvalue",
		                         limits = c(0,10),breaks = seq(0,10,2),labels = seq(0,10,2)) +
           scale_fill_gradient(low = "#498EA4", high = "#E54924", name = "Correlation",
		                       limits = c(-0.6,0.6),breaks = seq(-0.6,0.6,0.3)) +
		   # scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        # name = "Correlation",
		                        # limits = c(-0.8,0.82),midpoint = 0,breaks = seq(-0.8,0.8,0.4))+
		   labs(title = NULL, x = NULL, y = NULL) +
		   theme_minimal()+
		   theme(panel.border = element_rect(fill = NA,size = 1, linetype = "solid"),
                 panel.grid = element_blank(),
				 plot.title = element_text(hjust = 0.5,size = 20),
                 axis.ticks.y = element_blank(),
                 axis.title = element_blank(),
                 axis.text.x = element_blank(),
                 axis.text.y = element_text(colour = 'black', size = 14))					  
								  
####拉长图例
Dotplot2 <- Dotplot + theme(legend.position = "right",
                            legend.text = element_text(color = "black",size = 14),
                            legend.title = element_text(size = 16,color = "black")) +
            guides(fill = guide_colorbar(title.position = "top",title.hjust = 0.5,
                                         barwidth = 1.5,barheight = 15,ticks = TRUE))
Dotplot2	


#############分组注释
DataSet <- c("TCGA-GBM","TCGA-LGG","TCGA-GBM","TCGA-LGG","TCGA-GBM","TCGA-LGG")
Group <- data.frame(Sample_id = unique(CorrelationMerge$x),
                    Yaxis = "Annotation",
					Gene = rep(c("IGFBP2","MDK","RARRES2"),each = 2),
                    DataSet = factor(DataSet,levels = unique(DataSet)))
Group$Sample_id <- factor(Group$Sample_id,levels = unique(CorrelationMerge$x))
Group
theme <- theme_void()+
         theme(panel.border = element_blank(),
		       # plot.margin=unit(c(0.4,0.4,0.4,0.4),units=,"cm"),
		       panel.grid = element_blank(),
               legend.background=element_blank(),
               legend.text = element_text(size = 18),
               legend.title = element_text(size = 18))  
library(RColorBrewer)
Group1 <- ggplot(data = Group,aes(Sample_id,Yaxis,fill = DataSet)) +
          geom_tile() +
		  scale_x_discrete(expand = c(0,0)) +
          scale_y_discrete(expand = c(0,0)) +
          scale_fill_manual(values = alpha(brewer.pal(9,"Set1")[4:7],0.75)) + theme
Group1
Group2 <- ggplot(data = Group,aes(Sample_id,Yaxis,fill = Gene)) +
          geom_tile() +
		  scale_x_discrete(expand = c(0,0)) +
          scale_y_discrete(expand = c(0,0)) +
          scale_fill_manual(values = alpha(brewer.pal(9,"Set1")[1:3],0.75)) + theme
Group2
library(patchwork) 
pMerge1 <- (Group2  + Group1 + Dotplot1) + 
            plot_layout(heights = c(0.02,0.02,1.2),ncol = 1,guides = 'collect') & theme(legend.position = "right")
pMerge1
pMerge2 <- (Group2  + Group1 + Dotplot2) + 
            plot_layout(heights = c(0.03,0.03,1.2),ncol = 1,guides = 'collect') & theme(legend.position = "right")
pMerge2
pdf("./results/step6.Timer-Dotplot-1.pdf",height = 59/4,width = 8)
pMerge1
dev.off()   
pdf("./results/step6.Timer-Dotplot-2.pdf",height = 38/4,width = 8)
pMerge2
dev.off()  