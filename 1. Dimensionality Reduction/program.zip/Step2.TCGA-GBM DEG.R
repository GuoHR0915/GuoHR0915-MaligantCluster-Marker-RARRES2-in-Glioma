rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
##################################################################################################
#############################################数据准备#############################################
##################################################################################################
# load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-GBM-GeneSymbol.Rdata')
# load(file = "./Step2.Riskmodel.Rdata")
load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-GBM-GeneSymbol.Rdata')
exprSet <- data.frame(SampleNames = colnames(exp_Count),
                      SampleType = substr(sapply(strsplit(colnames(exp_Count),'-'),"[",4),1,3))
table(exprSet$SampleType)
# 01A 01B 01C 02A 02B 11A 
# 146  10   1  12   1   5 
exprSet <- exprSet[exprSet$SampleType %in% c("01A","11A"),]
exprSet$PatientNames <- substr(exprSet$SampleNames,1,12)
table(exprSet$SampleType)

exp_mRNA_Count <- exp_Count[unique(ids_Gene[ids_Gene$gene_type == "protein_coding","gene_name"]),
                            exprSet$SampleNames]
identical(colnames(exp_mRNA_Count),exprSet$SampleNames)
dim(exp_mRNA_Count)#[1] 19938

###分组
exprSet$Group <- ifelse(substr(exprSet$SampleType,1,2) > 10,"Normal","Tumor")
table(exprSet$Group)
# Normal  Tumor 
     # 5    146 
##################################################################################################
#############################################差异分析#############################################
##################################################################################################
group_list <- exprSet$Group
minRow <- rowMeans(exp_mRNA_Count) > 1  #按平均数筛选 
minNum <- rowSums(exp_mRNA_Count > 0) > (0.8*ncol(exp_mRNA_Count)) #表达量不为0的样品个数筛选 
#minNum <- rowSums(exp_mRNA_Count > 0) >= (1*ncol(exp_mRNA_Count))
exp_mRNA_Count <- exp_mRNA_Count[minRow & minNum,]
dim(exp_mRNA_Count)#[1]16682   151

############################DESeq2
library(DESeq2)
##设置分组信息并构建dds对象
database <- exp_mRNA_Count
condition <- factor(group_list, levels = c("Normal","Tumor"))
coldata <- data.frame(row.names = colnames(database), condition)
dds <- DESeqDataSetFromMatrix(countData = database, colData = coldata, design=~condition)

##使用DESeq函数估计离散度，然后差异分析获得res对象
dds <- DESeq(dds)
res <- results(dds)

#筛选差异基因
resOrdered <- res[order(res$padj),]
head(resOrdered)
DESeq2_DEG = na.omit(as.data.frame(resOrdered))
head(DESeq2_DEG)
        # baseMean log2FoldChange     lfcSE     stat       pvalue         padj
# RRM2   2485.7797       6.834824 0.4054482 16.85745 9.248923e-64 1.537264e-59
# TOP2A  5084.3503       7.236276 0.4681256 15.45798 6.665541e-54 5.539398e-50
# UBE2C  1651.2834       7.340734 0.4884396 15.02895 4.744685e-51 2.628714e-47
# MYBL2  2035.4349       7.685296 0.5204542 14.76652 2.408404e-49 8.336109e-46
# PBK    1264.3781       7.267402 0.4922449 14.76379 2.507704e-49 8.336109e-46
# KIF20A  803.5733       6.675782 0.4533330 14.72600 4.389281e-49 1.215904e-45
# DEG = DESeq2_DEG[,c(2,6)]
# colnames(DEG) = c('log2FoldChange','padj')
# head(DEG)

# 设定阈值，筛选显著上下调差异基因
logFC <- log2(1.5)
Pvalue <- 0.05
DESeq2_DEG$Group <- ifelse(DESeq2_DEG$log2FoldChange > logFC & DESeq2_DEG$padj < Pvalue,"Up",
                               ifelse(DESeq2_DEG$log2FoldChange < -logFC & DESeq2_DEG$padj < Pvalue,
                                      "Down","Stable"))
table(DESeq2_DEG$Group)
# Down Stable     Up 
# 3997   8073   4551 

#输出差异结果
# write.csv(DESeq2_DEG,file = "./results/Step2.TCGA_diff.csv",quote = F)
# save(DESeq2_DEG,file = "./results/Step2.TCGA_diff.Rdata")

# #绘制差异基因热图
# diffSig_up <- DESeq2_DEG[DESeq2_DEG$Group == "Up",]
# diffSig_down <- DESeq2_DEG[DESeq2_DEG$Group == "Down",]
# hmExp <- exp_TPM[c(rownames(diffSig_up),rownames(diffSig_down)),]
# ind1 <- colnames(exprSet_filted)[Group == "Low"]
# ind2 <- colnames(exprSet_filted)[Group == "High"]
# hmExp <- cbind(hmExp[,ind1],hmExp[,ind2])
# hmExp <- t(scale(t(hmExp)))

# Type <- c(rep("Low",table(Group)["Low"]),rep("High",table(Group)["High"]))
# names(Type) <- colnames(hmExp)
# Type <- as.data.frame(Type)

# hmExp[hmExp > 2] = 2
# hmExp[hmExp < -2] = -2
# library(pheatmap)
# pdf(file="./results/Step3.DEG/TCGA_heatmap.pdf",height = 8,width = 10)
# pheatmap(hmExp, 
         # annotation=Type, 
         # color = colorRampPalette(c("green", "black", "red"))(50),
         # cluster_cols = F,cluster_rows = F ,
         # show_colnames = F,show_rownames = F)
# dev.off()


#绘制火山图
library(ggplot2)
mytheme <- theme_bw() + 
           theme(legend.key = element_rect(fill = 'transparent'), 
                 legend.background = element_rect(fill = 'transparent'), 
                 legend.position = c(0.15, 0.85),
                 legend.title = element_blank(),
                 legend.text = element_text(size = 20,margin = margin(t = 6)), 
                 axis.text.x = element_text(hjust = 0.5,size = 18), 
                 axis.text.y = element_text(size = 18), 
                 axis.title.x = element_text(size = 20), 
                 axis.title.y = element_text(size = 20), 
                 axis.line = element_line(size = 1),
                 plot.title = element_text(size = 24, hjust = 0.5))
DESeq2_DEG$Group <- factor(DESeq2_DEG$Group,levels = c("Down","Stable","Up"))
p <- ggplot(DESeq2_DEG, aes(log2FoldChange, -log10(padj)))+
     geom_point(aes(col = Group))+
     labs(x = bquote(~Log[2]~"(fold change)"), 
          y = bquote(~-Log[10]~italic("Adjust P-value")),
		  title = NULL) +
     scale_colour_manual(name = NULL, values = alpha(c("#2DB2EB","#d8d8d8","#EB4232"), 0.7)) + 
     scale_x_continuous(expand = c(0, 0),limits = c(-12, 12),breaks = seq(-12,12,by = 4)) + 
     scale_y_continuous(expand = c(0, 0),limits = c(0, 60),breaks = seq(0,60,by = 10)) + 
     geom_hline(yintercept = c(-log10(0.05)),size = 0.7,color = "black",lty = "dashed") + 
     geom_vline(xintercept = c(-log2(1.5), log2(1.5)),size = 0.7,color = "black",lty = "dashed") + 
	 geom_vline(xintercept = c(-1, 1),size = 0.7,color = "black",lty = "dashed") + 
	 guides(color = guide_legend(override.aes = list(size = 5))) + mytheme 
p
pdf("./Step3.TCGA_volcano.pdf",width = 5.5,height = 5)
print(p)
dev.off()


Gene <- c("IGFBP2","MDK","RARRES2")

library(ggrepel)
##geom_text_repel()
Label <- DESeq2_DEG[c("IGFBP2","MDK","RARRES2"),]
Label$Symbol <- rownames(Label)
p2 <- p + 
      geom_point(data = Label,aes(x = log2FoldChange, y = -log10(padj)),
                 color = '#e8c559', size = 5.5, alpha = 0.85) +#强调显示一下需要标注的散点,增加更大尺寸散点套在外围
      geom_label_repel(data = Label,aes(x = log2FoldChange, y = -log10(padj), label = Symbol),
                       seed = 12345,color = 'black',show.legend = FALSE, 
                       min.segment.length = 0,#始终为标签添加指引线段；若不想添加线段，则改为Inf
                       segment.linetype = 1, #线段类型,1为实线,2-6为不同类型虚线
                       force = 2,#重叠标签间的排斥力
                       force_pull = 2,#标签和数据点间的吸引力
                       size = 8,
                       box.padding = unit(2, "lines"),
                       point.padding = unit(2, "lines"),
                       max.overlaps = Inf)#排斥重叠过多标签，设置为Inf则可以保持始终显示所有标签
p2
pdf("./results/Step2.TCGA_volcano.pdf",width = 5.5,height = 5)
print(p)
print(p2)
dev.off()
