rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
########################################################################
###############################数据准备#################################
########################################################################
library(readxl)
Drug <- read_excel(path = "D:/data/Drug sensitive/DTP_NCI60_ZSCORE/DTP_NCI60_ZSCORE.xlsx", skip = 8)
Drug <- Drug[,-c(67,68)]
# 筛选药物标准
table(Drug$`FDA status`)
#             - Clinical trial   FDA approved 
#         23993            546            314 

# 选取经过临床试验（Clinical trial）和FDA批准（FDA approved）的药物结果
Drug <- Drug[Drug$`FDA status` %in% c("FDA approved", "Clinical trial"),]
Drug <- Drug[,-c(1, 3:6)]#[1] 860  61
data.frame(Drug[1:6,1:6])
#         Drug.name BR.MCF7 BR.MDA.MB.231 BR.HS.578T BR.BT.549 BR.T.47D
#1     METHOTREXATE     0.7         -1.22      -1.89     -0.88    -1.16
#2    6-THIOGUANINE    0.48         -0.31      -1.09     -0.44    -0.06
#3 6-MERCAPTOPURINE     0.7         -0.44      -0.55     -1.44      0.5
#4       Colchicine    0.32            na         na        na       na
#5 Nitrogen mustard    0.55         -1.03       -1.4     -0.54     1.14
#6      Allopurinol    0.52          0.96      -1.71     -0.26    -0.43
drugDat <- as.matrix(Drug)
rownames(drugDat) <- drugDat[,1]
drug <- drugDat[,2:ncol(drugDat)]
dimnames <- list(rownames(drug),colnames(drug))
drug <- matrix(as.numeric(as.matrix(drug)),nrow = nrow(drug),dimnames = dimnames)
drug[1:6,1:6]
########考虑到药物敏感性数据中存在部分NA缺失值，通过impute.knn()函数来评估并补齐药物数据。
# library(impute)
# mat <- impute.knn(t(drug))
# drug <- t(mat$data);drug[1:6,1:6]
########3）读入表达数据
Expression <- read_excel(path = "D:/data/Drug sensitive/nci60_RNA__RNA_seq_composite_expression/RNA__RNA_seq_composite_expression.xls",skip = 10)
Expression <- Expression[,-c(2:6)]#[1] 23808    61
data.frame(Expression[1:6,1:6])
#   Gene.name.d BR.MCF7 BR.MDA.MB.231 BR.HS.578T BR.BT.549 BR.T.47D
#1 CH17-408M7.1   0.000         0.000      0.112     0.000    0.000
#2      DDX11L1   0.199         0.000      0.381     0.000    0.079
#3       WASH7P   3.088         0.566      1.771     2.129    3.169
#4      FAM138A   0.000         0.000      0.157     0.000    0.000
#5        OR4F5   0.000         0.000      0.147     0.000    0.000
#6       HYDIN2   0.000         0.030      0.083     0.000    0.020
Expression2 <- data.frame(Expression)
rownames(Expression2) <- Expression2[,1]
Expression2 <- Expression2[,2:ncol(Expression2)]
colnames(Expression2) <- colnames(Expression)[-1]
Expression <- Expression2

########################################################################
#############################药敏相关性分析#############################
########################################################################
identical(colnames(Expression),colnames(drug))
########提取特定基因表达
Genelist <- c("IGFBP2","MDK","RARRES2")
Genelist <- intersect(Genelist,rownames(Expression))

########药物敏感性计算########
exprSet <- t(rbind(Expression[Genelist,],drug))
rownames(exprSet) <- colnames(drug)
colnames(exprSet) <- c(Genelist,rownames(drug))

library(Hmisc)
correlation <- rcorr(exprSet,type = "spearman")
Rvalue <- correlation$r[Genelist,-c(1:length(Genelist))]
Pvalue <- correlation$P[Genelist,-c(1:length(Genelist))]

########################################################################
#############################相关性拟合曲线#############################
########################################################################
library(ggplot2)   
library(ggpubr)
formula <- y ~ poly(x, 1, raw = TRUE)    
Druglist <- sort(colnames(Pvalue)[which(Pvalue["IGFBP2",] < 0.001)])
Scatterplot <- lapply(Druglist,function(x){
           plotData <- data.frame(Gene = as.numeric(Expression["IGFBP2",]),
                       Drug = as.numeric(drug[x,]))
           plotData <- na.omit(plotData)
           p <- ggplot(data = plotData, mapping = aes(x=Gene, y=Drug)) +
                geom_point(size = 3,color = "#4d97cd") +  
                geom_smooth(color = "black", method = lm,formula = formula) +
                # scale_x_continuous(limits = c(0.5,3.25), 
                               # breaks = seq(0.5,3,0.5),labels = seq(0.5,3,0.5))+
                labs(x = bquote("Relative Expression ("~Log[2]~"FPKM)"), 
                     y = "Compound Activity Z Scores",title = x) +
                theme_bw() + 
                theme(plot.title = element_text(hjust = 0.5,size = 24),
                      axis.text.x = element_text(hjust = 0.5,size = 18), 
                      axis.text.y = element_text(hjust = 0.5,size = 18),
                      axis.title.y = element_text(size = 20), 
                      axis.title.x = element_text(size = 20), 
                      axis.line = element_line(colour = "black",size = 1))+
                stat_cor(method = "spearman",size = 8)
           return(p)     
    })
library(patchwork)	
Scatterplot[[1]]+Scatterplot[[2]]+Scatterplot[[3]]+Scatterplot[[4]]
pdf("./results/step5.CellMiner-IGFBP2.pdf",width = 6,height = 6)
Scatterplot[[1]]
Scatterplot[[2]]
Scatterplot[[3]]
Scatterplot[[4]]
Scatterplot[[5]]
Scatterplot[[6]]
dev.off()


########################################################################
#########################基因高低表达分组小提琴图#######################
########################################################################
library(ggplot2)   
library(ggpubr) 
Druglist <- sort(colnames(Pvalue)[which(Pvalue["IGFBP2",] < 0.001)])
Violinplot <- lapply(Druglist,function(x){
           plotData <- data.frame(Gene = as.numeric(Expression["IGFBP2",]),
                                  Drug = as.numeric(drug[x,]))
           plotData <- na.omit(plotData)
           plotData$Group <- ifelse(plotData$Gene > median(plotData$Gene),"High","Low")
   
           p = ggplot(plotData, aes(Group,Drug,fill= Group))+ 
               geom_violin(aes(fill = Group),trim = FALSE)+
               geom_boxplot(width = 0.1,fill = "white")+
               geom_signif(comparisons = list(c("High","Low")),
                           step_increase = 0.1,map_signif_level = T,
                           size = 0.5,textsize = 7.5,
                           tip_length = 0.02,
                           margin_top = 0.2,test = "t.test")+
               scale_fill_manual(values = c('#e94753','#47a4e9'))+
               theme_bw()+
               labs(y= paste0("Activity Z Scores of ",x),title= "IGFBP2")+
               theme(plot.title = element_blank(),#element_text(hjust = 0.5,size = 24),
                     legend.position = "none",
                     axis.text.x = element_text(hjust = 0.5,size = 20), 
                     axis.text.y = element_text(hjust = 0.5,size = 18),
                     axis.title.y = element_text(size = 20), 
                     axis.title.x = element_blank(), 
                     axis.line = element_line(colour = "black",size=1))
   })
Violinplot[[2]]
library(patchwork)
Scatterplot[[2]] + Violinplot[[2]] + plot_layout(widths = c(2.5, 1))