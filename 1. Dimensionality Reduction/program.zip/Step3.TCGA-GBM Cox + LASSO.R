rm(list = ls())
gc()
options(stringsAsFactors = FALSE)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
library(readxl)
exprSet <- as.data.frame(read_excel("./results/scRNA-GSE135045/FindAllMarkers-Cluster.xlsx",sheet = 1))
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]
head(exprSet)
Genelist_C2 <- exprSet[exprSet$cluster == "C2","gene"];length(Genelist_C2)#[1] 770
Genelist_C3 <- exprSet[exprSet$cluster == "C3","gene"];length(Genelist_C3)#[1] 1114
Genelist_C4 <- exprSet[exprSet$cluster == "C4","gene"];length(Genelist_C4)#[1] 1414
Genelist_Merge <- unique(c(Genelist_C2,Genelist_C3,Genelist_C4));
length(Genelist_Merge)#[1] 2078
###################################################################################
######################################整理数据#####################################
###################################################################################
########差异分析
load(file = "./results/Step2.TCGA_diff.Rdata")
DEG <- rownames(DESeq2_DEG[DESeq2_DEG$Group == "Up",])
Genelist_Merge <- intersect(Genelist_Merge,DEG)
length(Genelist_Merge)#689

load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-GBM-GeneSymbol.Rdata')
exprSet <- data.frame(SampleNames = colnames(exp_Count),
                      SampleType = substr(sapply(strsplit(colnames(exp_Count),'-'),"[",4),1,3))
table(exprSet$SampleType)
exprSet_Tumor <- exprSet[exprSet$SampleType %in% c("01A"),]
exprSet_Tumor$PatientNames <- substr(exprSet_Tumor$SampleNames,1,12)
table(exprSet_Tumor$SampleType)

exp_mRNA_Count_Tumor <- exp_Count[unique(ids_Gene[ids_Gene$gene_type == "protein_coding","gene_name"]),
                                  exprSet_Tumor$SampleNames]
identical(colnames(exp_mRNA_Count_Tumor),exprSet_Tumor$SampleNames)
dim(exp_mRNA_Count_Tumor)#[1] 19938

minRow <- rowMeans(exp_mRNA_Count_Tumor) > 1  #按平均数筛选 
minNum <- rowSums(exp_mRNA_Count_Tumor > 0) >= (0.8*ncol(exp_mRNA_Count_Tumor)) #表达量不为0的样品个数筛选 
#minNum <- rowSums(exp_mRNA_Count_Tumor > 0) >= (1*ncol(exp_mRNA_Count_Tumor))
exp_mRNA_Count_Tumor <- exp_mRNA_Count_Tumor[minRow & minNum,]
dim(exp_mRNA_Count_Tumor)#[1]16678   146

exp_TPM <- exp_TPM[rownames(exp_mRNA_Count_Tumor),colnames(exp_mRNA_Count_Tumor)]

Genelist_Merge <- intersect(Genelist_Merge,rownames(exp_TPM))
length(Genelist_Merge)#689
exprSet <- data.frame(t(log2(exp_TPM[Genelist_Merge,]+1)))
#exprSet$SampleNames <- colnames(exp_TPM)
exprSet$PatientID <- substr(colnames(exp_TPM),1,12)
exprSet[1:6,(ncol(exprSet)-3):ncol(exprSet)]
                                # LARP7   S100A6     PDPN    PatientID
# TCGA-06-0130-01A-01R-1849-01 5.227267 11.12737 7.325805 TCGA-06-0130
# TCGA-06-0132-01A-02R-1849-01 3.922017 10.29198 7.433003 TCGA-06-0132
# TCGA-06-0125-01A-01R-1849-01 5.149694 10.98265 8.492620 TCGA-06-0125
# TCGA-06-0139-01A-01R-1849-01 4.323031 10.83169 8.455198 TCGA-06-0139
# TCGA-26-5132-01A-01R-1850-01 5.209578 11.47153 8.002510 TCGA-26-5132
# TCGA-15-1444-01A-02R-1850-01 5.259423 10.17122 4.609123 TCGA-15-1444
dim(exprSet)
exprSet[which(exprSet$PatientID %in% names(which(table(exprSet$PatientID) > 1))),
        1:10]
tmp <- exprSet[which(exprSet$PatientID %in% names(which(table(exprSet$PatientID) > 1))),
               Genelist_Merge]
tmp <- as.matrix(tmp)
rownames(tmp) <- exprSet[which(exprSet$PatientID %in% names(which(table(exprSet$PatientID) > 1))),"PatientID"]
tmp2 <- data.frame(limma::avereps(tmp))
tmp2$PatientID <- rownames(tmp2)
exprSet <- rbind(exprSet[-which(exprSet$PatientID %in% names(which(table(exprSet$PatientID) > 1))),],
                 tmp2)
dim(exprSet)#[1] 146 690
###############clinical
load("D:/data/TCGA/TCGAbiolinks-EXP/TCGA-GBM-clinical.Rdata")
head(meta)
meta <- meta[,-1]
meta <- meta[!duplicated(meta$PatientID),]

table(exprSet$PatientID %in% meta$PatientID)
exprSet <- exprSet[exprSet$PatientID %in% meta$PatientID,]
meta <- meta[meta$PatientID %in% exprSet$PatientID,]
exprSet <- merge(exprSet,meta,by = "PatientID")
dim(exprSet)#[1] 146 698
exprSet[1:5,c(1:5,(ncol(exprSet)-10):ncol(exprSet))]
     # PatientID    TOP2A    CENPF    NUSAP1    UBE2C    LARP7    S100A6     PDPN
# 1 TCGA-02-0047 5.693150 3.872504 0.2467121 5.827009 4.481531 10.646153 7.949321
# 2 TCGA-02-0055 5.024306 2.874895 0.2260152 6.625098 4.825226 12.198010 8.268929
# 3 TCGA-02-2483 7.385186 5.352939 0.1916890 8.602876 5.064672  9.968206 5.204078
# 4 TCGA-02-2485 6.688448 4.342441 0.6383056 6.857838 5.017548 10.228932 8.453092
# 5 TCGA-02-2486 2.828835 1.516519 0.1306673 3.674811 5.455120 12.013060 9.439414
  # event gender age days_to_death days_to_last_follow_up sex status time
# 1  Dead   male  78           448                    448   1      1  448
# 2  Dead female  62            76                     76   0      1   76
# 3 Alive   male  43            NA                    466   1      0  466
# 4 Alive   male  53            NA                    470   1      0  470
# 5  Dead   male  64           618                    493   1      1  618

exprSet <- exprSet[which(!is.na(exprSet$status) & !is.na(exprSet$time)),]
#[1] 145 698

###################################################################################
#####################################单因素Cox#####################################
###################################################################################
library("survival")
OSData <- exprSet[!is.na(exprSet$time),]
# sort(colnames(OSData)[grep("[.]",colnames(OSData))])
# sort(Genelist_Merge[grep("-",Genelist_Merge)])
dim(OSData)#[1]145 698
OSData[1:5,1:10]
OSData <- OSData[OSData$time < 365*10,]
OSData <- OSData[OSData$time > 0,]
dim(OSData)#[1]145 698
colnames(OSData)[2:(length(Genelist_Merge)+1)] <- Genelist_Merge
univariateCox <- lapply(Genelist_Merge,function(x){
    res.cox <- coxph(Surv(time,status)~get(x), data = OSData)
    OScoxSummary <- summary(res.cox)
	OScoxSummary <- data.frame(HR = round(OScoxSummary$conf.int[,"exp(coef)"],5),
	                           HR_95L = round(OScoxSummary$conf.int[,"lower .95"],5),
	                           HR_95H = round(OScoxSummary$conf.int[,"upper .95"],5),
	                           C_index = round(OScoxSummary$concordance["C"],5),
	                           C_index_se = round(OScoxSummary$concordance["se(C)"],5),                   
	                           pvalue = round(OScoxSummary$coefficients[,"Pr(>|z|)"],5))
    return(OScoxSummary)
})
univariateCox <- do.call(rbind,univariateCox)
rownames(univariateCox) <- Genelist_Merge
head(univariateCox)
            # HR  HR_95L  HR_95H C_index C_index_se  pvalue
# TOP2A  1.02871 0.88982 1.18927 0.46866    0.03493 0.70210
# CENPF  1.01183 0.86843 1.17891 0.46067    0.03532 0.88015
# NUSAP1 0.62455 0.23882 1.63330 0.50330    0.03457 0.33720
# UBE2C  1.04131 0.89120 1.21671 0.49848    0.03314 0.61028
# ASPM   1.02731 0.84738 1.24545 0.47260    0.03595 0.78389
# HMGB2  1.14565 0.88146 1.48903 0.48998    0.03215 0.30935
            # HR  HR_95L  HR_95H C_index C_index_se  pvalue
# TOP2A  1.02466 0.88612 1.18487 0.46487    0.03512 0.74237
# CENPF  1.00616 0.86392 1.17181 0.45793    0.03545 0.93707
# NUSAP1 0.58288 0.22095 1.53765 0.50759    0.03482 0.27544
# UBE2C  1.04070 0.89039 1.21639 0.49846    0.03316 0.61617
# ASPM   1.01801 0.83976 1.23410 0.46770    0.03604 0.85580
# HMGB2  1.13443 0.87205 1.47576 0.48636    0.03237 0.34730

univariateCoxSig <- univariateCox[univariateCox$pvalue < 0.05,]
dim(univariateCoxSig)#[1]55  6
#write.csv(univariateCox,file = "./results/Step3.univariateCox.csv",quote = F)

###################################################################################
########################################LASSO######################################
###################################################################################
set.seed(19)#17
library(glmnet)
dat.outcome <- cbind(time = as.numeric(OSData[,"time"]),
                     status = as.numeric(OSData[,"status"]))
dat <- OSData[,rownames(univariateCoxSig)]
tmp <- list()
for(i in 1:ncol(dat))tmp[[i]] <- as.numeric(dat[,i])
dat <- do.call(cbind,tmp)
colnames(dat) <- rownames(univariateCoxSig)

# model_lasso <- glmnet(dat, dat.outcome, family = "cox", nlambda = 50, alpha = 1)
# print(model_lasso)
#用交叉验证（cross validation）拟合进而选取模型
cv_fit <- cv.glmnet(x = dat, y = dat.outcome,family = "cox",nfolds = 10)
plot(cv_fit)# 两条虚线分别指示了两个特殊的λ值:
cv_fit
# all:  cv.glmnet(x = dat, y = dat.outcome, family = "cox") 
    # Lambda Index Measure     SE Nonzero
# min 0.2073     4   9.286 0.2087       3
# 1se 0.2740     1   9.291 0.2137       0
c(cv_fit$lambda.min,cv_fit$lambda.1se) 


# library(glmnet)
# niter <- 1000
# selected <- matrix(0, nrow = niter, ncol = length(rownames(univariateCoxSig)))
# colnames(selected) <- rownames(univariateCoxSig)
# for(i in 1:niter){
  # set.seed(i)
  # # ids <- sample(1:nrow(dat), nrow(dat)/2,replace = FALSE)
  # # fit <- cv.glmnet(dat[ids,], dat.outcome[ids,], family = "cox", nfolds = 10)
  # fit <- cv.glmnet(dat, dat.outcome, family = "cox", nfolds = 10)
  # coefi <- coef(fit, s = "lambda.min")
  # selected[i, which(as.numeric(coefi) != 0)] <- 1
# }
# apply(selected, 2, mean) # selection frequency
# sort(apply(selected, 2, mean))
  # # NUDT1    HES6    RBP1   NUCB2    RPA3  TUBA1C    RFC2  COMMD2    LDHA    GNB2   PDAP1    RCN1  NDUFB2   IFT22 
  # # 0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000 
 # # EEF1B2   CD151   PDIA3  TAGLN2   TMED4    P4HB    GUSB  FERMT1    SOX6  IGFBP5   PLOD3 ZDHHC12   ZNF22   PSMC2 
  # # 0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000 
 # # MALSU1  MRPL23  PDLIM4  UBE2E1   LMAN2  KDELR2   TMED9    PDPN   IKBIP     MDK    ENAH    FHL1   TCF12   BUD23 
  # # 0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.000   0.013   0.029   0.961   0.961   0.961   0.961 
# # HSP90B1   ACTG1   NUDT5  MTHFD2  MRPL36  SMIM20     OS9    PHB2    TCTA    ETFA   G6PC3  IGFBP2 RARRES2 
  # # 0.961   0.961   0.961   0.961   0.961   0.961   0.961   0.961   0.961   0.961   0.968   0.991   0.991 

# ##########10折交叉验证的图
# xx <- data.frame(lambda = cv_fit[["lambda"]],
                 # cvm = cv_fit[["cvm"]],
				 # cvsd = cv_fit[["cvsd"]],
                 # cvup = cv_fit[["cvup"]],
				 # cvlo = cv_fit[["cvlo"]],
				 # nozezo = cv_fit[["nzero"]])
# xx <- xx[xx$nozezo != 0,]
# xx$ll <- log(xx$lambda)
# xx$NZERO <- paste0(xx$nozezo,' vars')
# xx$NZERO[which(xx$nozezo > 50)] <- "> 50 vars"
# xx$NZERO[which(xx$nozezo <= 50 & xx$nozezo > 40)] <- "> 40 vars"
# xx$NZERO[which(xx$nozezo <= 40 & xx$nozezo > 30)] <- "> 30 vars"
# xx$NZERO[which(xx$nozezo <= 30 & xx$nozezo > 20)] <- "> 20 vars"
# xx$NZERO[which(xx$nozezo <= 20 & xx$nozezo > 15)] <- "> 15 vars"
# xx$NZERO[which(xx$nozezo <= 15 & xx$nozezo > 10)] <- "> 10 vars"
# xx$NZERO <- factor(xx$NZERO,levels = unique(xx[["NZERO"]]))
# library(randomcoloR)
# palette <- distinctColorPalette(length(unique(cv_fit[["nzero"]])))#差异明显颜色
# library(ggplot2)
# p1 <- ggplot(xx,aes(ll,cvm,color = NZERO))+
  # geom_errorbar(aes(x = ll,ymin = cvlo,ymax = cvup),width = 0.05,size = 1)+
  # geom_vline(xintercept = xx$ll[which.min(xx$cvm)],
             # size = 0.8,color = 'grey60',alpha = 0.8,linetype = 2)+
  # geom_point(size = 2)+
  # xlab("Log Lambda")+ylab('Partial Likelihood Deviance')+
  # theme_bw(base_rect_size = 1.5)+ 
  # scale_color_manual(values = palette)+ ###颜色数量手动调整
  # scale_x_continuous(expand = c(0,0),limits = c(-7.5,-1.2),breaks = seq(-7,-1.5,0.5))+
  # scale_y_continuous(expand = c(0,0),limits = c(9,15.7),breaks = seq(9,15,1))+
  # theme(#panel.grid = element_blank(),
        # axis.title = element_text(size = 22),
        # axis.text = element_text(size = 22),
        # legend.title = element_blank(),
        # legend.text = element_text(size = 22),
        # legend.position = 'bottom') +
  # annotate('text',x = xx$ll[which.min(xx$cvm)],y = max(xx$cvup)*0.85,size = 8,
           # label = paste0('Optimal Lambda = ',round(cv_fit$lambda.min,3)),color = 'black')+
  # guides(col = guide_legend(ncol = 6))
# p1
                             
# # pdf("./results/Step3.LASSO-cv_fit.pdf",width = 10,height = 6)
# # p1
# # dev.off()

###lambda.min
fit.coef.lambda.min <- coef(cv_fit,s = cv_fit$lambda.min)
fit.min.out <- fit.coef.lambda.min[which(fit.coef.lambda.min != 0),]
fit.min.out <- round(fit.min.out,4)
fit.min.out2 <- matrix(fit.min.out,length(fit.min.out),1)
rownames(fit.min.out2) <- names(fit.min.out)
colnames(fit.min.out2) <- c("coef")
LASSOVariables <- names(fit.min.out)
LASSOVariables

###lambda.1se
# fit.coef.lambda.1se <- coef(cv_fit,s = cv_fit$lambda.1se)
# fit.1se.out <- fit.coef.lambda.1se[which(fit.coef.lambda.1se != 0),]
# fit.1se.out <- round(fit.1se.out,4)
# fit.1se.out2 <- matrix(fit.1se.out,length(fit.1se.out),1)
# rownames(fit.1se.out2) <- names(fit.1se.out)
# colnames(fit.1se.out2) <- c("coef")
# LASSOVariables <- names(fit.1se.out)
# LASSOVariables
# #[1]"IGFBP2"  "MDK"     "RARRES2"
univariateCox[LASSOVariables,]
             # HR  HR_95L  HR_95H C_index C_index_se  pvalue
# IGFBP2  1.22712 1.07475 1.40110 0.57942    0.03175 0.00248
# MDK     1.41717 1.14754 1.75015 0.57523    0.03158 0.00120
# RARRES2 1.20803 1.08544 1.34448 0.58069    0.03261 0.00054
# ###########森林图
OScoxSummary <- univariateCoxSig[univariateCoxSig$pvalue < 0.01,]
forest <- data.frame(Characteristics = rownames(OScoxSummary),
                     HR2 = paste0(sprintf("%0.2f", OScoxSummary$HR)," (",
                                 sprintf("%0.2f", OScoxSummary$HR_95L),"-",sprintf("%0.2f", OScoxSummary$HR_95H),")"),
                     P_value = sprintf("%0.5f", OScoxSummary$pvalue))
forest$HR_95L <- OScoxSummary$HR_95L
forest$HR_95H <- OScoxSummary$HR_95H
forest$HR <- OScoxSummary$HR
range(forest$HR_95H)
range(forest$HR_95L)

# forest$P_value <- ifelse(as.numeric(forest$P_value) < 0.001,"<0.001",forest$P_value)
# forest$Characteristics <- factor(forest$Characteristics,levels = rev(forest$Characteristics))

# library(ggplot2)
# #######################HR barplot	
# p4 <-  ggplot(forest,aes(x = HR, y = Characteristics))+
	   # geom_errorbar(aes(xmin = HR_95L , xmax = HR_95H), 
                     # position = position_dodge(0.8), 
					 # width = 0.35,
					 # color = "black") +
	   # geom_point(shape = 21,size = 5,color = "#005496",fill = "#005496") +
	   # scale_x_continuous(expand = c(0,0),
	                      # limits = c(0.25,4),
	                      # breaks = c(0.25,0.5,1,2,4),
						  # labels = c("0.25","0.5","1","2","4")) +
	   # geom_vline(aes(xintercept = 1), linetype = 'dashed', color = 'black')+
	   # coord_trans(x = "log2") +
	   # labs(title = "", x = "Hazard Ratio(HR)",x = "") +
	   # theme_classic() +
	   # theme(plot.title = element_text(hjust = 0.5,face = "bold"),
			 # #axis.text.x = element_text(angle = 45,hjust = 1,size = 17), 
			 # axis.text.x = element_text(size = 18), 
             # axis.text.y = element_blank(), 
			 # axis.title.x = element_blank(), 
			 # axis.title.y = element_blank(), 
			 # axis.ticks.y = element_blank(),
			 # axis.ticks.length.x = unit(0.4,"lines"), 
			 # axis.line.x = element_line(size = 1),
			 # axis.line.y = element_blank(),
			 # panel.border = element_blank(),
			 # legend.position = "none")
# for (i in 1:nrow(forest)) 
    # p4 <- p4 + annotate('rect', xmin = -Inf, xmax = Inf, ymin = i-0.5, ymax = i+0.5, 
                        # fill = ifelse(i %% 2 == 0, 'white', 'gray95'), alpha = .5)			 
# p4

# #######################P value
# p5 <-  ggplot(forest,aes(x = 1, y = Characteristics))+
	   # geom_text(aes(x = 1,y = Characteristics),label = forest$P_value,
                 # hjust = 0.5,inherit.aes = FALSE,size = 6) +
	   # labs(title="P value", x = "",x="") +
	   # theme_classic() +
	   # theme(plot.title = element_text(hjust = 0.5,face = "bold",size = 20),
			 # axis.text.x = element_blank(), 
             # axis.text.y = element_blank(),
			 # axis.title.x = element_blank(), 
			 # axis.title.y = element_blank(),
			 # axis.ticks.x = element_blank(),			 
			 # axis.ticks.y = element_blank(),
			 # axis.line.x = element_blank(),
			 # axis.line.y = element_blank())

# #######################Variable Type
# p1 <-  ggplot(forest,aes(x = 1, y = Characteristics))+
	   # geom_text(aes(x = 1,y = Characteristics),label = forest$Characteristics,
                 # hjust = 0.5,inherit.aes = FALSE,size = 6) +
	   # labs(title="Characteristics", x = "",x="") +
	   # theme_classic() +
	   # theme(plot.title = element_text(hjust = 0.5,face = "bold",size = 20),
			 # axis.text.x = element_blank(), 
             # axis.text.y = element_blank(),
			 # axis.title.x = element_blank(), 
			 # axis.title.y = element_blank(),
			 # axis.ticks.x = element_blank(),			 
			 # axis.ticks.y = element_blank(),
			 # axis.line.x = element_blank(),
			 # axis.line.y = element_blank())
# #######################95% HR2
# p3 <-  ggplot(forest,aes(x = 1, y = Characteristics))+
	   # geom_text(aes(x = 1,y = Characteristics),label = forest$HR2,
                 # hjust = 0.5,inherit.aes = FALSE,size = 6) +
	   # labs(title="HR (95% CI)", x = "",x="") +
	   # theme_classic() +
	   # theme(plot.title = element_text(hjust = 0.5,face = "bold",size = 20),
			 # axis.text.x = element_blank(), 
             # axis.text.y = element_blank(),
			 # axis.title.x = element_blank(), 
			 # axis.title.y = element_blank(),
			 # axis.ticks.x = element_blank(),			 
			 # axis.ticks.y = element_blank(),
			 # axis.line.x = element_blank(),
			 # axis.line.y = element_blank())			 
# library(patchwork)
# p1 + p3 + p4 + p5 + plot_layout(widths = c(1,1,2,0.5),nrow = 1)
# pdf("./results/Step3.univariateCox.pdf",
    # width = 9,height = 6)
# p1 + p3 + p4 + p5 + plot_layout(widths = c(1,1,2,0.5),nrow = 1)
# dev.off()


##用得到的最佳的位置去建模：
model_lasso_final <- glmnet(x = dat, y = dat.outcome, alpha = 1, 
                            lambda = cv_fit$lambda.1se,family = "cox")
# #####计算每个样本的风险得分
# model_lasso_final_coef <- matrix(model_lasso_final$beta)
# LASSO_score <- apply(dat,1,function(x)sum(as.numeric(as.numeric(x)*model_lasso_final_coef)))

# #等价于使用predict直接计算score：
# lasso.prob <- predict(cv_fit, newx = dat , s = c(cv_fit$lambda.min,cv_fit$lambda.1se) )
# #1为lambda.min  ，2为lambda.1se （1倍标准误）
# head(lasso.prob)




###################################################################################
#####################################模型评估######################################
###################################################################################
####################
####################单个基因ROC
####################
Risk_table <- OSData[,c(LASSOVariables,"time","status")]
#[1]"IGFBP2"  "MDK"     "RARRES2"
Risk_table$time <- Risk_table$time/30
predict_1_year <- 12*1
predict_3_year <- 12*3
predict_5_year <- 12*5
library(timeROC)
library(survival)
ROC <- lapply(LASSOVariables,function(Gene){
   Risk_table_tmp <- Risk_table[,c("time","status",Gene)]
   colnames(Risk_table_tmp) <- c("time","status","Gene")
   Time_roc_res <- timeROC(T = Risk_table_tmp$time,#结局时间 
                           delta = Risk_table_tmp$status,#生存结局 
                           marker = Risk_table_tmp$Gene,#预测变量 
                           cause = 1,#阳性结局赋值，比如死亡与否
                           weighting = "marginal",#权重计算方法，marginal是默认值，采用km计算删失分布
                           times = c(predict_1_year,predict_3_year,predict_5_year),#时间点，
                           ROC = TRUE)
   dat <- data.frame(fpr = as.numeric(Time_roc_res$FP),
                     tpr = as.numeric(Time_roc_res$TP),
                     time = rep(as.factor(c(12*1,12*3,12*5)),each = nrow(Time_roc_res$TP)))
   library(ggplot2)
   ROC_trainset <- ggplot() + 
                   geom_line(data = dat,aes(x = fpr, y = tpr,color = time),size = 2) + 
                   scale_color_manual(name = NULL,values = c("#92C5DE", "#F4A582", "#66C2A5"),
                                      labels = paste0("AUC of ",c(1,3,5),"-Year Survival: ",
                                                      format(round(Time_roc_res$AUC,2),nsmall = 2)))+
                   geom_line(aes(x = c(0,1),y = c(0,1)),color = "grey")+
                   theme_bw()+
                   theme(plot.title = element_text(hjust = 0.5,size = 25),
                         #panel.grid = element_blank(),
                         legend.background = element_blank(),
                         legend.position = c(0.6,0.125),
                         axis.text.x = element_text(hjust = 0.5,size = 22),
                         axis.text.y = element_text(hjust = 0.5,size = 22), 
                         axis.title.x = element_text(size = 24), 
                         axis.title.y = element_text(size = 24), 
                         #panel.border = element_blank(),
                         axis.line = element_line(size = 1), 
                         legend.text = element_text(size = 24),
                         legend.title = element_blank())+
                         scale_x_continuous(expand = c(0.005,0.005))+
                         scale_y_continuous(expand = c(0.005,0.005))+
                    labs(x = "1 - Specificity",y = "Sensitivity",title = Gene) +
                    coord_fixed()
   ROC_trainset
})

# pdf("./results/Step3.TCGA-GBM-ROC.pdf",width = 7.5,height = 7.5)
# ROC[[1]]
# ROC[[2]]
# ROC[[3]]
# dev.off()


####################
####################LASSO模型ROC
####################
mRNA_coef <- fit.min.out
#OSData$RiskScore <- as.numeric(as.matrix(OSData[,names(mRNA_coef)])%*%mRNA_coef)
#等价于使用predict直接计算score：
OSData$RiskScore <- predict(cv_fit, newx = as.matrix(OSData[,rownames(fit.coef.lambda.min)]), 
                            s = cv_fit$lambda.min)
OSData[1:5,(ncol(OSData)-10):ncol(OSData)]
#save(OSData,mRNA_coef,file = "./results/Step3.Risk-model.Rdata")
####################
####################ROC
####################
Risk_table <- OSData[,c(names(mRNA_coef),"time","status","RiskScore")]
Risk_table$time <- Risk_table$time/30
predict_1_year <- 12*1
predict_3_year <- 12*3
predict_5_year <- 12*5
library(timeROC)
library(survival)
Time_roc_res <- timeROC(T = Risk_table$time,#结局时间 
                        delta = Risk_table$status,#生存结局 
                        marker = Risk_table$RiskScore,#预测变量 
                        cause = 1,#阳性结局赋值，比如死亡与否
                        weighting = "marginal",#权重计算方法，marginal是默认值，采用km计算删失分布
                        times = c(predict_1_year,predict_3_year,predict_5_year),#时间点，
                        ROC = TRUE)
###使用ggplot2重新绘制
#identical(c(result$TP[,1],result$TP[,2],result$TP[,3]),as.numeric(result$TP))
dat <- data.frame(fpr = as.numeric(Time_roc_res$FP),
                  tpr = as.numeric(Time_roc_res$TP),
                  time = rep(as.factor(c(12*1,12*3,12*5)),each = nrow(Time_roc_res$TP)))
library(ggplot2)
ROC_trainset <- 
ggplot() + 
  geom_line(data = dat,aes(x = fpr, y = tpr,color = time),size = 2) + 
  scale_color_manual(name = NULL,values = c("#92C5DE", "#F4A582", "#66C2A5"),
                     labels = paste0("AUC of ",c(1,3,5),"-Year Survival: ",
                                     format(round(Time_roc_res$AUC,2),nsmall = 2)))+
  geom_line(aes(x = c(0,1),y = c(0,1)),color = "grey")+
  theme_bw()+
  theme(plot.title = element_text(hjust = 0.5,size = 22),
        #panel.grid = element_blank(),
        legend.background = element_blank(),
        legend.position = c(0.6,0.125),
        axis.text.x = element_text(hjust = 0.5,size = 22),
        axis.text.y = element_text(hjust = 0.5,size = 22), 
        axis.title.x = element_text(size = 24), 
        axis.title.y = element_text(size = 24), 
        #panel.border = element_blank(),
		axis.line = element_line(size = 1), 
        legend.text = element_text(size = 24),
        legend.title = element_blank())+
  scale_x_continuous(expand = c(0.005,0.005))+
  scale_y_continuous(expand = c(0.005,0.005))+
  labs(x = "1 - Specificity",
       y = "Sensitivity",title = NULL) +
  coord_fixed()
ROC_trainset
# pdf("./results/Step3.TCGA-GBM-Model ROC.pdf",width = 7.5,height = 7.5)
# ROC_trainset
# dev.off()
####################
####################OS
####################
suppressMessages(library(survival))
suppressMessages(library(survminer))
Risk_table$os_time <- as.numeric(Risk_table$time)
Risk_table$os_event <- as.numeric(Risk_table$status)
##########中位数分组
phe <- na.omit(Risk_table[,c("os_time","os_event","RiskScore")])
phe$Group <- ifelse(phe$RiskScore <= median(phe$RiskScore),"Low","High")
table(phe$Group)
# High  Low 
  # 72   73
# ####最佳截断点
# res.cut <- surv_cutpoint(phe, time = "os_time", event = "os_event",
                         # variables = c("Normalized_count"))
# summary(res.cut)

#median(phe$Normalized_count)
#phe$Group <- ifelse(phe$Normalized_count > summary(res.cut)[1,1],"High","Low")
phe$Group <- factor(phe$Group,levels = c("Low","High"))
table(phe$Group)
# Low High 
#  73   72 


library("survival")
res.cox <- coxph(Surv(os_time,os_event)~Group, data = phe)
coxSummary <- summary(res.cox)
coxSummary
  # n= 145, number of events= 113 
            # coef exp(coef) se(coef)    z Pr(>|z|)   
# GroupHigh 0.6066    1.8342   0.1951 3.11  0.00187 **
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
          # exp(coef) exp(-coef) lower .95 upper .95
# GroupHigh     1.834     0.5452     1.251     2.688

HR <- round(coxSummary$coefficients[1,2],2)
HR.confint.lower <- round(coxSummary$conf.int[,"lower .95"],2)
HR.confint.upper <- round(coxSummary$conf.int[,"upper .95"],2)
HR <- paste0("HR = ",HR," (", HR.confint.lower, "-", HR.confint.upper, ")")
HR# "HR = 1.83 (1.25-2.69)"

HRPvalue <- coxSummary$coefficients[1,5]
HRPvalue <- paste0("HR P = ",round(HRPvalue,3))
HRPvalue#"HR P = 0"
#HRPvalue <- "HR P < 0.0001"

data.survdiff = survdiff(Surv(os_time, os_event)~Group, data = phe)
p.val <- 1 - pchisq(data.survdiff$chisq, length(data.survdiff$n) - 1)   #计算P值
p.val
LogrankPvalue <- paste0("logrank P = ",round(p.val,3))
LogrankPvalue
#LogrankPvalue <- "Logrank P < 0.0001"#"Logrank P = 0"



library(survival)
library(survminer)
sfit <- survfit(Surv(os_time,os_event)~Group, data = phe)
pKMplot <- ggsurvplot(sfit,palette = c("#2E9FDF","red"),
                 risk.table = TRUE,
                 risk.table.col = "strata", # Change risk table color by groups
				 risk.table.height = 0.25,
				 risk.table.title = "No. at risk",
				 risk.table.y.text = FALSE,
                 linetype = "strata", # Change line type by groups
				 pval = FALSE,conf.int = T,#pval.coord = c(0.15, 0.08),pval.size = 7,
				 fontsize = 8,
                 legend = "top",
				 font.x = 16,font.y = 16,font.legend = 14,font.tickslab = 15, font.title = 18, 
				 surv.median.line = "hv",
                 break.time.by = 20,ggtheme = theme_bw(),
				 legend.title = "",
                 legend.labs = c("Low Expression","High Expression"),
                 xlab = "Time in months",
                 ylab = "Overall Survival Probility",
				 title = "TCGA-GBM")
pKMplot
library(ggplot2)
pKMplot$plot <- pKMplot$plot +
                #因为是百分比，转换为*100：
                scale_y_continuous(expand = c(0,0.03),breaks = seq(0,1,0.25),
	                               labels = paste0(seq(0,100,25),"%")) +
                theme(plot.title = element_blank(),#element_text(hjust = 0.5,size = 24),
	                  axis.text.x = element_blank(),
	                  axis.title.x = element_blank(),
	                  axis.ticks.x = element_blank(),
	                  axis.text.y = element_text(size = 20),
	                  axis.title.y = element_text(size = 22), 
	                  axis.line = element_line(size = 1), 
	                  legend.text = element_text(size = 22),
	                  legend.title = element_blank(),
	                  legend.position = c(0.)) +
                annotate("text", x = max(phe$os_time)/3, y = 0.8,
				         label = LogrankPvalue,size = 8,hjust = 0) +
                annotate("text", x = max(phe$os_time)/3, y = 0.7,
				         label = HR,size = 8,hjust = 0)
pKMplot$table <- pKMplot$table + 
                 theme(plot.title = element_blank(),
	                   axis.text = element_text(size = 22),
	                   axis.title.x = element_text(size = 22),
	                   # axis.text.y = element_text(size = 22),
	                   # axis.title.y = element_blank(), 
	                   legend.position = "none") 
pKMplot
library(patchwork)
pKMplot2 <- pKMplot$plot + pKMplot$table + plot_layout(ncol = 1,height = c(4,1))     
pKMplot2
# pdf("./results/Step3.TCGA-GBM-Model OS.pdf",width = 7.5,height = 7.5)
# pKMplot2
# dev.off()
			   
			   
			   
