rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
##################################################################################################
#############################################数据准备#############################################
##################################################################################################
# load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-GBM-GeneSymbol.Rdata')
# load(file = "./step2.Riskmodel.Rdata")
load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-GBM-GeneSymbol.Rdata')
exprSet <- data.frame(SampleNames = colnames(exp_Count),
                      SampleType = substr(sapply(strsplit(colnames(exp_Count),'-'),"[",4),1,3))
table(exprSet$SampleType)
exprSet_Tumor <- exprSet[exprSet$SampleType %in% c("01A"),]
exprSet_Tumor$PatientNames <- substr(exprSet_Tumor$SampleNames,1,12)
table(exprSet_Tumor$SampleType)

exp_mRNA_Count_Tumor <- exp_Count[unique(ids_Gene[ids_Gene$gene_type == "protein_coding","gene_name"]),
                                  exprSet_Tumor$SampleNames]
identical(colnames(exp_mRNA_Count_Tumor),exprSet_Tumor$SampleNames)
dim(exp_mRNA_Count_Tumor)#[1] 19938   146
exp_TPM <- exp_TPM[rownames(exp_mRNA_Count_Tumor),colnames(exp_mRNA_Count_Tumor)]

##########################
##########################添加GSVA
##########################
library(readxl)
exprSet <- as.data.frame(read_excel("./results/scRNA-GSE135045/FindAllMarkers-Cluster.xlsx",sheet = 1))
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]
head(exprSet)

Gene_df <- data.frame(gene = exprSet$gene,
                      term = exprSet$cluster)
Gene_list <- split(Gene_df$gene,Gene_df$term)
lapply(Gene_list, length)
lapply(Gene_list[1:3], head)
dat <- as.matrix(log2(exp_TPM + 0.1))

set.seed(123456)
library(GSVA)
library(clusterProfiler)
GSVA_ES <- gsva(expr = dat, gset.idx.list = Gene_list, 
                parallel.sz = 5, verbose = TRUE,
				kcdf = "Gaussian",
				method = "ssgsea") 
GSVA_ES[1:10,1:3]

GSVA_ES <- data.frame(t(GSVA_ES))
head(GSVA_ES)
                                   # C0       C1      C10       C2       C3       C4       C5
# TCGA-76-4932-01A-01R-1850-01 1.471257 1.294842 1.236669 1.466232 1.551322 1.533327 1.880354
# TCGA-12-0619-01A-01R-1849-01 1.671596 1.500206 1.255400 1.425071 1.539289 1.446600 1.791459
# TCGA-06-0156-01A-02R-1849-01 1.617036 1.435259 1.186892 1.500716 1.601138 1.573997 1.883137
# TCGA-76-4931-01A-01R-1850-01 1.334891 1.158452 1.175423 1.505197 1.587994 1.541575 1.905982
# TCGA-06-0686-01A-01R-1849-01 1.463956 1.291726 1.191883 1.493380 1.571504 1.633484 1.899106
# TCGA-06-5858-01A-01R-1849-01 1.584962 1.428265 1.286889 1.488781 1.554391 1.528367 1.831101
                                   # C6       C7       C8       C9
# TCGA-76-4932-01A-01R-1850-01 1.599365 1.537130 1.291565 1.537562
# TCGA-12-0619-01A-01R-1849-01 1.546583 1.597409 1.244287 1.520224
# TCGA-06-0156-01A-02R-1849-01 1.617492 1.578301 1.294730 1.490135
# TCGA-76-4931-01A-01R-1850-01 1.581469 1.467357 1.283139 1.479373
# TCGA-06-0686-01A-01R-1849-01 1.502070 1.478996 1.400022 1.516185
# TCGA-06-5858-01A-01R-1849-01 1.642172 1.567755 1.463547 1.592293

GSVA_ES$SampleNames <- rownames(GSVA_ES)
GSVA_ES$ID <- substr(GSVA_ES$SampleNames,1,12)#[1] 146  13

##########################
##########################TCGA-clinical
##########################
load("D:/data/TCGA/TCGAbiolinks-EXP/TCGA-GBM-clinical.Rdata")
head(meta)#[1] 617   9
            # ID event gender age days_to_death days_to_last_follow_up sex status time
# 1 TCGA-27-2523  Dead   male  63           489                    489   1      1  489
# 2 TCGA-4W-AA9R Alive   male  61            NA                    124   1      0  124
# 3 TCGA-06-5408  Dead female  54           357                    342   0      1  357
# 4 TCGA-08-0380  Dead female  74           454                    330   0      1  454
# 5 TCGA-06-0133  Dead   male  64           435                    428   1      1  435
# 6 TCGA-12-0692  Dead female  75           111                     80   0      1  111
OSData <- merge(GSVA_ES,meta,by = "ID")
dim(OSData)#[1] 146  21

###################################################################################
######################################计算HR值#####################################
###################################################################################
Variables <- paste0("C",0:10)
rownames(OSData) <- OSData$SampleNames
OSData <- OSData[,c(Variables,"time","status")]
OSData[is.na(OSData$time),]
OSData <- OSData[!is.na(OSData$time),]#[1]145  13
dim(OSData)
#OSData$Expression <- ifelse(as.numeric(OSData$Expression) < median(OSData$Expression),"High","Low") 
#######单因素
library("survival")
univariateCox <- lapply(Variables,function(x){
    res.cox <- coxph(Surv(time,status)~get(x), data = OSData)
    OScoxSummary <- summary(res.cox)
	OScoxSummary <- data.frame(HR = round(OScoxSummary$conf.int[,"exp(coef)"],3),
	                           HR_95L = round(OScoxSummary$conf.int[,"lower .95"],3),
	                           HR_95H = round(OScoxSummary$conf.int[,"upper .95"],3),
	                           C_index = round(OScoxSummary$concordance["C"],3),
	                           C_index_se = round(OScoxSummary$concordance["se(C)"],3),                   
	                           pvalue = round(OScoxSummary$coefficients[,"Pr(>|z|)"],3))
    return(OScoxSummary)
})
univariateCox <- do.call(rbind,univariateCox)
rownames(univariateCox) <- Variables
univariateCox
       # HR HR_95L HR_95H C_index C_index_se pvalue
# C0  2.263  0.677  7.566   0.551      0.032  0.185
# C1  2.327  0.688  7.864   0.539      0.032  0.174
# C2  0.472  0.061  3.623   0.552      0.033  0.470
# C3  0.260  0.008  8.674   0.534      0.030  0.452
# C4  0.186  0.009  4.052   0.538      0.030  0.285
# C5  0.053  0.001  3.359   0.543      0.029  0.166
# C6  1.577  0.125 19.840   0.488      0.032  0.724
# C7  2.824  0.204 39.005   0.517      0.032  0.438
# C8  0.622  0.075  5.186   0.501      0.035  0.661
# C9  4.703  0.357 61.866   0.513      0.033  0.239
# C10 1.308  0.103 16.631   0.473      0.032  0.836



