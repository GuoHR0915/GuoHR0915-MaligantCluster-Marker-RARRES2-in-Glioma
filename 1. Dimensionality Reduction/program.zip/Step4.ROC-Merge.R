rm(list = ls())
options(stringsAsFactors = F)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
library(ggplot2)
mytheme <- theme_bw() + 
           theme(plot.title = element_text(hjust = 0.5,size = 24),
		         strip.text = element_text(size = 20),
                 axis.line = element_line(color = "black",size = 0.4),
                 axis.text.y = element_text(color = "black",size = 20),
                 axis.text.x = element_text(color = "black",size = 20),
                 axis.title = element_blank(),
                 panel.grid.minor = element_blank(),
                 panel.grid.major = element_line(size = 0.2,color = "#e5e5e5"),
				 legend.text = element_text(size = 24),
				 legend.title = element_blank(),
                 legend.position = "bottom")
##mRNA_array_301
DataROC <- data.frame(AUC = c(0.6560774,0.8021978,0.7549744,
                              0.6482270,0.7498432,0.6391656,
							  0.6342938,0.7348867,0.7222352),
					  Group = rep(c("IGFBP2","MDK","RARRES2"),each = 3),
					  Time = c(rep(c("1-Year","3-Year","5-Year"),3)))
DataROC$Label = as.character(round(DataROC$AUC,3))
DataROC$Group <- factor(DataROC$Group,
                        levels = rev(c("IGFBP2","MDK","RARRES2")),
						labels = rev(c("IGFBP2","MDK","RARRES2")))
# 绘制并列条形图
pROC <- ggplot(DataROC, aes(x = Group, y = AUC, fill = Time)) +
        geom_bar(stat = "identity", position = position_dodge()) +
        labs(title = "mRNAarray 301", x = NULL, y = "AUC", fill = NULL) +
        scale_fill_manual(values = c("#92C5DE", "#F4A582", "#66C2A5")) + 
		scale_y_continuous(expand = c(0,0),limits = c(0,0.9),
		                   breaks = seq(0,0.8,0.2),
						   labels = seq(0,0.8,0.2)) +
		coord_flip() + 
        mytheme
# 在每个柱子上添加文字
pROC + geom_text(aes(y = 0.25,label = Label), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 8)
pdf("./results/step4.ROC-mRNAarray301.pdf",height = 5.5,width = 6)
pROC + geom_text(aes(y = 0.25,label = Label), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 7)
dev.off()

##mRNAseq325
DataROC <- data.frame(AUC = c(0.7386026,0.8327293,0.8644653,
                              0.7437315,0.8094028,0.7671195,
                              0.6697501,0.7131294,0.7647846),
					  Group = rep(c("IGFBP2","MDK","RARRES2"),each = 3),
					  Time = c(rep(c("1-Year","3-Year","5-Year"),3)))
DataROC$Label = as.character(round(DataROC$AUC,3))
DataROC$Group <- factor(DataROC$Group,
                        levels = rev(c("IGFBP2","MDK","RARRES2")),
						labels = rev(c("IGFBP2","MDK","RARRES2")))
# 绘制并列条形图
pROC <- ggplot(DataROC, aes(x = Group, y = AUC, fill = Time)) +
        geom_bar(stat = "identity", position = position_dodge()) +
        labs(title = "mRNAseq 325", x = NULL, y = "AUC", fill = NULL) +
        scale_fill_manual(values = c("#92C5DE", "#F4A582", "#66C2A5")) + 
		scale_y_continuous(expand = c(0,0),limits = c(0,0.9),
		                   breaks = seq(0,0.8,0.2),
						   labels = seq(0,0.8,0.2)) +
		coord_flip() + 
        mytheme
# 在每个柱子上添加文字
pROC + geom_text(aes(y = 0.25,label = Label), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 8)
pdf("./results/step4.ROC-mRNAseq325.pdf",height = 5.5,width = 6)
pROC + geom_text(aes(y = 0.25,label = Label), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 7)
dev.off()

##mRNAseq639
DataROC <- data.frame(AUC = c(0.7291866,0.7864408,0.7283954,
                              0.5756154,0.5955208,0.5575848,
                              0.5997110,0.6527483,0.6157204),
					  Group = rep(c("IGFBP2","MDK","RARRES2"),each = 3),
					  Time = c(rep(c("1-Year","3-Year","5-Year"),3)))
DataROC$Label = as.character(round(DataROC$AUC,3))
DataROC$Group <- factor(DataROC$Group,
                        levels = rev(c("IGFBP2","MDK","RARRES2")),
						labels = rev(c("IGFBP2","MDK","RARRES2")))
# 绘制并列条形图
pROC <- ggplot(DataROC, aes(x = Group, y = AUC, fill = Time)) +
        geom_bar(stat = "identity", position = position_dodge()) +
        labs(title = "mRNAseq 639", x = NULL, y = "AUC", fill = NULL) +
        scale_fill_manual(values = c("#92C5DE", "#F4A582", "#66C2A5")) + 
		scale_y_continuous(expand = c(0,0),limits = c(0,0.9),
		                   breaks = seq(0,0.8,0.2),
						   labels = seq(0,0.8,0.2)) +
		coord_flip() + 
        mytheme
# 在每个柱子上添加文字
pROC + geom_text(aes(y = 0.25,label = Label), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 8)
pdf("./results/step4.ROC-mRNAseq639.pdf",height = 5.5,width = 6)
pROC + geom_text(aes(y = 0.25,label = Label), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 7)
dev.off()


##TCGA-LGG
DataROC <- data.frame(AUC = c(0.8932468,0.8410743,0.7008480,
                              0.7946789,0.7023287,0.6640329,
                              0.8090592,0.7316666,0.6303517),
					  Group = rep(c("IGFBP2","MDK","RARRES2"),each = 3),
					  Time = c(rep(c("1-Year","3-Year","5-Year"),3)))
DataROC$Label = as.character(round(DataROC$AUC,3))
DataROC$Group <- factor(DataROC$Group,
                        levels = rev(c("IGFBP2","MDK","RARRES2")),
						labels = rev(c("IGFBP2","MDK","RARRES2")))
# 绘制并列条形图
pROC <- ggplot(DataROC, aes(x = Group, y = AUC, fill = Time)) +
        geom_bar(stat = "identity", position = position_dodge()) +
        labs(title = "TCGA-LGG", x = NULL, y = "AUC", fill = NULL) +
        scale_fill_manual(values = c("#92C5DE", "#F4A582", "#66C2A5")) + 
		scale_y_continuous(expand = c(0,0),limits = c(0,0.9),
		                   breaks = seq(0,0.8,0.2),
						   labels = seq(0,0.8,0.2)) +
		coord_flip() + 
        mytheme
# 在每个柱子上添加文字
pROC + geom_text(aes(y = 0.25,label = Label), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 8)
pdf("./results/step4.ROC-TCGA-LGG.pdf",height = 5.5,width = 6)
pROC + geom_text(aes(y = 0.25,label = Label), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 7)
dev.off()

##TCGA-GBM
DataROC <- data.frame(AUC = c(0.6175617,0.6226373,0.6955897,
                              0.6257614,0.7562183,0.8735507,
                              0.6316500,0.6300215,0.8276916),
					  Group = rep(c("IGFBP2","MDK","RARRES2"),each = 3),
					  Time = c(rep(c("1-Year","3-Year","5-Year"),3)))
DataROC$Label = as.character(round(DataROC$AUC,3))
DataROC$Group <- factor(DataROC$Group,
                        levels = rev(c("IGFBP2","MDK","RARRES2")),
						labels = rev(c("IGFBP2","MDK","RARRES2")))
# 绘制并列条形图
pROC <- ggplot(DataROC, aes(x = Group, y = AUC, fill = Time)) +
        geom_bar(stat = "identity", position = position_dodge()) +
        labs(title = "TCGA-GBM", x = NULL, y = "AUC", fill = NULL) +
        scale_fill_manual(values = c("#92C5DE", "#F4A582", "#66C2A5")) + 
		scale_y_continuous(expand = c(0,0),limits = c(0,0.9),
		                   breaks = seq(0,0.8,0.2),
						   labels = seq(0,0.8,0.2)) +
		coord_flip() + 
        mytheme
# 在每个柱子上添加文字
pROC + geom_text(aes(y = 0.25,label = Label), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 8)
pdf("./results/step4.ROC-TCGA-GBM.pdf",height = 5.5,width = 6)
pROC + geom_text(aes(y = 0.25,label = Label), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 7)
dev.off()

