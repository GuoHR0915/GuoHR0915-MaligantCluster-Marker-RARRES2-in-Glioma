rm(list = ls())
options(stringsAsFactors = F)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
options(timeout = 10000)
##########################################训练集准备##########################################
dir <- 'D:/data/Drug sensitive/oncoPredict-Training Data/'
GDSC2_Expr <- readRDS(file = file.path(dir,'GDSC2_Expr (RMA Normalized and Log Transformed).rds'))
GDSC2_Expr[1:10,1:4]#[1]17419   805
GDSC2_Res <- readRDS(file = file.path(dir,"GDSC2_Res.rds"))#读入药物的IC50数据
GDSC2_Res[1:10,1:4]#[1] 805 198
#IMPORTANT note: here I do e^IC50 since the IC50s are actual ln values/log transformed already, and the calcPhenotype function Paul 
#has will do a power transformation (I assumed it would be better to not have both transformations)
GDSC2_Res <- exp(GDSC2_Res) 
GDSC2_Res[1:10,1:4]#[1] 805 198
sort(colnames(GDSC2_Res))

##########################################测试集准备##########################################
##################
##################mRNAseq_325
##################
phenoDat <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325_clinical.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
head(phenoDat)
phenoDat <- phenoDat[phenoDat$PRS_type == "Primary",]
exprSet <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325.RSEM-genes.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]

exprSet <- exprSet[,colnames(exprSet) %in% phenoDat$CGGA_ID]
phenoDat <- phenoDat[phenoDat$CGGA_ID %in% colnames(exprSet),]

exprSet[1:5,1:5]
boxplot(exprSet[,1:4])

fpkmToTpm <- function(fpkm)
{
    exp(log(fpkm) - log(sum(fpkm)) + log(1e6))
}
exp_TPM <- apply(exprSet,2,fpkmToTpm)
boxplot(exp_TPM[,1:4])

exprSet <- log2(exp_TPM + 1)
print(dim(exprSet))
##################测试集准备
testExpr <- as.matrix(exprSet)
testExpr[1:4,1:4]  

##################药物敏感性预测
library(oncoPredict)
calcPhenotype(trainingExprData = GDSC2_Expr,
              trainingPtype = GDSC2_Res,
              testExprData = testExpr,
              batchCorrect = 'standardize',  #   "eb" for ComBat  
              powerTransformPhenotype = TRUE,
              removeLowVaryingGenes = 0.2,
              minNumSamples = 10, 
              printOutput = TRUE, 
              removeLowVaringGenesFrom = 'rawData')


##################
##################mRNAseq_693
##################
phenoDat <- read.table("D:/data/CGGA/mRNAseq_693/CGGA.mRNAseq_693_clinical.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
head(phenoDat)
phenoDat <- phenoDat[phenoDat$PRS_type == "Primary",]
exprSet <- read.table("D:/data/CGGA/mRNAseq_693/CGGA.mRNAseq_693.RSEM-genes.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]

exprSet <- exprSet[,colnames(exprSet) %in% phenoDat$CGGA_ID]
phenoDat <- phenoDat[phenoDat$CGGA_ID %in% colnames(exprSet),]

exprSet[1:5,1:5]
boxplot(exprSet[,1:4])

fpkmToTpm <- function(fpkm)
{
    exp(log(fpkm) - log(sum(fpkm)) + log(1e6))
}
exp_TPM <- apply(exprSet,2,fpkmToTpm)
boxplot(exp_TPM[,1:4])

exprSet <- log2(exp_TPM + 1)
print(dim(exprSet))
##################测试集准备
testExpr <- as.matrix(exprSet)
testExpr[1:4,1:4]  

##################药物敏感性预测
library(oncoPredict)
calcPhenotype(trainingExprData = GDSC2_Expr,
              trainingPtype = GDSC2_Res,
              testExprData = testExpr,
              batchCorrect = 'standardize',  #   "eb" for ComBat  
              powerTransformPhenotype = TRUE,
              removeLowVaryingGenes = 0.2,
              minNumSamples = 10, 
              printOutput = TRUE, 
              removeLowVaringGenesFrom = 'rawData')


