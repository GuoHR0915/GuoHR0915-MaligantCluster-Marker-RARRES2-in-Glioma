rm(list=ls())
options(stringsAsFactors = F)
library(Seurat)
library(ggplot2)
library(cowplot)
library(dplyr)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
##########################################################################################
######################################导入数据############################################
##########################################################################################
# library(data.table)
# GSM3984317 <- data.frame(fread("data/GSE135045_RAW/GSM3984317_NO.1.expression_matrix.txt.gz"))
# GSM3984317[1:4,1:4]
# dat <- GSM3984317[,-1]
# rownames(dat) <- GSM3984317[,1]
# dat[1:4,1:4]
#创建SeuratObject
# GSM3984317 <- CreateSeuratObject(counts = dat,  #和文章一样，初步质控
                                 # min.cells = 3, #在不少于三个细胞中表达
                                 # min.features = 200, #基因数不少于200
                                 # project = "GSM3984317")
# GSM3984317
# # One low-grade glioma, 8 high-grade primary gliomas, 
# # 1 recurrent glioma and 2 paratumor tissues
fs <- list.files('./data/GSE135045_RAW')
fs <- fs[grep("expression_matrix.txt.gz",fs)]
setwd('./data/GSE135045_RAW')
library(data.table)
library(Seurat)
scRNAlist <- lapply(fs,function(x){
    exprSet <- data.frame(fread(x))
    exprSet[1:4,1:4]
    dat <- exprSet[,-1]
    rownames(dat) <- exprSet[,1]
    dat[1:4,1:4]
    
	project <- sapply(strsplit(x,"_"),"[",1)
    scRNA <- CreateSeuratObject(counts = dat,  #和文章一样，初步质控
                                min.cells = 10, #在不少于10个细胞中表达
                                min.features = 200, #基因数不少于200
                                project = project)
    scRNA
})
scRNAlist

################################################################################
##################################数据Merge & QC################################
################################################################################
sce.all <- merge(scRNAlist[[1]], y = scRNAlist[-1],
				 add.cell.ids = sapply(strsplit(fs,"_"),"[",1), project = "GSE135045")
sce.all
# An object of class Seurat 
# 24074 features across 28261 samples within 1 assay 
# Active assay: RNA (24074 features, 0 variable features)

table(sce.all@meta.data$orig.ident)
# GSM3984317 GSM3984318 GSM3984319 GSM3984322 GSM3984326 GSM3984330 GSM4495152 
      # 4463       2641       3193       3195       6284       2920       5565 
head(sce.all@meta.data)
#                             orig.ident nCount_RNA nFeature_RNA
# GSM3984317_CF3CCATCACAATGC GSM3984317      24932         2899
# GSM3984317_CF1TCACCCATTCGC GSM3984317      24586         2270
# GSM3984317_CF3CCATTCGCACGC GSM3984317      27706         3547
# GSM3984317_CF1CAACCAATCATC GSM3984317      34124         5717
# GSM3984317_CF1CGTAGTATCGAT GSM3984317      33344         7212
# GSM3984317_CF1ATATGTAACGAA GSM3984317      30276         6661

##############QC
sce.all[["percent.mt"]] <- PercentageFeatureSet(sce.all, pattern = "^MT-")
sce.all[["percent.ribo"]] <- PercentageFeatureSet(sce.all, pattern = "^RP[SL]")
head(sce.all@meta.data)
#Visualize QC metrics as a violin plot
VlnPlot(sce.all, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), 
        ncol = 4,group.by = 'orig.ident')
head(sce.all@meta.data)

# FeatureScatter is typically used to visualize feature-feature relationships, but can be used for anything calculated by the object, i.e. columns in object metadata, PC scores etc.
plot1 <- FeatureScatter(sce.all, feature1 = "nCount_RNA", feature2 = "percent.mt") 
plot2 <- FeatureScatter(sce.all, feature1 = "nCount_RNA", feature2 = "nFeature_RNA") 
plot1 + plot2
# 细胞过滤
sce.all <- subset(sce.all, subset = percent.mt < 30)
sce.all <- subset(sce.all, subset = percent.ribo < 50)
sce.all <- subset(sce.all, subset = nFeature_RNA > 500)
sce.all <- subset(sce.all, subset = nFeature_RNA < 8000)
sce.all
# An object of class Seurat 
# 24074 features across 27642 samples within 1 assay 
# Active assay: RNA (24074 features, 0 variable features)
VlnPlot(sce.all, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), 
        ncol = 3,group.by = 'orig.ident')
# FeatureScatter is typically used to visualize feature-feature relationships, but can be used for anything calculated by the object, i.e. columns in object metadata, PC scores etc.
plot1 <- FeatureScatter(sce.all, feature1 = "nCount_RNA", feature2 = "percent.mt") 
plot2 <- FeatureScatter(sce.all, feature1 = "nCount_RNA", feature2 = "nFeature_RNA") 
plot1 + plot2
# An object of class Seurat 
# 24074 features across 27756 samples within 1 assay 
# Active assay: RNA (24074 features, 0 variable features)

saveRDS(sce.all,file = "./sce.all_QC.rds")

############去批次前
sce.all <- NormalizeData(sce.all, normalization.method = "LogNormalize", scale.factor = 1e4) 
sce.all <- FindVariableFeatures(sce.all, selection.method = 'vst', nfeatures = 2000)
# Identify the 10 most highly variable genes
top10 <- head(VariableFeatures(sce.all), 10)
# plot variable features with and without labels
plot1 <- VariableFeaturePlot(sce.all)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
plot1 + plot2
sce.all <- ScaleData(sce.all)
sce.all <- RunPCA(sce.all, features = VariableFeatures(object = sce.all))  
# 
sce.all <- FindNeighbors(sce.all, dims = 1:20)
sce.all <- FindClusters(sce.all, resolution = 0.5)
sce.all <- RunUMAP(sce.all, dims = 1:20)
Sample_UMAP <- DimPlot(sce.all, reduction = 'umap',group.by = 'orig.ident',
                      label = TRUE, pt.size = 0.5)
Cluster_UMAP <- DimPlot(sce.all, reduction = 'umap',#group.by = 'orig.ident',
                       label = TRUE, pt.size = 0.5)
Sample_UMAP + Cluster_UMAP


################################################################################
##################################数据整合去批次################################
################################################################################
rm(list = ls())
library(Seurat)
library(ggplot2)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
sce.all <- readRDS("./data/GSE135045_RAW/sce.all_QC.rds")
sce.all
sce.all <- NormalizeData(sce.all, normalization.method = "LogNormalize", scale.factor = 1e4) 
sce.all <- FindVariableFeatures(sce.all, selection.method = 'vst', nfeatures = 2000)

all.genes <- rownames(sce.all)
sce.all <- ScaleData(sce.all, features = all.genes)
sce.all <- RunPCA(sce.all, features = VariableFeatures(object = sce.all),seed.use = 123)

# sce.all <- JackStraw(sce.all,dims = 50,num.replicate = 100)#默认dims = 20
# sce.all <- ScoreJackStraw(sce.all, dims = 1:50)
# JackStrawPlot <- JackStrawPlot(sce.all, dims = 1:50)
# ElbowPlot <- ElbowPlot(sce.all,ndim = 50)
# JackStrawPlot + ElbowPlot

##############去批次 harmony
library(harmony)# 5 iterations
sce.all <- RunHarmony(sce.all, group.by.vars = "orig.ident")#reduction = "pca"
names(sce.all@reductions)

###选择合适的pcs
n.pcs <- 30
sce.all <- FindNeighbors(sce.all,dims = 1:n.pcs,reduction = "harmony")
for (res in c(0.05,0.1,0.2,0.3,0.5,0.8,1)) {
  print(res)
  sce.all <- FindClusters(sce.all,resolution = res, algorithm = 1)
}
head(sce.all@meta.data)

sce.all <- RunUMAP(sce.all,dims = 1:n.pcs,reduction = "harmony",seed.use = 345)
DimPlot(sce.all,reduction = "umap",label = T, group.by = "RNA_snn_res.0.2") 
# p1 <- DimPlot(sce.all, reduction = "umap", group.by = "orig.ident")
# p2 <- DimPlot(sce.all, reduction = "umap", label = TRUE, repel = TRUE)+
      # ggtitle("Cluster of resolution 0.3")+
      # theme(plot.title = element_text(hjust = 0.5)) 
# p1 + p2

sce.all <- RunTSNE(sce.all,dims = 1:n.pcs,reduction = "harmony")
# p3 <- DimPlot(sce.all, reduction = "tsne", group.by = "orig.ident")
# p4 <- DimPlot(sce.all, reduction = "tsne", label = TRUE, repel = TRUE)+
      # ggtitle("Cluster of resolution 0.3")+
      # theme(plot.title = element_text(hjust = 0.5)) 
# p3 + p4

library(clustree)
library(patchwork)
p1 <- clustree(sce.all, prefix = 'RNA_snn_res.') + 
      theme(legend.position = "bottom") + 
      scale_color_brewer(palette = "Set1") +
      scale_edge_color_continuous(low = "grey80", high = "red")
p2 <- DimPlot(sce.all, group.by = 'RNA_snn_res.0.3', label = T)
#p1 + p2 + plot_layout(widths = c(3, 1))
pdf("./results/scRNA-GSE135045/Clustree.pdf",width = 10)
p1 + p2 + plot_layout(widths = c(3, 1))
dev.off()

saveRDS(sce.all,file = "./data/GSE135045_RAW/sce.all_Harmony.rds")


rm(list=ls())
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
################################################################################
######################################细胞注释##################################
################################################################################
library(Seurat)
sce.all <- readRDS("./data/GSE135045_RAW/sce.all_Harmony.rds")
library(ggplot2) 
#查看这些marker基因在各个cluster里的表达情况
#sce.all@assays$RNA
genes_to_check <- c("PTPRC", "CD3G", "CD3E", "CD79A",#Immune cells
                   "EPCAM", "KRT8", "KRT18", "KRT19", "CDH1",#Epithelial/Cancer cells
				   'PECAM1', 'MME')#Stromal cells (CD10+,MME,fibo or CD31+,PECAM1,endo)
genes_to_check <- c("SOX2",
                   #"AQP4", "ADGRV1","ALDOC",#Astrocytes 星型胶质细胞 
				   "GPR17",#Oligodendrocyte precursor cells
				   "PTPRZ1","PDGFRA","PCDH15","VCAN","ARHGAP31","TNR",#OPC
                   "COL5A3","OLIG1","OLIG2", 
                   "MBP","PLP1","OLIG1","MOG","CLDN11",#Oligodendrocytes 少突胶质细胞
				   "SNAP25","SYP","ELAVL2","HAPLN2",#Pan-neuron
				   "STMN1","MKI67","TOP2A","CDK1",#Proliferating 
				   "CD2","CD3D","CD3E","CD3G","TRAC",#T lymphocytes
				   "C3","LRMDA","DOCK8",#Microglia 小神经胶质细胞
				   "S100A8","S100A9",#Monocyte 
				   "C1QA","CD14","AIF1","CSF1R","CTSS",#TAM = Microglia + macrophage	
                   "CLDN5","ABCB1","PECAM1","FLT1","RAMP2",#Endothelial
				   "DCN","ACTA2","RGS5","NOTCH3","CSPG4","ABCC9","KCNJ8","EPAS1")#Pericyte 周边细胞
# 区分microglia和macrophage的一些基因
# Microglia P2RY12 SALL1 CX3CR1  ITGAX （前两个比较明确）
# macrophage ITGA4  THBD MRC1 CD163 CADM1 HLA-DRA CD14（第一个比较明确）	   
p_all_markers <- DotPlot(sce.all, features = unique(genes_to_check),
                         assay = 'RNA',group.by = "RNA_snn_res.0.2")  + 
				 coord_flip()
p_all_markers
Cluster_UMAP <- DimPlot(sce.all, reduction = 'umap',#group.by = 'orig.ident',
                       label = TRUE, pt.size = 0.5,group.by = "RNA_snn_res.0.2")
p_all_markers + Cluster_UMAP
VlnPlot(sce.all, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), 
        ncol = 3,group.by = 'RNA_snn_res.0.2')

# ###单独查看cluster11的marker
cluster11.markers <- FindMarkers(sce.all, ident.1 = 11, min.pct = 0.25)
head(cluster11.markers, n = 5)
cluster11.markers[cluster11.markers$pct.1 > 0.4,]
# library(data.table)
# Markers <- data.frame(fread("./data/scRNA/GSE135045_RAW/Mouse Gene Marker.txt"))
# geneset <- Markers[,c("Cell.Type","Gene")]
# geneset$Gene <- toupper(geneset$Gene)
# cluster8.markers <- cluster8.markers[order(cluster8.markers$avg_log2FC,decreasing = T),]
# geneList <- cluster8.markers$avg_log2FC
# names(geneList) <- rownames(cluster8.markers)

# library(clusterProfiler)
# set.seed(123456)
# egmt <- GSEA(geneList, TERM2GENE=geneset, verbose=FALSE, 
             # nPerm = 10000, minGSSize = 5, maxGSSize = 1000, pvalueCutoff=1)
# gsea_results <- egmt@result
# gsea_results[,3:8]

### 需要自行看图，定细胞亚群：  
celltype <- data.frame(ClusterID = 0:10,
                       celltype = 'Unkown')
celltype[celltype$ClusterID %in% c(1),2] <- 'Myeloid cell'
celltype[celltype$ClusterID %in% c(5),2] <- 'Proliferating Myeloid cell'
celltype[celltype$ClusterID %in% c(7),2] <- 'T cell'   
celltype[celltype$ClusterID %in% c(10),2] <- 'Endothelial cell'
celltype[celltype$ClusterID %in% c(9),2] <- 'Pericyte' 
celltype[celltype$ClusterID %in% c(4),2] <- 'Oligodendrocyte' 
celltype[celltype$ClusterID %in% c(0,2,3,6,8),2] <- 'Malignant cell'
celltype 
table(celltype$celltype)

sce.all@meta.data$celltype = "NA"
Idents(object = sce.all) <- "RNA_snn_res.0.2" 
for(i in 1:nrow(celltype)){
  sce.all@meta.data[which(sce.all@meta.data$RNA_snn_res.0.2 == celltype$ClusterID[i]),
                    'celltype'] <- celltype$celltype[i]}
table(sce.all@meta.data$celltype)
          # Endothelial cell             Malignant cell               Myeloid cell 
                       # 302                      15170                       8750 
           # Oligodendrocyte                   Pericyte Proliferating Myeloid cell 
                      # 1478                        321                       1142 
                    # T cell 
                       # 593 
table(sce.all@meta.data$RNA_snn_res.0.2)
p <- DotPlot(sce.all, features = unique(genes_to_check),
             assay = 'RNA' ,group.by = 'celltype')  + 
	 coord_flip() + ggtitle(NULL) +
     theme(plot.title = element_text(hjust = 0.5)) 
p
head(sce.all@meta.data)
sce.all@meta.data$Cluster <- "unknow"
sce.all@meta.data$Cluster[sce.all@meta.data$RNA_snn_res.0.2 %in% c("0","8")] <- "C0"
sce.all@meta.data$Cluster[sce.all@meta.data$RNA_snn_res.0.2 %in% c("5")] <- "C1"
sce.all@meta.data$Cluster[sce.all@meta.data$RNA_snn_res.0.2 %in% c("2")] <- "C2"
sce.all@meta.data$Cluster[sce.all@meta.data$RNA_snn_res.0.2 %in% c("3")] <- "C3"
sce.all@meta.data$Cluster[sce.all@meta.data$RNA_snn_res.0.2 %in% c("4")] <- "C4"
sce.all@meta.data$Cluster[sce.all@meta.data$RNA_snn_res.0.2 %in% c("5")] <- "C5"
sce.all@meta.data$Cluster[sce.all@meta.data$RNA_snn_res.0.2 %in% c("6")] <- "C6"
sce.all@meta.data$Cluster[sce.all@meta.data$RNA_snn_res.0.2 %in% c("7")] <- "C7"
sce.all@meta.data$Cluster[sce.all@meta.data$RNA_snn_res.0.2 %in% c("8")] <- "C8"
sce.all@meta.data$Cluster[sce.all@meta.data$RNA_snn_res.0.2 %in% c("9")] <- "C9"
sce.all@meta.data$Cluster[sce.all@meta.data$RNA_snn_res.0.2 %in% c("10")] <- "C10"
sce.all@meta.data$Cluster <- as.character(sce.all@meta.data$Cluster)

write.table(sce.all@meta.data,file = "./results/scRNA-GSE135045/metadata.txt",
            sep = '\t',quote = F)
saveRDS(sce.all,file="./data/GSE135045_RAW/sce.all_Annotation.rds")


library(SingleR)
#refdata <- HumanPrimaryCellAtlasData()
address <- "D:/bioinformatics/scRNA-seq/3.Cell Annotation/SingleR/singleR refDataset/"
refdata <- readRDS(paste0(address,"HumanPrimaryCellAtlasData.rds"))
library(BiocParallel)
cellpred <- SingleR(test = sce.all@assays$RNA@data,  
                    ref = refdata, 
                    labels = refdata$label.main,
                    method = "cluster", 
                    clusters = sce.all@meta.data$RNA_snn_res.0.2,
                    assay.type.test = "logcounts", 
                    assay.type.ref = "logcounts")					  
cellpred$pruned.labels
plotScoreHeatmap(cellpred, clusters = cellpred@rownames, 
                 fontsize.row = 9,show_colnames = T)

# str(cellpred,max.level = 3)
# Celltype = data.frame(ClusterID = rownames(cellpred), 
                      # celltype = cellpred$labels, 
                      # stringsAsFactors = F)
# Celltype



##################################################################################################
##########################################干性与增殖打分##########################################
##################################################################################################
rm(list = ls())
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
library(Seurat)
sce.all <- readRDS("./data/GSE135045_RAW/sce.all_Annotation.rds")
library(ggplot2) 
my36colors <- c('#E5D2DD', '#53A85F', '#F1BB72', '#F3B1A0', '#D6E7A3', '#57C3F3', 
                '#476D87', '#E95C59', '#E59CC4', '#AB3282', '#23452F', '#BD956A', 
                '#8C549C', '#585658', '#9FA3A8', '#E0D4CA', '#5F3D69', '#C5DEBA', 
                '#58A4C3', '#E4C755', '#F7F398', '#AA9A59', '#E63863', '#E39A35', 
                '#C1E6F3', '#6778AE', '#91D0BE', '#B53E2B', '#712820', '#DCC1DD', 
                '#CCE0F5',  '#CCC9E6', '#625D9E', '#68A180', '#3A6963', '#968175')
sce.all@meta.data$Cluster <- factor(sce.all@meta.data$Cluster,
                                    levels = c("C0","C1","C2","C3","C4",
									           "C5","C6","C7","C8","C9","C10"))

dat <- data.frame(x = LETTERS[1:6],y = 1)
ggplot(data = dat,aes(x = x,y = y))+
  geom_col(aes(fill = x),show.legend = FALSE)+
  scale_fill_manual(values = my36colors)+#[c(2,3,4,5,6,8)+1]
  theme_bw()
Proliferation <- c("AURKA","BUB1","CCNB1","CCND1","CCNE1",
                   "DEK","E2F1","FEN1","FOXM1","H2AFZ",
                   "HMGB2","MCM2","MCM3","MCM4","MCM5",
				   "MCM6","MKI67","MYBL2","PCNA","PLK1",
				   "TOP2A","TYMS","ZWINT")
Stemnness <- c("DNMT3B","PFAS","XRCC5","HAUS6","TET1","IGF2BP1","PLAA","TEX10","MSH6","DLGAP5",
               "MTREX","SOHLH2","RRAS2","PAICS","CPSF3","LIN28B","IPO5","BMPR1A","ZNF788P","ASCC3",
               "FANCB","HMGA2","TRIM24","ORC1","HDAC2","HESX1","INHBE","MIS18A","DCUN1D5","MRPL3",
               "CENPH","MYCN","HAUS1","GDF3","TBCE","RIOK2","BCKDHB","RAD1","NREP","ADH5",
               "PLRG1","ROR1","RAB3B","DIAPH3","GNL2","FGF2","NMNAT2","KIF20A","CENPI","DDX1",
               "XXYLT1","GPR176","BBS9","RTRAF","BOD1","CDC123","SNRPD3","FAM118B","DPH3","EIF2B3",
               "RPF2","APLP1","DACT1","PDHB","C14orf119","DTD1","SAMM50","CCL26","MED20","UTP6",
               "RARS2","ARMCX2","RARS","MTHFD2","DHX15","HTR7","MTHFD1L","ARMC9","XPOT","IARS",
               "HDX","ACTRT3","ERCC2","TBC1D16","GARS","KIF7","UBE2K","SLC25A3","ICMT","UGGT2",           
               "ATP11C","SLC24A1","EIF2AK4","GPX8","ALX1","OSTC","TRPC4","HAS2","FZD2","TRNT1",
               "MMADHC","SNX8","CDH6","HAT1","SEC11A","DIMT1","TM2D2","FST","GBE1")
GeneSets <- list(Proliferation = Proliferation,Stemnness = Stemnness)

scRNA <- AddModuleScore(sce.all, features = GeneSets, 
                        name = c("Proliferation","Stemnness"), assay = "RNA")
# library(GSVA)
# expr <- as.matrix(sce.all@assays$RNA@data)#已经过log转换
# mat_ssgsea <- gsva(expr, geneSets, method="ssgsea", parallel.sz=18L)
# boxplot(t(mat_ssgsea))

AddModuleScore <- data.frame(Cluster = scRNA@meta.data$Cluster,
                             Celltype = scRNA@meta.data$celltype,
							 Proliferation = scRNA@meta.data$Proliferation1,
							 Stemnness = scRNA@meta.data$Stemnness2)
rownames(AddModuleScore) <- rownames(scRNA@meta.data)						 
AddModuleScore <- AddModuleScore[AddModuleScore$Cluster %in% 
                                 c("C1","C2","C3","C4","C5"),]
AddModuleScore$Cluster <- factor(AddModuleScore$Cluster,
                                 levels = c("C1","C2","C3","C4","C5"))

library(ggsci)
theme <- theme_bw() +
         theme(plot.title = element_text(hjust = 0.5),
		       axis.text.x = element_text(hjust = 0.5,size = 18), 
		       axis.text.y = element_text(size = 16),
		       axis.title.y = element_text(size = 18), 
		       axis.line = element_line(size = 1), 
		       legend.text = element_text(size = 14),
		       legend.title = element_text(size = 15),
		       legend.position = "none")
p_Proliferation <- ggplot(AddModuleScore,aes(x = Cluster, y = Proliferation,fill = Cluster)) + 
                   geom_violin(trim = FALSE,scale = "width",color = "white") + 
                   geom_boxplot(width = 0.15,position = position_dodge(0.9),outlier.shape = NA)+
                   scale_y_continuous(limits = c(-0.4,1.1),expand = c(0,0),breaks = seq(-0.4,1.1,0.2))+
                   #scale_fill_lancet(alpha = 0.6) + 
                   scale_fill_manual(values = my36colors[c(1,2,3,4,5,8,9)+1]) + 
                   theme + 
                   labs(title = NULL,x = NULL, y = "Relative Proliferation Score")
p_Proliferation

p_Stemnness <- ggplot(AddModuleScore,aes(x = Cluster, y = Stemnness,fill = Cluster)) + 
               geom_violin(trim = FALSE,scale = "width",color = "white") + 
               geom_boxplot(width = 0.15,position = position_dodge(0.9),outlier.shape = NA)+
               #geom_boxplot(position=position_dodge(0.9),outlier.shape=NA)+
               scale_y_continuous(limits = c(-0.15,0.25),expand = c(0,0),
	                              breaks = round(seq(-0.1,0.2,0.1),1))+
               #scale_fill_lancet(alpha = 0.6) + 
               scale_fill_manual(values = my36colors[c(1,2,3,4,5,8,9)+1]) + 
               theme + 
               labs(title = NULL,x = NULL, y = "Relative Stemnness Score")
p_Stemnness 
fit <- aov(Stemnness ~ Cluster, data = AddModuleScore) 
summary(fit)

pdf("./results/scRNA-GSE135045/Boxplot-Proliferation.pdf",width = 6,height = 4)
p_Proliferation
dev.off()

pdf("./results/scRNA-GSE135045/Boxplot-Stemnness.pdf",width = 6,height = 4)
p_Stemnness
dev.off()

##################################################################################################
########################################Cell Markers EXP##########################################
##################################################################################################
rm(list = ls())
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
library(Seurat)
sce.all <- readRDS("./data/GSE135045_RAW/sce.all_Annotation.rds")
#sce.all$celltype <- gsub("TAM","Myeloid cell",sce.all$celltype)
Idents(sce.all) <- 'celltype'
my36colors <- c('#E5D2DD', '#53A85F', '#F1BB72', '#F3B1A0', '#D6E7A3', '#57C3F3', 
                '#476D87', '#E95C59', '#E59CC4', '#AB3282', '#23452F', '#BD956A', 
                '#8C549C', '#585658', '#9FA3A8', '#E0D4CA', '#5F3D69', '#C5DEBA', 
                '#58A4C3', '#E4C755', '#F7F398', '#AA9A59', '#E63863', '#E39A35', 
                '#C1E6F3', '#6778AE', '#91D0BE', '#B53E2B', '#712820', '#DCC1DD', 
                '#CCE0F5',  '#CCC9E6', '#625D9E', '#68A180', '#3A6963', '#968175')

my10colors <- c("#db6968","#4d97cd","#459943","#fdc58f","#e8c559",
                "#a3d393","#f8984e","#005496","#f6f5ee","#99cbeb")
dat <- data.frame(x = LETTERS[1:10],y = 1)
ggplot(data = dat,aes(x = x,y = y))+
  geom_col(aes(fill = x),show.legend = FALSE)+
  scale_fill_manual(values = my10colors)+#[c(2,3,4,5,6,8)+1]
  theme_bw()

sce.all@meta.data$celltype <- factor(sce.all@meta.data$celltype,
                                     levels = c("Malignant cell",
                                                "Oligodendrocyte",
												"Pericyte","Endothelial cell",
												"Myeloid cell","Proliferating Myeloid cell",
												"T cell",
												"Unkown"))  
sce.all@meta.data$Cluster <- factor(sce.all@meta.data$Cluster,
                                    levels = c("C0","C1","C2","C3","C4",
									           "C5","C6","C7","C8","C9","C10"))
range(sce.all@reductions$umap@cell.embeddings[,1])
#[1] -9.738569 12.212759
range(sce.all@reductions$umap@cell.embeddings[,2])
#[1] -8.863019 13.331707
range(sce.all@reductions$tsne@cell.embeddings[,1])
#[1] -40.50368  42.46852
range(sce.all@reductions$tsne@cell.embeddings[,2])
#[1] -39.20396  40.38460



library(ggplot2) 
Sample_UMAP <- DimPlot(sce.all, reduction = 'umap',group.by = "orig.ident",
                        label = FALSE,  label.size = 6, pt.size = 0.5)+
				labs(x = "UMAP-1", y = "UMAP-2",title = "Sample")+
				scale_x_continuous(expand = c(0,0),limits = c(-10,12.5),breaks = seq(-9,12,3)) +
				scale_y_continuous(expand = c(0,0),limits = c(-9,13.5),breaks = seq(-9,12,3)) 
Sample_UMAP
Sample_tSNE <- DimPlot(sce.all, reduction = 'tsne',group.by = 'orig.ident',
                        label = FALSE,  label.size = 5.5, pt.size = 0.5)+
				labs(x = "tSNE-1", y = "tSNE-2",title = "Cell Type")	+
				scale_x_continuous(expand = c(0,0),limits = c(-42,45),breaks = seq(-40,40,10)) +
				scale_y_continuous(expand = c(0,0),limits = c(-42,42),breaks = seq(-40,40,10))  		
Sample_tSNE
Celltype_UMAP <- DimPlot(sce.all, reduction = 'umap',cols = my10colors[c(1:7,9)],group.by = 'celltype',
                        label = TRUE,  label.size = 5.5, pt.size = 0.5)+
				labs(x = "UMAP-1", y = "UMAP-2",title = "Cell Type")+
				scale_x_continuous(expand = c(0,0),limits = c(-10,12.5),breaks = seq(-9,12,3)) +
				scale_y_continuous(expand = c(0,0),limits = c(-9,13.5),breaks = seq(-9,12,3)) 
Celltype_tSNE <- DimPlot(sce.all, reduction = 'tsne',cols = my10colors[c(1:7,9)],group.by = 'celltype',
                        label = TRUE,  label.size = 5.5, pt.size = 0.5)+
				labs(x = "tSNE-1", y = "tSNE-2",title = "Cell Type")	+
				scale_x_continuous(expand = c(0,0),limits = c(-42,45),breaks = seq(-40,40,10)) +
				scale_y_continuous(expand = c(0,0),limits = c(-42,42),breaks = seq(-40,40,10)) 		
Cluster_UMAP <- DimPlot(sce.all, reduction = 'umap',group.by = 'Cluster',
                        cols = my36colors[c(1:7,13,8:9,12)],
                        label = TRUE,  label.size = 5.5, pt.size = 0.5)+
				labs(x = "UMAP-1", y = "UMAP-2",title = "Cell Clustering")+
				scale_x_continuous(expand = c(0,0),limits = c(-10,12.5),breaks = seq(-9,12,3)) +
				scale_y_continuous(expand = c(0,0),limits = c(-9,13.5),breaks = seq(-9,12,3)) 
Cluster_tSNE <- DimPlot(sce.all, reduction = 'tsne',group.by = 'Cluster',
                        cols= my36colors[c(1:7,13,8:9,12)],
                        label = TRUE,  label.size = 5.5, pt.size = 0.5)+
				labs(x = "tSNE-1", y = "tSNE-2",title = "Cell Clustering")+
				scale_x_continuous(expand = c(0,0),limits = c(-42,45),breaks = seq(-40,40,10)) +
				scale_y_continuous(expand = c(0,0),limits = c(-42,42),breaks = seq(-40,40,10)) 


mytheme <- theme(plot.title = element_text(hjust = 0.5,size = 18),
                 axis.text.x = element_text(hjust = 0.5,size = 18), 
                 axis.text.y = element_text(hjust = 0.5,size = 18), 
                 axis.title.x = element_text(size = 18), 
                 axis.title.y = element_text(size = 18), 
                 legend.text = element_text(size = 18),
                 legend.position = "right")

pdf("./results/scRNA-GSE135045/Cluster.pdf",width = 9,height = 6)
Celltype_UMAP + mytheme
Celltype_tSNE + mytheme
Cluster_UMAP + mytheme
Cluster_tSNE + mytheme
Sample_UMAP + mytheme
Sample_tSNE + mytheme
dev.off()


######缩减坐标tidydr：
#install.packages("tidydr")
mytheme2 <- tidydr::theme_dr(arrow = grid::arrow(length = unit(0.3, "cm"), type = "open")) +
            theme(plot.title = element_text(hjust = 0.5,size = 18),
	              legend.text = element_text(size = 18),
	              legend.title = element_text(size = 18),
	              legend.position = "right",
	              axis.title.x = element_text(size = 18), 
	              axis.title.y = element_text(size = 18))
     

Celltype_UMAP <- Celltype_UMAP + mytheme2 
Celltype_tSNE <- Celltype_tSNE + mytheme2 
Celltype_UMAP + Celltype_tSNE 
Cluster_UMAP <- Cluster_UMAP + mytheme2 
Cluster_tSNE <- Cluster_tSNE + mytheme2 
Sample_UMAP <- Sample_UMAP + mytheme2 
Sample_tSNE <- Sample_tSNE + mytheme2 
pdf("./results/scRNA-GSE135045/Cluster3.pdf",width = 8,height = 6)
Celltype_UMAP
Celltype_tSNE
Sample_UMAP
Sample_tSNE
dev.off()	 
pdf("./results/scRNA-GSE135045/Cluster3-Cluster.pdf",width = 7,height = 6)
Cluster_UMAP
Cluster_tSNE
dev.off()	
pdf("./results/scRNA-GSE135045/Cluster3-label.pdf",width = 6,height = 6)
Celltype_UMAP + NoLegend()
Celltype_tSNE + NoLegend()
Cluster_UMAP + NoLegend()
Cluster_tSNE + NoLegend()
dev.off()	


rm(list = ls())
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
library(Seurat)
sce.all <- readRDS("./data/GSE135045_RAW/sce.all_Annotation.rds")
Idents(sce.all) <- 'celltype'
my36colors <-c('#E5D2DD', '#53A85F', '#F1BB72', '#F3B1A0', '#D6E7A3', '#57C3F3', 
               '#476D87', '#E95C59', '#E59CC4', '#AB3282', '#23452F', '#BD956A', 
               '#8C549C', '#585658', '#9FA3A8', '#E0D4CA', '#5F3D69', '#C5DEBA', 
               '#58A4C3', '#E4C755', '#F7F398', '#AA9A59', '#E63863', '#E39A35', 
               '#C1E6F3', '#6778AE', '#91D0BE', '#B53E2B', '#712820', '#DCC1DD', 
               '#CCE0F5',  '#CCC9E6', '#625D9E', '#68A180', '#3A6963', '#968175')

my10colors <- c("#db6968","#4d97cd","#459943","#fdc58f","#e8c559",
               "#a3d393","#f8984e","#005496","#f6f5ee","#99cbeb")
sce.all@meta.data$celltype <- factor(sce.all@meta.data$celltype,
                                     levels = c("Malignant cell",
                                                "Oligodendrocyte",
												"Myeloid cell","T cell",
                                                "Pericyte","Endothelial cell"))    
sce.all@meta.data$Cluster <- factor(sce.all@meta.data$Cluster,
                                     levels =c("C0","C1","C2","C3","C4","C5","C6","C7",
									           "C8","C9","C10"))

library(ggplot2)
theme <- theme_bw() +
         theme(panel.border = element_rect(fill = NA,size = 1, linetype = "solid"),#加边框 
               plot.title = element_text(hjust = 0.5,size = 18),
               axis.text.x = element_text(hjust = 0.5,size = 16), 
               axis.text.y = element_text(hjust = 0.5,size = 16), 
               axis.title.x = element_text(size = 16), 
               axis.title.y = element_text(size = 16), 
               axis.line = element_line(size = 1))

VlnPlot(sce.all, features = c("RARRES2"))
VlnPlot(sce.all, features = c("IGFBP2"))
VlnPlot(sce.all, features = c("MDK"))


GeneExp_boxplot1 <- VlnPlot(sce.all,features = "IGFBP2",pt.size = 0,#点尺寸调整为0，不显示
                           slot = "data",group.by = "Cluster",cols = my36colors) + 
                   scale_y_continuous(expand = c(0,0.05))+
				   # scale_y_continuous(limits = c(0,3),expand = c(0,0.1),
	                                  # breaks = seq(0,3,0.5))+
				   theme + NoLegend() +
				   theme(axis.text.x = element_text(angle = 30,hjust = 1,size = 16)) + 
				   labs(x = "",y = "Relative Expression")
GeneExp_boxplot2 <- VlnPlot(sce.all,features = "MDK",pt.size = 0,#点尺寸调整为0，不显示
                           slot = "data",group.by = "Cluster",cols = my36colors) + 
                   scale_y_continuous(expand = c(0,0.05))+
				   # scale_y_continuous(limits = c(0,3),expand = c(0,0.1),
	                                  # breaks = seq(0,3,0.5))+
				   theme + NoLegend() +
				   theme(axis.text.x = element_text(angle = 30,hjust = 1,size = 16)) + 
				   labs(x = "",y = "Relative Expression")
GeneExp_boxplot3 <- VlnPlot(sce.all,features = "RARRES2",pt.size = 0,#点尺寸调整为0，不显示
                           slot = "data",group.by = "Cluster",cols = my36colors) + 
                   scale_y_continuous(expand = c(0,0.05))+
				   # scale_y_continuous(limits = c(0,3),expand = c(0,0.1),
	                                  # breaks = seq(0,3,0.5))+
				   theme + NoLegend() +
				   theme(axis.text.x = element_text(angle = 30,hjust = 1,size = 16)) + 
				   labs(x = "",y = "Relative Expression")
# pdf("./results/scRNA-GSE135045/Boxplot-EXP.pdf",width = 6,height = 3)
# GeneExp_boxplot1
# GeneExp_boxplot2
# GeneExp_boxplot3
# dev.off()
				
				
GeneExp_SOX2 <- FeaturePlot(sce.all, features = c("SOX2"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "SOX2")
GeneExp_SOX4 <- FeaturePlot(sce.all, features = c("SOX4"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "SOX4")
GeneExp_OLIG2 <- FeaturePlot(sce.all, features = c("OLIG2"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "OLIG2")
GeneExp_IGFBP2 <- FeaturePlot(sce.all, features = c("IGFBP2"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "IGFBP2")
GeneExp_MDK <- FeaturePlot(sce.all, features = c("MDK"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "MDK")
GeneExp_RARRES2 <- FeaturePlot(sce.all, features = c("RARRES2"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "RARRES2")

GeneExp_MBP <- FeaturePlot(sce.all, features = c("MBP"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "MBP")
GeneExp_PLP1 <- FeaturePlot(sce.all, features = c("PLP1"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "PLP1")
GeneExp_C1QA <- FeaturePlot(sce.all, features = c("C1QA"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "C1QA")
GeneExp_AIF1 <- FeaturePlot(sce.all, features = c("AIF1"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "AIF1")
GeneExp_CD3D <- FeaturePlot(sce.all, features = c("CD3D"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "CD3D")
GeneExp_CD3G <- FeaturePlot(sce.all, features = c("CD3G"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "CD3G")
GeneExp_DCN <- FeaturePlot(sce.all, features = c("DCN"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "DCN")
GeneExp_RGS5 <- FeaturePlot(sce.all, features = c("RGS5"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "RGS5")
GeneExp_ABCB1 <- FeaturePlot(sce.all, features = c("ABCB1"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "ABCB1")
GeneExp_CLDN5 <- FeaturePlot(sce.all, features = c("CLDN5"),
                            slot = "scale.data", reduction = 'umap',repel = TRUE) +
                labs(y = "UMAP-2",x="UMAP-1",title = "CLDN5")
theme <- tidydr::theme_dr(arrow = grid::arrow(length = unit(0.3, "cm"), type = "open")) +
         theme(plot.title = element_text(hjust = 0.5,size = 18),
	           legend.text = element_text(size = 16),
	           legend.title = element_text(size = 16),
	           legend.position = c(0.9, 0.8),
	           axis.title.x = element_text(size = 16), 
	           axis.title.y = element_text(size = 16))
GeneExp_SOX2 + theme 
GeneExp_IGFBP2 + theme
GeneExp_MDK + theme
GeneExp_RARRES2 + theme
# pdf("./results/scRNA-GSE135045/FeaturePlot-2.pdf",width = 4,height = 3.2)
# GeneExp_MBP + theme
# GeneExp_PLP1 + theme
# GeneExp_C1QA + theme
# GeneExp_AIF1 + theme
# GeneExp_CD3D + theme
# GeneExp_CD3G + theme
# GeneExp_DCN + theme
# GeneExp_RGS5 + theme
# GeneExp_ABCB1 + theme
# GeneExp_CLDN5 + theme
# dev.off()

# pdf("./results/scRNA-GSE135045/FeaturePlot.pdf",width = 4,height = 3.2)
# GeneExp_SOX2 + theme
# GeneExp_SOX4 + theme
# GeneExp_OLIG2 + theme
# GeneExp_IGFBP2 + theme
# GeneExp_MDK + theme
# GeneExp_RARRES2 + theme
# dev.off()

library(ggplot2)
theme <- theme_bw() +
         theme(panel.border = element_rect(fill = NA,size = 1, linetype = "solid"),#加边框 
               plot.title = element_text(hjust = 0.5,size = 18),
               axis.text.x = element_text(hjust = 0.5,size = 16), 
               axis.text.y = element_text(hjust = 0.5,size = 16), 
               axis.title.x = element_text(size = 16), 
               axis.title.y = element_text(size = 16), 
               axis.line = element_line(size = 1))
GeneExp_boxplot <- VlnPlot(sce.all,features = "FA2H",pt.size = 0,#点尺寸调整为0，不显示
                           slot = "data",group.by = "Cluster",cols = my36colors) + 
                   scale_y_continuous(limits = c(0,3),expand = c(0,0.1),
	                                  breaks = seq(0,3,0.5))+
				   theme + NoLegend() +
				   labs(x = "",y = "Relative Expression")
GeneExp_boxplot

# pdf("./results/scRNA-GSE135045/Boxplot-EXP-Cluster.pdf",width = 6,height= 4.5)
# GeneExp_boxplot
# dev.off()

# #########差异分析
# all.markers <- FindAllMarkers(sce.all, only.pos = TRUE, 
                              # min.pct = 0.25, logfc.threshold = 0.25)
# library(dplyr)
# all.markers %>% group_by(cluster) %>% top_n(n = 2, wt = avg_log2FC)
# head(all.markers, n = 5)
# library(openxlsx)
# write.xlsx(all.markers,file = "./results/scRNA-GSE135045/FindAllMarkers-celltype.xlsx",colNames = TRUE,rowNames=TRUE)

# Idents(sce.all) <- 'Cluster'
# all.markers <- FindAllMarkers(sce.all, only.pos = TRUE, 
                              # min.pct = 0.3, logfc.threshold = 0.25)
# library(dplyr)
# all.markers %>% group_by(cluster) %>% top_n(n = 2, wt = avg_log2FC)
# head(all.markers, n = 5)
# library(openxlsx)
# write.xlsx(all.markers,file = "./results/scRNA-GSE135045/FindAllMarkers-Cluster.xlsx",colNames = TRUE,rowNames=TRUE)


genes_to_check = c("SOX2","PTPRZ1","SOX4",
                   "MBP", "PLP1", "MOG", #Oligodendrocytes 少突胶质细胞
				   #"AIF1","CD68","LYZ",#Myeloid cells
				   "C1QA", "AIF1","CTSS",#TAM = Microglia + macrophage
				   "CD3D", "CD3G", "TRAC",#T lymphocytes
				   "RGS5","NOTCH3","DCN",#Pericyte 周边细胞 
				   "CLDN5", "ABCB1","VWF")#Endothelial			   
P_DotPlot <- DotPlot(sce.all, group.by = "celltype",features = genes_to_check)+
             coord_flip() + 
			 theme_bw()+#去除背景，旋转图片  
             theme(plot.title = element_text(size = 18,hjust = 0.5),
                   axis.text.x = element_text(angle = 30,hjust = 1,vjust = 1,size = 16), 
                   axis.text.y = element_text(hjust = 0.5,size = 16), 
                   axis.title.x = element_text(size = 16), 
                   axis.title.y = element_text(size = 16),
                   legend.title = element_text(size = 12),
                   legend.text = element_text(size = 12))+
             scale_color_gradientn(colors = c('blue','white','red'),limits=c(-1,2.1))+#
             labs(x = NULL, y = NULL,title = "Cell Markers")
P_DotPlot

# pdf("./results/scRNA-GSE135045/DotPlot.pdf")
# P_DotPlot
# dev.off()

# P_DotPlot <- DotPlot(sce.all, features = "FA2H",assay='RNA' ,group.by = 'celltype')+
             # theme_bw()+
             # theme(plot.title = element_text(size = 18,hjust = 0.5),
                   # axis.text.x=element_text(hjust = 0.5,vjust = 0.5,face="plain",size=16), 
                   # axis.text.y=element_text(hjust = 0.5,face="plain",size=16), 
                   # axis.title.x=element_text(size = 16,face="plain"), 
                   # axis.title.y=element_text(size = 16,face="plain"),
                   # legend.title = element_text(size=12),
                   # legend.text= element_text(size=12))+
             # scale_color_gradientn(colors = c('blue','white','red'),limits=c(-0.5,2.1))+#
             # labs(x = "", y = "",title = "Cell Markers")
# P_DotPlot			 
# pdf("./results/scRNA-GSE135045/DotPlot-FA2H.pdf",width = 5)
# P_DotPlot
# dev.off()

####heatmap				   			   
library(scRNAtoolVis)
library(ggsci)
celltype.averages <- AverageExpression(sce.all,slot = "data",group.by = "celltype")#
head(celltype.averages[["RNA"]])
celltype.averages <- celltype.averages[["RNA"]][genes_to_check,]
# save(celltype.averages,file="celltype.averages.Rdata")
celltype.averages <- as.matrix(t(scale(t(celltype.averages))))
range(celltype.averages)#[1] -0.952707  2.041236


# AverageHeatmap <- 
# AverageHeatmap(object = sce.all,
               # group.by = "ident",htRange = c(-1, 0, 2),
			   # row_title = "Cluster Marker genes",
			   # column_order = order(as.numeric(unique(sce.all$celltype))),
			   # clusterAnnoName = TRUE,showRowNames = TRUE,
			   # row_names_side = "left",
			   # border = FALSE,rect_gp = grid::gpar(col = "white", lwd = 1),
			   # fontsize = 12,
               # annoCol = TRUE,
               # myanCol = my10colors[1:6],#pal_npg("nrc", alpha = 0.6)(9),#颜色  
               # #htCol = c("#0099CC", "white", "#CC0033"),
			   # markerGene = unique(genes_to_check))
# AverageHeatmap
require(ComplexHeatmap)
library(circlize)
col_fun = colorRamp2(c(-1, 0, 2), c("#0099CC", "white", "#CC0033"))
Color <- my10colors[1:6]
names(Color) <- colnames(celltype.averages)
top_anno = HeatmapAnnotation(
    celltype = colnames(celltype.averages),
    col = list(celltype = Color),
    gp = gpar(col = "black"),
	show_legend = FALSE)

AverageHeatmap <- 
  Heatmap(matrix = celltype.averages,
          top_annotation = top_anno,
          col = col_fun,
		  border = FALSE,
		  rect_gp = grid::gpar(col = "white", lwd = 1),
          cluster_rows = FALSE,
          cluster_columns = FALSE,
          show_column_names = TRUE,
          show_row_names = TRUE,
          show_heatmap_legend = TRUE,
		  row_names_side = "left",
		  column_names_side = "top",
		  column_names_rot = 45,
          column_names_gp = gpar(fontsize = 12),
          row_names_gp = gpar(fontsize = 12),
          column_title = NULL,
          use_raster = FALSE,
          heatmap_legend_param = list(title = 'Z−score'))
AverageHeatmap



# pdf("./results/scRNA-GSE135045/Heatmap.pdf",width = 5)
# AverageHeatmap
# dev.off()			   

#######Cluster		
genes_to_check <- c("CD14","AIF1","CTSS","CD163","CTSB",#Myeloid cells
				    "PTPRZ1","SOX4","SOX2","OLIG2","GFAP","PTN",#Cancer 
				    "IGFBP2","MDK","RARRES2",
				    "MKI67","TOP2A","BIRC5","TYMS","CDK1",#Proliferating  
				    "CD2","CD3D","CD3E","CD3G","TRAC","CD52",#T
				    "MBP","PLP1","MOG","CLDN11","SOX10",#Oligodendrocytes
                    #"CD19","CD79A","IGHM","JCHAIN","IGHG1","MZB1",#B/Plasma			   
                    "DCN","LUM","COL1A1","ACTA2","NOTCH3","TAGLN",#Pericyte 周边细胞         
				    "VWF","CLDN5","ABCB1","PECAM1","FLT1","RAMP2")#Endothelial
P_DotPlot <- DotPlot(sce.all, 
                     group.by = "Cluster",
					 features = unique(genes_to_check))+
             coord_flip() + theme_bw()+#去除背景，旋转图片  
             theme(plot.title = element_text(size = 18,hjust = 0.5),
                   axis.text.x = element_text(angle = 30,hjust = 1,vjust = 1,size = 16), 
                   axis.text.y = element_text(hjust = 0.5,size = 16), 
                   axis.title.x = element_text(size = 16), 
                   axis.title.y = element_text(size = 16),
                   legend.title = element_text(size = 12),
                   legend.text= element_text(size = 12))+
             scale_color_gradientn(colors = c('blue','white','red'))+#
             labs(x = "", y = "",title = "Cell Markers")
P_DotPlot
				   
		   
Cluster.averages <- AverageExpression(sce.all,slot = "data",group.by = "Cluster")#
head(Cluster.averages[["RNA"]])
Cluster.averages <- Cluster.averages[["RNA"]][unique(genes_to_check),]
Cluster.averages <- as.matrix(t(scale(t(Cluster.averages))))
range(Cluster.averages)#[1] -1.357218  3.015084
#save(Cluster.averages,file="Cluster.averages.Rdata")

require(ComplexHeatmap)
library(circlize)
col_fun <- colorRamp2(c(-1,0,3), c("#0099CC", "white", "#CC0033"))
my36colors <- c('#E5D2DD', '#53A85F', '#F1BB72', '#F3B1A0', '#D6E7A3', '#57C3F3', 
                '#476D87', '#E95C59', '#E59CC4', '#AB3282', '#23452F', '#BD956A', 
                '#8C549C', '#585658', '#9FA3A8', '#E0D4CA', '#5F3D69', '#C5DEBA', 
                '#58A4C3', '#E4C755', '#F7F398', '#AA9A59', '#E63863', '#E39A35', 
                '#C1E6F3', '#6778AE', '#91D0BE', '#B53E2B', '#712820', '#DCC1DD', 
                '#CCE0F5', '#CCC9E6', '#625D9E', '#68A180', '#3A6963', '#968175')#颜色设置  

Color <- my36colors[1:11]
names(Color) <- colnames(Cluster.averages)
top_anno = HeatmapAnnotation(
    Cluster = colnames(Cluster.averages),
    col = list(Cluster = Color),
    gp = gpar(col ="black"),
	show_legend = FALSE)

AverageHeatmap <- 
  Heatmap(matrix = Cluster.averages,
          top_annotation = top_anno,
          col = col_fun,
		  border = FALSE,
		  rect_gp = grid::gpar(col = "white", lwd = 1),
          cluster_rows = FALSE,
          cluster_columns = FALSE,
          show_column_names = TRUE,
          show_row_names = TRUE,
          show_heatmap_legend = TRUE,
		  row_names_side = "left",
		  column_names_side = "top",
		  column_names_rot = 30,
          column_names_gp = gpar(fontsize = 12),
          row_names_gp = gpar(fontsize = 12),
          column_title = NULL,
          use_raster = FALSE,
          heatmap_legend_param = list(title = 'Z−score'))
AverageHeatmap
pdf("./results/scRNA-GSE135045/Heatmap-Cluster.pdf",width = 6,height = 8)
AverageHeatmap
dev.off()		

df <- data.frame(sce.all@meta.data[,c("celltype","Cluster")])
df <- unique(df)
df <- df[order(df$Cluster),]
colnames(df) <- c("Celltype","Cluster")

my10colors <- c("#db6968","#4d97cd","#459943","#fdc58f","#e8c559",
               "#a3d393","#f8984e","#005496","#f6f5ee","#99cbeb")
Celltype <- my10colors[1:6]
names(Celltype) <- sort(unique(df$Celltype))
Celltype <- Celltype[as.character(df$Celltype)]

Cluster <- my36colors[1:11]
names(Cluster) <- sort(unique(df$Cluster))

require(ComplexHeatmap)
library(circlize)
col_fun = colorRamp2(c(-1,0,3), c("#0099CC", "white", "#CC0033"))
top_anno = HeatmapAnnotation(
    Celltype = names(Celltype),
	Cluster = names(Cluster),
    col = list(Celltype = Celltype,
	           Cluster = Cluster),
    gp = gpar(col = "black"),
	border = TRUE,
	show_annotation_name = TRUE,
	show_legend = TRUE)

AverageHeatmap <- 
  Heatmap(matrix = Cluster.averages,
          top_annotation = top_anno,
          col = col_fun,
		  border = FALSE,
		  rect_gp = grid::gpar(col = "white", lwd = 1),
          cluster_rows = FALSE,
          cluster_columns = FALSE,
          show_column_names = FALSE,
          show_row_names = TRUE,
          show_heatmap_legend = TRUE,
		  row_names_side = "left",
		  column_names_side = "top",
		  column_names_rot = 30,
          column_names_gp = gpar(fontsize = 12),
          row_names_gp = gpar(fontsize = 12),
          column_title = NULL,
          use_raster = FALSE,
          heatmap_legend_param = list(title = 'Z−score'))
AverageHeatmap
pdf("./补/Heatmap-Cluster-2.pdf",width = 6,height = 6.5)
AverageHeatmap
dev.off()	

#install.packages("remotes")
#remotes::install_github("lyc-1995/MySeuratWrappers")
library(MySeuratWrappers)  
#需要展示的基因  markers 与 颜色设置my36colors
genes_to_check = c("SOX2","PTPRZ1",
                   "MBP", "MOG", #Oligodendrocytes 少突胶质细胞
				   "C1QA", "AIF1",#TAM = Microglia + macrophage	
				   "CD3D", "CD3G", #T lymphocytes
				   "DCN",  "RGS5",#Pericyte 周边细胞
				   "ABCB1", "PECAM1")#Endothelial		   
				   
pWrappers <- VlnPlot(sce.all, group.by = "celltype",
                     features = genes_to_check,  
                     stacked = T,pt.size = 0,  
                     cols = my10colors[1:6],#颜色  
                     direction = "horizontal", #水平作图  
                     x.lab = NULL, y.lab = NULL) + #横纵轴不标记任何东西 
             theme(axis.text.y = element_text(hjust = 0.5,size=16), 
                   axis.text.x = element_text(angle = 0,hjust = 0.5,vjust = 0.5,size = 10),   
                   axis.title.x = element_blank(), 
                   axis.title.y = element_blank(), 
                   strip.text = element_text(size = 15))#不显示坐标刻度 
pWrappers

pdf("./results/scRNA-GSE135045/Wrappers-celltype.pdf",width = 12,height = 4.5)
pWrappers
dev.off()

pWrappers <- VlnPlot(sce.all, group.by = "Cluster",
                     features = genes_to_check,  
                     stacked = T,pt.size = 0,  
                     cols = my36colors[1:11],#颜色  
                     direction = "horizontal", #水平作图  
                     x.lab = NULL, y.lab = NULL) + #横纵轴不标记任何东西 
             theme(axis.text.y = element_text(hjust = 0.5,size = 16), 
                   axis.text.x = element_text(angle = 0,hjust = 0.5,vjust = 0.5,size = 10),   
                   axis.title.x = element_blank(), 
                   axis.title.y = element_blank(), 
                   strip.text = element_text(size = 15))#不显示坐标刻度 
pWrappers

pdf("./results/scRNA-GSE135045/Wrappers-Cluster.pdf",width = 12,height = 6)
pWrappers
dev.off()

#########细胞来源比例
library(dplyr)
Ratio <- sce.all@meta.data %>%group_by(celltype,orig.ident) %>%
  count() %>%
  group_by(celltype) %>%
  mutate(Freq = n/sum(n)*100)
colnames(Ratio) <- c("Group","Celltype","N","Radio")

p <- ggplot(Ratio, aes(Group, Radio, fill = Celltype)) +
     geom_col(position = 'stack', width = 0.6) +
     geom_text(aes(label = paste(round(Radio, 1),"%")), 
               position = position_stack(vjust = 0.5))+
     scale_y_continuous(expand = c(0,0))+ 
     #scale_fill_npg()+
     scale_fill_manual(values =  my36colors) +
     labs(x = '', y = 'Relative Proportion of Sample(%)') + theme_bw()
p
theme <- theme(panel.grid = element_blank(),
               panel.border = element_rect(fill = NA,size = 1, linetype = "solid"),
               panel.background = element_blank(),
               legend.title = element_blank(),
               legend.text = element_text(size = 12),
               axis.line = element_line(size = 1),
               axis.title.y = element_text(size = 16),
			   axis.title.x = element_text(size = 16),
               axis.text.x = element_text(hjust = 0.5,size = 16),
               axis.text.y = element_text(size = 16))
p1 <- p + coord_flip() + theme
p1
pdf(file = "./results/scRNA-GSE135045/Cell Porportion-Sample.pdf",width = 20,height = 4)
p1
dev.off()

library(dplyr)
Ratio <- sce.all@meta.data %>%group_by(celltype,orig.ident) %>%
  count() %>%
  group_by(orig.ident) %>%
  mutate(Freq = n/sum(n)*100)
colnames(Ratio) <- c("Celltype","Group","N","Radio")
p <- ggplot(Ratio, aes(Group, Radio, fill = Celltype)) +
     geom_col(position = 'stack', width = 0.8) +
     # geom_text(aes(label = paste(round(Radio, 1),"%")), 
               # position = position_stack(vjust = 0.5))+
     scale_y_continuous(expand = c(0,0))+ 
     #scale_fill_npg()+
     scale_fill_manual(values =  my10colors[1:6]) +
     labs(x = NULL, y = 'Relative Proportion of Sample(%)') + theme_bw()
p
p1 <- p + coord_flip() + theme
p1


table(sce.all$orig.ident)
bs = split(colnames(sce.all),sce.all$orig.ident)
pseudobulkCount = do.call(
  cbind,lapply(names(bs), function(x){ 
    # x=names(bs)[[1]]
    kp = colnames(sce.all) %in% bs[[x]]
    rowSums(as.matrix(sce.all@assays$RNA@counts[, kp]))
  })
)
colnames(pseudobulkCount) <- names(bs)
head(pseudobulkCount)
pseudobulkCPM <- edgeR::cpm(pseudobulkCount, log = TRUE)
pseudobulkCPM[c("IGFBP2","MDK","RARRES2"),]
