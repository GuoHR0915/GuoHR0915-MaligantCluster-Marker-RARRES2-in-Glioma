rm(list = ls())
options(stringsAsFactors = F)
setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
library(forestplot)  
library(readxl) 
forest <- read_excel("./results/Step4.Univartiate Cox Merge.xlsx")
subgps <- c(3,4,5,8,9,10,13,14,15,18,19,20,23,24,25,26) 
# 指定要缩进的亚组，此处向量中的数字表示亚组的行数
forest$Variable[subgps] <- paste("    ",forest$Variable[subgps])  
lapply(subgps,function(x){as.character(as.numeric(forest[x,6]))})

forest[subgps,6] <- unlist(lapply(subgps,function(x){as.character(as.numeric(forest[x,6]))}))

attach(forest) 
labeltext <- as.matrix(forest[,c(1,2,6)])   
forestplot(labeltext,  # 图形文本部分            
           mean = HR,  # 图形 HR 部分(mean)            
           lower = LowerCI, # 95%CI下限(lower)            
           upper = UpperCI) # 95%CI上限(upper)

pdf("./results/Step4.Univartiate Cox Merge-1.pdf",width = 9)
forestplot(labeltext,  # 图形文本部分 
           mean = HR,  # 图形 HR 部分 
           lower = LowerCI, # 95%CI下限           
           upper = UpperCI, # 95%CI上限
           #箱线图中基准线的位置
           zero = 1.0, lwd.zero = 2, # 设置无效线的横坐标和线条宽度
           xlab = "<Hazard ratio>", # 设置x轴标题 
		   # xlog = TRUE,
		   graph.pos = 3,
           # clip = c(0.2,2.2),
		   # xticks = c(0.25,0.5,1,2),
           cex = 0.9, lineheight = "auto",
           lwd.xaxis = 2, # 设置x轴的宽度
           boxsize = 0.35, # 设置Box的大小，保持大小一样
           lty.ci = 1, lwd.ci = 2, # 森林图置信区间的线条类型和宽度
           ci.vertices = TRUE,  # 森林图置信区间两端添加小竖线，默认FALSE
           ci.vertices.height = 0.2, # 设置森林图置信区间两端小竖线的高度，默认0.1
           is.summary = c(T,T,F,F,F,F,T,F,F,F,F,T,F,F,F),  
           col=fpColors(box = "#1c61b6", lines = "#1c61b6", zero = "gray50"), ##fpColors函数设置颜色
           txt_gp = fpTxtGp(label = gpar(cex = 1.15), # 设置文本字体大小
                            ticks = gpar(cex = 1.20), # 设置坐标轴刻度大小
                            xlab = gpar(cex = 1.45))) # 设置坐标轴标题大小
dev.off()
