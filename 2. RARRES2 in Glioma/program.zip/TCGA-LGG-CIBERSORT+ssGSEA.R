rm(list = ls())
setwd("D:/Temp/9-RARRES2 in Glioma") 
########################################################
#######################提取表达量########################
########################################################
Gene <- "RARRES2"
load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-LGG-GeneSymbol.Rdata')
exprSet <- data.frame(SampleNames = colnames(exp_TPM),
                      Expression = as.numeric(exp_TPM[Gene,]),
                      SampleType = sapply(strsplit(colnames(exp_TPM),'-'),"[",4))
exprSet$Group <- ifelse(as.numeric(substr(exprSet$SampleType,1,2)) < 10,"Tumor","Normal")
table(exprSet$SampleType)
# 01A 01B 02A 02B 
# 505  11  14   4 
table(exprSet$Group)


exprSet$ID <- substr(exprSet$SampleNames,1,12)
##仅保留肿瘤样本
exprSet <- exprSet[exprSet$Group == "Tumor",]
table(exprSet$Group)
##仅保留原发癌样本 & A
exprSet <- exprSet[exprSet$SampleType %in% c("01A"),]
table(exprSet$SampleType)
head(exprSet)
exp_TPM <- exp_TPM[,exprSet$SampleNames]


########################################################
########################CIBERSORT#######################
########################################################
set.seed(12345)
# library(CIBERSORT)
# #读取包自带的LM22文件（免疫细胞特征基因文件）
# data(LM22)
# LM22[1:4,1:4]#547 22
# CIBERSORT <- cibersort(sig_matrix = LM22, mixture_file = exp_TPM,perm = 1000,QN = F)
library(IOBR)
CIBERSORT <- deconvo_tme(eset = exp_TPM, 
                         method = "cibersort", 
                         arrays = FALSE, #取消微阵列数据优化
                         perm = 1000,
						 absolute.mode = T)
CIBERSORT[1:4,1:4]
rownames(CIBERSORT) <- CIBERSORT$ID
colnames(CIBERSORT)
identical(rownames(CIBERSORT),exprSet$SampleNames)
exprSet2 <- cbind(exprSet,CIBERSORT[,-1])
TCGALGG <- exprSet2	

library(ggpubr)
cor.test(exprSet2$Expression,exprSet2$Macrophages_M0_CIBERSORT,method = 'spearman')
cor.test(exprSet2$Expression,exprSet2$Macrophages_M1_CIBERSORT,method = 'spearman')
cor.test(exprSet2$Expression,exprSet2$Macrophages_M2_CIBERSORT,method = 'spearman')

p1 <- ggplot(exprSet2,aes(x = log2(Expression+1), y = Macrophages_M2_CIBERSORT)) + 
      #xlim(-20,15) + ylim(-15,10) +
      labs(x = "Gene Expression", y = "Macrophages M2") +
      geom_point(colour = "#368ad9",size = 4) +
      geom_smooth(method ='lm') +
      stat_cor(method = "spearman",size = 8) +
      theme_bw() + 
      theme(axis.text.x = element_text(size = 18), 
            axis.text.y = element_text(size = 18), 
            axis.title.x = element_text(size = 20), 
            axis.title.y = element_text(size = 20),
            legend.title = element_blank(),
            legend.text = element_text(size=19))
p1

########################################################
##########################GSVA##########################
########################################################
MacrophageM1 <- c("NOS2","IL12","CD64","CD80","CXCR10","IL23","CXCL9","CXCL10","CXCL11","CD86",
				  "IL1A","IL1B","IL6","TNF","CCL5","IRF5","IRF1","CD40","IDO1","KYNU",
				  "CCR7")
MacrophageM2 <- c("ARG1","ARG2","IL10","CD32","CD163","FCER2","CD200R1","PDCD1LG2","CD274","MARCO",
				  "CSF1R","MRC1","IL1RN","Il1R2","IL4R","CCL4","CCL13","CCL20","CCL17","CCL18",
				  "CCL22","CCL24","LYVE1","VEGFA","VEGFB","VEGFC","VEGFD","EGF","CTSA","CTSB",
				  "CSTC","CTSD","TGFB1","TGFB2","TGFB3","MMP14","MMP19","MMP9","CLEC7A","WNT7B",
				  "FASL","TNFSF12","TNFSF8","CD276","VTCN1","MSR1","FN1","IRF4")
Proinflammatory <- c("IL1A","IL1B","TNF","IFNG","TBX21","CCL3","CCL4","PRF1","GZMA","GZMB",
                     "GZMK","GZMH","CD8A","FASLG","CCL2","CCL20","IL2","IL6","IL12A","IL17A",
					 "IL23A","PTGS2","TLR4","TNF")
Antiinflammatory <- c("TIGIT","IDO1","LGALS3","PDCD1","FOXP3","ENTPD1","CD274","CSF2","CTLA4","CXCL12",
                      "CXCL5","CXCL8","MIF","PTGS2","VEGFA")

library(GSVA)
gs <- list(MacrophageM1 = MacrophageM1,
           MacrophageM2 = MacrophageM2,
		   Proinflammatory = Proinflammatory,
		   Antiinflammatory = Antiinflammatory)
gsva.es <- gsva(expr = log2(exp_TPM + 1), 
                gset.idx.list = gs,
                method = 'ssgsea',
                kcdf = 'Gaussian',
                verbose = FALSE)
dim(gsva.es)#[1] 100  30
gsva.es[,1:5]
identical(colnames(gsva.es),exprSet$SampleNames)
exprSet2 <- cbind(exprSet,t(gsva.es))

library(ggplot2)
library(ggpubr)
cor.test(exprSet2$Expression,exprSet2$MacrophageM1,method = 'spearman')
cor.test(exprSet2$Expression,exprSet2$MacrophageM2,method = 'spearman')
p1 <- ggplot(exprSet2,aes(x = log2(Expression+1), y = Proinflammatory)) + 
      #xlim(-20,15) + ylim(-15,10) +
      labs(x = "Gene Expression", y = "Pro-inflammatory Score") +
      geom_point(colour = "#368ad9",size = 4) +
      geom_smooth(method ='lm') +
      stat_cor(method = "spearman",size = 8) +
      theme_bw() + 
      theme(axis.text.x = element_text(size = 18), 
            axis.text.y = element_text(size = 18), 
            axis.title.x = element_text(size = 20), 
            axis.title.y = element_text(size = 20),
            legend.title = element_blank(),
            legend.text = element_text(size=19))
p1
p2 <- ggplot(exprSet2,aes(x = log2(Expression+1), y = Antiinflammatory)) + 
      #xlim(-20,15) + ylim(-15,10) +
      labs(x = "Gene Expression", y = "Anti-inflammatory Score") +
      geom_point(colour = "#368ad9",size = 4) +
      geom_smooth(method ='lm') +
      stat_cor(method = "spearman",size = 8) +
      theme_bw() + 
      theme(axis.text.x = element_text(size = 18), 
            axis.text.y = element_text(size = 18), 
            axis.title.x = element_text(size = 20), 
            axis.title.y = element_text(size = 20),
            legend.title = element_blank(),
            legend.text = element_text(size=19))
p2

