library(ggplot2)
mytheme <- theme_bw() + 
           theme(plot.title = element_text(hjust = 0.5,size = 24),
		         strip.text = element_text(size = 20),
                 axis.line = element_line(color = "black",size = 0.4),
                 axis.text.y = element_text(color = "black",size = 20),
                 axis.text.x = element_text(color = "black",size = 20),
                 axis.title = element_blank(),
                 panel.grid.minor = element_blank(),
                 panel.grid.major = element_line(size = 0.2,color = "#e5e5e5"),
				 legend.text = element_text(size = 24),
				 legend.title = element_blank(),
                 legend.position = "bottom")
##mRNA_array_301
DataROC <- data.frame(Cindex = c(0.567,0.575,0.649,0.609,
                                 0.557,0.511,0.584,0.557,
							     0.526,0.526,0.53,0.532),
					  Group = rep(rev(c("RARRES2","RARRES2+GPR1","RARRES2+CMKLR1","RARRES2+CCRL2")),3),
					  Group2 = rep(c("GSE74187-GBM","GSE42669-GBM","GSE107850-LGG"),each = 4))
# 绘制并列条形图
pROC <- ggplot(DataROC, aes(x = Group2, y = Cindex, fill = Group)) +
        geom_bar(stat = "identity", position = position_dodge()) +
        labs(title = NULL, x = NULL, y = "AUC", fill = NULL) +
        scale_fill_manual(values = c("#db6968","#4d97cd","#99cbeb","#fdc58f")) + 
		scale_y_continuous(expand = c(0,0),limits = c(0,0.65),
		                   breaks = seq(0,0.6,0.1),
						   labels = seq(0,0.6,0.1)) +
		coord_flip() + 
        mytheme
# 在每个柱子上添加文字
pROC + geom_text(aes(y = 0.25,label = Cindex), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 8)
pdf("./results/step4.ROC-mRNAarray301.pdf",height = 5.5,width = 6)
pROC + geom_text(aes(y = 0.25,label = Label), 
                 position = position_dodge(width = 0.9),
				 color = 'white',size = 7)
dev.off()