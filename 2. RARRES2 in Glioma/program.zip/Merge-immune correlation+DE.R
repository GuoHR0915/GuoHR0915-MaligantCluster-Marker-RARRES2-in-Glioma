rm(list = ls())
gc()
options(stringsAsFactors = FALSE)
setwd("D:/Temp/9-RARRES2 in Glioma") 
load(file = "./data/CIBERSORT.Rdata")
ls()
##[1] "CGGAmRNAseq325" "CGGAmRNAseq693" "TCGAGBM"        "TCGALGG"      
cor.test(TCGAGBM$Expression,TCGAGBM$Macrophages_M0_CIBERSORT,method = 'spearman')
cor.test(TCGAGBM$Expression,TCGAGBM$Macrophages_M1_CIBERSORT,method = 'spearman')
cor.test(TCGAGBM$Expression,TCGAGBM$Macrophages_M2_CIBERSORT,method = 'spearman')
Celllist <- c("T_cells_CD8_CIBERSORT",
              "NK_cells_resting_CIBERSORT","NK_cells_activated_CIBERSORT",
              "Monocytes_CIBERSORT","Macrophages_M0_CIBERSORT",
              "Macrophages_M1_CIBERSORT","Macrophages_M2_CIBERSORT",
              "Dendritic_cells_resting_CIBERSORT","Dendritic_cells_activated_CIBERSORT")



#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(Celllist,function(x){
	GeneA <- as.numeric(CGGAmRNAseq325[,x])
    GeneB <- as.numeric(CGGAmRNAseq325[,"Expression"])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "spearman")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- Celllist
head(Correlation)
CGGA325 <- Correlation	
CGGA325$Cohort <- "mRNAseq325"

Correlation <- lapply(Celllist,function(x){
	GeneA <- as.numeric(CGGAmRNAseq693[,x])
    GeneB <- as.numeric(CGGAmRNAseq693[,"Expression"])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "spearman")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- Celllist
head(Correlation)
CGGA693 <- Correlation	
CGGA693$Cohort <- "mRNAseq693"

Correlation <- lapply(Celllist,function(x){
	GeneA <- as.numeric(TCGAGBM[,x])
    GeneB <- as.numeric(TCGAGBM[,"Expression"])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "spearman")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- Celllist
head(Correlation)
TCGAGBM <- Correlation	
TCGAGBM$Cohort <- "TCGA-GBM"

Correlation <- lapply(Celllist,function(x){
	GeneA <- as.numeric(TCGALGG[,x])
    GeneB <- as.numeric(TCGALGG[,"Expression"])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "spearman")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- Celllist
head(Correlation)
TCGALGG <- Correlation	
TCGALGG$Cohort <- "TCGA-LGG"

#################################################################
#############################绘制热图############################
#################################################################
dft <- rbind(TCGAGBM,TCGALGG,CGGA325,CGGA693)
library(dplyr)
tmp <- case_when(as.vector(dft$Pvalue) < 0.001~"****",
                 as.vector(dft$Pvalue) < 0.001~"***",
                 as.vector(dft$Pvalue) < 0.01~"**",
                 as.vector(dft$Pvalue) < 0.05~"*",
                 T~ "")
tmp
dft$label <- tmp


dft$Gene <- rep(Celllist,4)
range(dft$R)#[1] -0.1339148  0.4898977
head(dft)
                                             # R     Pvalue   Cohort label                                Gene
# Monocytes_CIBERSORT                 0.10014812 0.22908502 TCGA-GBM                       Monocytes_CIBERSORT
# Macrophages_M0_CIBERSORT            0.05873904 0.48127442 TCGA-GBM                  Macrophages_M0_CIBERSORT
# Macrophages_M1_CIBERSORT            0.08414873 0.31257887 TCGA-GBM                  Macrophages_M1_CIBERSORT
# Macrophages_M2_CIBERSORT            0.10559610 0.20461769 TCGA-GBM                  Macrophages_M2_CIBERSORT
# Dendritic_cells_resting_CIBERSORT   0.05063135 0.54390944 TCGA-GBM         Dendritic_cells_resting_CIBERSORT
# Dendritic_cells_activated_CIBERSORT 0.15691436 0.05856557 TCGA-GBM       Dendritic_cells_activated_CIBERSORT
dft$Cohort <- factor(dft$Cohort,levels = unique(dft$Cohort))
dft$Gene <- gsub("_"," ",dft$Gene)
dft$Gene <- gsub("CIBERSORT","",dft$Gene)
#dft$Gene <- factor(dft$Gene,levels = rev(Celllist))

ESTIMATE <- data.frame(R = c(0.18,0.14,0.28,0.51),
                       Pvalue = c(0.028,0.0012,0,0),
					   Cohort = c("TCGA-GBM","TCGA-LGG","mRNAseq325","mRNAseq693"),
					   label = c("*","**","****","****"),
					   Gene = "Immune Score")

dft <- rbind(dft,ESTIMATE)
dft$Gene <- factor(dft$Gene,levels = rev(c("Immune Score","T cells CD8 ",
                                       "NK cells resting ","NK cells activated ",
									   "Monocytes ","Macrophages M0 ","Macrophages M1 ","Macrophages M2 ",
									   "Dendritic cells resting ","Dendritic cells activated ")))   
library(ggplot2)
library(paletteer)
library(ggthemes)
theme1 <- theme_minimal()+
          theme(panel.border = element_rect(fill = NA,size = 1, linetype = "solid"),
                panel.grid = element_blank(),
                axis.ticks.y = element_blank(),
                plot.title = element_text(hjust = 0.5,size = 26),
                axis.text.x = element_text(angle = 30,hjust = 1,size = 26),
                axis.text.y = element_text(size = 26))
Heatmap <- ggplot(data = dft,aes(x = Cohort,y = Gene)) +
           geom_tile(aes(fill = R),color = "grey") +
           geom_text(aes(label = label),size = 12) +
           scale_x_discrete(expand = c(0,0)) + 
           scale_y_discrete(expand = c(0,0)) +
		   scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        name = "Correlation level",midpoint = 0,
		                        limits = c(-0.51,0.51),breaks = seq(-0.4,0.4,0.2)) + 
           # scale_fill_paletteer_c("ggthemes::Classic Red-Blue",
                                  # direction = -1,
                                  # name="Correlation level",
                                  # limits = c(-0.5,0.7),
							      # breaks = seq(-0.4,0.6,0.2)) +
		   labs(title = NULL, x = NULL, y = NULL) + theme1		 
# ####拉长图例
Heatmap2 <- Heatmap + theme(legend.position = "top",
                            legend.text = element_text(color = "black",size = 24),
                            legend.title = element_blank()) +
			guides(fill = guide_colorbar(barwidth = 20,barheight = 2,ticks = TRUE))    				
Heatmap2                           

pdf("D:/Temp/9-RARRES2 in Glioma/results/Correlation-Macrophages2.pdf",
     height = 7.5,width = 9)
print(Heatmap2)
dev.off()			

Heatmap2 <- Heatmap + theme(legend.position = "right",
                            legend.text = element_text(color = "black",size = 24),
                            legend.title = element_blank()) +
			guides(fill = guide_colorbar(barwidth = 2,barheight = 15,ticks = TRUE))    				
Heatmap2                           

pdf("D:/Temp/9-RARRES2 in Glioma/results/Correlation-Macrophages.pdf",
     height = 6.5,width = 12)
print(Heatmap2)
dev.off()	

dft$Gene <- factor(dft$Gene,levels = Celllist)
dft$Cohort <- factor(dft$Cohort,levels = rev(unique(dft$Cohort)))
Heatmap <- ggplot(data = dft,aes(x = Gene,y = Cohort)) +
           geom_tile(aes(fill = R),color = "grey") +
           geom_text(aes(label = label),size = 8) +
           scale_x_discrete(expand = c(0,0)) + 
           scale_y_discrete(expand = c(0,0)) +
		   scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        name = "Correlation level",midpoint = 0,
		                        limits = c(-0.6,0.6),breaks = seq(-0.6,0.6,0.3)) + 
           # scale_fill_paletteer_c("ggthemes::Classic Red-Blue",
                                  # direction = -1,
                                  # name="Correlation level",
                                  # limits = c(-0.5,0.7),
							      # breaks = seq(-0.4,0.6,0.2)) +
		   labs(title = NULL, x = NULL, y = NULL) + theme1		 
# ####拉长图例
Heatmap2 <- Heatmap + theme(legend.position = "right",
                            legend.text = element_text(color = "black",size = 24),
                            legend.title = element_blank()) +
			guides(fill = guide_colorbar(barwidth = 1.5,barheight = 10,ticks = TRUE))    				
Heatmap2                           

pdf("D:/Temp/9-RARRES2 in Glioma/results/Correlation-Geneset-2.pdf",
     height = 4,width = 14)
print(Heatmap2)
dev.off()			



rm(list = ls())
gc()
options(stringsAsFactors = FALSE)
setwd("D:/Temp/9-RARRES2 in Glioma") 
load(file = "./data/CIBERSORT.Rdata")
ls()
##[1] "CGGAmRNAseq325" "CGGAmRNAseq693" "TCGAGBM"        "TCGALGG"      
cor.test(TCGAGBM$Expression,TCGAGBM$Macrophages_M0_CIBERSORT,method = 'spearman')
cor.test(TCGAGBM$Expression,TCGAGBM$Macrophages_M1_CIBERSORT,method = 'spearman')
cor.test(TCGAGBM$Expression,TCGAGBM$Macrophages_M2_CIBERSORT,method = 'spearman')
Celllist <- c("T_cells_CD8_CIBERSORT",
              "NK_cells_resting_CIBERSORT","NK_cells_activated_CIBERSORT",
              "Monocytes_CIBERSORT","Macrophages_M0_CIBERSORT",
              "Macrophages_M1_CIBERSORT","Macrophages_M2_CIBERSORT",
              "Dendritic_cells_resting_CIBERSORT","Dendritic_cells_activated_CIBERSORT")
#####################
###########TCGAGBM
#####################
TCGAGBM$Group <- ifelse(as.numeric(TCGAGBM[,"Expression"]) > 
                              median(as.numeric(TCGAGBM[,"Expression"])),"High","Low")
table(TCGAGBM$Group)

TCGAGBM$Group <- "Median"
quantile(as.numeric(TCGAGBM[,"Expression"]),0.7)
TCGAGBM$Group[as.numeric(TCGAGBM[,"Expression"]) > quantile(as.numeric(TCGAGBM[,"Expression"]),0.7)] <- "High"
TCGAGBM$Group[as.numeric(TCGAGBM[,"Expression"]) < quantile(as.numeric(TCGAGBM[,"Expression"]),0.3)] <- "Low"
table(TCGAGBM$Group)
TCGAGBM <- TCGAGBM[TCGAGBM$Group != "Median",]
table(TCGAGBM$Group)


library(tidyr)
# 使用 pivot_longer 转换数据
TCGAGBM2 <- pivot_longer(
  data = TCGAGBM[,c(Celllist,"Group","SampleNames")],
  cols = Celllist,  # 选择需要转换的列:
  names_to = "CellType",        # 新列名：存储原列名（变量名）
  values_to = "Fraction"           # 新列名：存储对应的值
)
head(TCGAGBM2)
# # A tibble: 6 × 4
  # Group SampleNames                  CellType                     Fraction
  # <chr> <chr>                        <chr>                           <dbl>

TCGAGBM2$Group <- factor(TCGAGBM2$Group,levels = c("Low","High"))
TCGAGBM2$CellType <- gsub("_CIBERSORT","",TCGAGBM2$CellType)
TCGAGBM2$CellType <- gsub("_"," ",TCGAGBM2$CellType)
head(TCGAGBM2)
TCGAGBM2$CellType <- factor(TCGAGBM2$CellType,levels = unique(TCGAGBM2$CellType))

pTCGAGBM <- ggplot(TCGAGBM2,aes(x = CellType,y = Fraction,fill = Group)) +
       geom_boxplot(outlier.shape = NA, width = 0.8) +
       scale_fill_manual(values = c("#377EB8","#E41A1C")) +
       scale_y_continuous(expand = c(0,0),limits = c(-0.02,1),breaks = seq(0,1,0.25)) +
	   labs(x = NULL,y = 'Relative Proportion',title = "TCGA-GBM") +
       theme_bw() +
       theme(axis.text.x = element_text(angle = 30, hjust = 1, vjust = 1,size = 20), 
             axis.text.y = element_text(size = 20), 
             axis.title.x = element_blank(),
             axis.title.y = element_text(size = 20), 
			 plot.title = element_text(size = 24,hjust = 0.5),
             legend.title = element_blank(),
             legend.text = element_text(size = 22),
             legend.position = "bottom")
library(ggpubr)
pTCGAGBM <- pTCGAGBM + stat_compare_means(aes(group = Group,label = ..p.signif..),
                              method = "t.test",label.y = 0.9,size = 10)
pTCGAGBM

# #每组最大值——显著性符号的位置
# library(dplyr)
# Marker <- TCGAGBM2 %>% group_by(CellType,Group) %>% summarise(Max = max(Fraction))
# Marker <- Marker[order(Marker$CellType,Marker$Max,decreasing = T),]
# Marker <- Marker[!duplicated(Marker$CellType),]
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# Marker <- Marker[order(Marker$CellType,decreasing = T),]
# Marker$X <- 1:nrow(Marker)

# ##确保Marker与TCGAGBM2的顺序对应
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# pTCGAGBM <- ggplot(TCGAGBM2,aes(x = CellType,y = Fraction,fill = Group)) +
       # geom_violin(scale = "width",alpha = 0.6,size = 0.5,width = 1)+
       # ##去除本体，仅保留两侧胡须
       # geom_boxplot(width = 0, position = position_dodge(1), 
                    # outlier.shape = NA,alpha = 0.1,show.legend = FALSE) +
       # ##中位数点
       # stat_summary(fun.y = "median",geom = "point",shape = 16, 
                    # size = 3, color = "white",position = position_dodge(1))+
       # #分组添加颜色
       # scale_fill_manual(values = c("#377EB8","#E41A1C")) +  
       # #设置纵坐标
      # # scale_y_continuous(expand = c(0,0),limits = c(0,0.75),breaks = seq(0,0.6,0.2)) +
       # #按分组进行统计检验
       # stat_compare_means(aes(group = Group), 
                          # method = "wilcox",
                          # paired = F,
                          # symnum.args = list(cutpoint = c(0,0.001,0.01,0.05,1),
                                        # symbols = c("***","**","*","NS.")),
                          # label = "p.signif",
                          # label.y = Marker$Max + 0.03,      #显著性符号的位置
                          # size = 8) +                               
       # #在显著性符号下面添加一条短线
       # geom_segment(data = Marker,
                    # aes(x = X - 0.2,y = Max,
                        # xend = X + 0.2,yend = Max),
                    # size = 0.8) +
       # labs(x = NULL,y = 'Relative Proportion',fill = NULL) +
       # theme_bw() +
       # theme(axis.text.x = element_text(angle = 30, hjust = 1, vjust = 1,size = 20), 
             # axis.text.y = element_text(size = 20), 
             # axis.title.x = element_blank(),
             # axis.title.y = element_text(size = 20), 
             # panel.border = element_rect(size = 1.2),
             # legend.title = element_blank(),
             # legend.text = element_text(size = 22),
             # legend.position = c(0.1,0.8))
# pTCGAGBM

#####################
###########TCGALGG
#####################
TCGALGG$Group <- ifelse(as.numeric(TCGALGG[,"Expression"]) > 
                              median(as.numeric(TCGALGG[,"Expression"])),"High","Low")
table(TCGALGG$Group)

TCGALGG$Group <- "Median"
quantile(as.numeric(TCGALGG[,"Expression"]),0.7)
TCGALGG$Group[as.numeric(TCGALGG[,"Expression"]) > quantile(as.numeric(TCGALGG[,"Expression"]),0.7)] <- "High"
TCGALGG$Group[as.numeric(TCGALGG[,"Expression"]) < quantile(as.numeric(TCGALGG[,"Expression"]),0.3)] <- "Low"
table(TCGALGG$Group)
TCGALGG <- TCGALGG[TCGALGG$Group != "Median",]
table(TCGALGG$Group)


library(tidyr)
# 使用 pivot_longer 转换数据
TCGALGG2 <- pivot_longer(
  data = TCGALGG[,c(Celllist,"Group","SampleNames")],
  cols = Celllist,  # 选择需要转换的列:
  names_to = "CellType",        # 新列名：存储原列名（变量名）
  values_to = "Fraction"           # 新列名：存储对应的值
)
head(TCGALGG2)
# # A tibble: 6 × 4
  # Group SampleNames                  CellType                     Fraction
  # <chr> <chr>                        <chr>                           <dbl>

TCGALGG2$Group <- factor(TCGALGG2$Group,levels = c("Low","High"))
TCGALGG2$CellType <- gsub("_CIBERSORT","",TCGALGG2$CellType)
TCGALGG2$CellType <- gsub("_"," ",TCGALGG2$CellType)
head(TCGALGG2)
TCGALGG2$CellType <- factor(TCGALGG2$CellType,levels = unique(TCGALGG2$CellType))

pTCGALGG <- ggplot(TCGALGG2,aes(x = CellType,y = Fraction,fill = Group)) +
       geom_boxplot(outlier.shape = NA, width = 0.8) +
       scale_fill_manual(values = c("#377EB8","#E41A1C")) +
       scale_y_continuous(expand = c(0,0),limits = c(-0.02,1),breaks = seq(0,1,0.25)) +
	   labs(x = NULL,y = 'Relative Proportion',title = "TCGA-LGG") +
       theme_bw() +
       theme(axis.text.x = element_text(angle = 30, hjust = 1, vjust = 1,size = 20), 
             axis.text.y = element_text(size = 20), 
             axis.title.x = element_blank(),
             axis.title.y = element_text(size = 20), 
			 plot.title = element_text(size = 24,hjust = 0.5),
             legend.title = element_blank(),
             legend.text = element_text(size = 22),
             legend.position = "bottom")
library(ggpubr)
pTCGALGG <- pTCGALGG + stat_compare_means(aes(group = Group,label = ..p.signif..),
                              method = "t.test",label.y = 0.9,size = 10)
pTCGALGG

# #每组最大值——显著性符号的位置
# library(dplyr)
# Marker <- TCGALGG2 %>% group_by(CellType,Group) %>% summarise(Max = max(Fraction))
# Marker <- Marker[order(Marker$CellType,Marker$Max,decreasing = T),]
# Marker <- Marker[!duplicated(Marker$CellType),]
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# Marker <- Marker[order(Marker$CellType,decreasing = T),]
# Marker$X <- 1:nrow(Marker)

# ##确保Marker与TCGALGG2的顺序对应
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# pTCGALGG <- ggplot(TCGALGG2,aes(x = CellType,y = Fraction,fill = Group)) +
       # geom_violin(scale = "width",alpha = 0.6,size = 0.5,width = 1)+
       # ##去除本体，仅保留两侧胡须
       # geom_boxplot(width = 0, position = position_dodge(1), 
                    # outlier.shape = NA,alpha = 0.1,show.legend = FALSE) +
       # ##中位数点
       # stat_summary(fun.y = "median",geom = "point",shape = 16, 
                    # size = 3, color = "white",position = position_dodge(1))+
       # #分组添加颜色
       # scale_fill_manual(values = c("#377EB8","#E41A1C")) +  
       # #设置纵坐标
      # # scale_y_continuous(expand = c(0,0),limits = c(0,0.75),breaks = seq(0,0.6,0.2)) +
       # #按分组进行统计检验
       # stat_compare_means(aes(group = Group), 
                          # method = "wilcox",
                          # paired = F,
                          # symnum.args = list(cutpoint = c(0,0.001,0.01,0.05,1),
                                        # symbols = c("***","**","*","NS.")),
                          # label = "p.signif",
                          # label.y = Marker$Max + 0.03,      #显著性符号的位置
                          # size = 8) +                               
       # #在显著性符号下面添加一条短线
       # geom_segment(data = Marker,
                    # aes(x = X - 0.2,y = Max,
                        # xend = X + 0.2,yend = Max),
                    # size = 0.8) +
       # labs(x = NULL,y = 'Relative Proportion',fill = NULL) +
       # theme_bw() +
       # theme(axis.text.x = element_text(angle = 30, hjust = 1, vjust = 1,size = 20), 
             # axis.text.y = element_text(size = 20), 
             # axis.title.x = element_blank(),
             # axis.title.y = element_text(size = 20), 
             # panel.border = element_rect(size = 1.2),
             # legend.title = element_blank(),
             # legend.text = element_text(size = 22),
             # legend.position = c(0.1,0.8))
# pTCGALGG

#####################
###########CGGAmRNAseq325
#####################
# CGGAmRNAseq325$Group <- ifelse(as.numeric(CGGAmRNAseq325[,"Expression"]) > 
                              # median(as.numeric(CGGAmRNAseq325[,"Expression"])),"High","Low")
# table(CGGAmRNAseq325$Group)
CGGAmRNAseq325$Group <- "Median"
quantile(as.numeric(CGGAmRNAseq325[,"Expression"]),0.7)
CGGAmRNAseq325$Group[as.numeric(CGGAmRNAseq325[,"Expression"]) > quantile(as.numeric(CGGAmRNAseq325[,"Expression"]),0.7)] <- "High"
CGGAmRNAseq325$Group[as.numeric(CGGAmRNAseq325[,"Expression"]) < quantile(as.numeric(CGGAmRNAseq325[,"Expression"]),0.3)] <- "Low"
table(CGGAmRNAseq325$Group)
CGGAmRNAseq325 <- CGGAmRNAseq325[CGGAmRNAseq325$Group != "Median",]
table(CGGAmRNAseq325$Group)


library(tidyr)
# 使用 pivot_longer 转换数据
CGGAmRNAseq3252 <- pivot_longer(
  data = CGGAmRNAseq325[,c(Celllist,"Group","SampleNames")],
  cols = Celllist,  # 选择需要转换的列:
  names_to = "CellType",        # 新列名：存储原列名（变量名）
  values_to = "Fraction"           # 新列名：存储对应的值
)
head(CGGAmRNAseq3252)
# # A tibble: 6 × 4
  # Group SampleNames                  CellType                     Fraction
  # <chr> <chr>                        <chr>                           <dbl>

CGGAmRNAseq3252$Group <- factor(CGGAmRNAseq3252$Group,levels = c("Low","High"))
CGGAmRNAseq3252$CellType <- gsub("_CIBERSORT","",CGGAmRNAseq3252$CellType)
CGGAmRNAseq3252$CellType <- gsub("_"," ",CGGAmRNAseq3252$CellType)
head(CGGAmRNAseq3252)
CGGAmRNAseq3252$CellType <- factor(CGGAmRNAseq3252$CellType,levels = unique(CGGAmRNAseq3252$CellType))

pCGGAmRNAseq325 <- ggplot(CGGAmRNAseq3252,aes(x = CellType,y = Fraction,fill = Group)) +
       geom_boxplot(outlier.shape = NA, width = 0.8) +
       scale_fill_manual(values = c("#377EB8","#E41A1C")) +
       scale_y_continuous(expand = c(0,0),limits = c(-0.02,1),breaks = seq(0,1,0.25)) +
	   labs(x = NULL,y = 'Relative Proportion',title = "CGGA-mRNAseq325") +
       theme_bw() +
       theme(axis.text.x = element_text(angle = 30, hjust = 1, vjust = 1,size = 20), 
             axis.text.y = element_text(size = 20), 
             axis.title.x = element_blank(),
             axis.title.y = element_text(size = 20), 
			 plot.title = element_text(size = 24,hjust = 0.5),
             legend.title = element_blank(),
             legend.text = element_text(size = 22),
             legend.position = "bottom")
library(ggpubr)
pCGGAmRNAseq325 <- pCGGAmRNAseq325 + stat_compare_means(aes(group = Group,label = ..p.signif..),
                              method = "t.test",label.y = 0.9,size = 10)
pCGGAmRNAseq325

# #每组最大值——显著性符号的位置
# library(dplyr)
# Marker <- CGGAmRNAseq3252 %>% group_by(CellType,Group) %>% summarise(Max = max(Fraction))
# Marker <- Marker[order(Marker$CellType,Marker$Max,decreasing = T),]
# Marker <- Marker[!duplicated(Marker$CellType),]
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# Marker <- Marker[order(Marker$CellType,decreasing = T),]
# Marker$X <- 1:nrow(Marker)

# ##确保Marker与CGGAmRNAseq3252的顺序对应
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# pCGGAmRNAseq325 <- ggplot(CGGAmRNAseq3252,aes(x = CellType,y = Fraction,fill = Group)) +
       # geom_violin(scale = "width",alpha = 0.6,size = 0.5,width = 1)+
       # ##去除本体，仅保留两侧胡须
       # geom_boxplot(width = 0, position = position_dodge(1), 
                    # outlier.shape = NA,alpha = 0.1,show.legend = FALSE) +
       # ##中位数点
       # stat_summary(fun.y = "median",geom = "point",shape = 16, 
                    # size = 3, color = "white",position = position_dodge(1))+
       # #分组添加颜色
       # scale_fill_manual(values = c("#377EB8","#E41A1C")) +  
       # #设置纵坐标
      # # scale_y_continuous(expand = c(0,0),limits = c(0,0.75),breaks = seq(0,0.6,0.2)) +
       # #按分组进行统计检验
       # stat_compare_means(aes(group = Group), 
                          # method = "wilcox",
                          # paired = F,
                          # symnum.args = list(cutpoint = c(0,0.001,0.01,0.05,1),
                                        # symbols = c("***","**","*","NS.")),
                          # label = "p.signif",
                          # label.y = Marker$Max + 0.03,      #显著性符号的位置
                          # size = 8) +                               
       # #在显著性符号下面添加一条短线
       # geom_segment(data = Marker,
                    # aes(x = X - 0.2,y = Max,
                        # xend = X + 0.2,yend = Max),
                    # size = 0.8) +
       # labs(x = NULL,y = 'Relative Proportion',fill = NULL) +
       # theme_bw() +
       # theme(axis.text.x = element_text(angle = 30, hjust = 1, vjust = 1,size = 20), 
             # axis.text.y = element_text(size = 20), 
             # axis.title.x = element_blank(),
             # axis.title.y = element_text(size = 20), 
             # panel.border = element_rect(size = 1.2),
             # legend.title = element_blank(),
             # legend.text = element_text(size = 22),
             # legend.position = c(0.1,0.8))
# pCGGAmRNAseq325


#####################
###########CGGAmRNAseq693
#####################
CGGAmRNAseq693$Group <- ifelse(as.numeric(CGGAmRNAseq693[,"Expression"]) > 
                              median(as.numeric(CGGAmRNAseq693[,"Expression"])),"High","Low")
table(CGGAmRNAseq693$Group)

CGGAmRNAseq693$Group <- "Median"
quantile(as.numeric(CGGAmRNAseq693[,"Expression"]),0.7)
CGGAmRNAseq693$Group[as.numeric(CGGAmRNAseq693[,"Expression"]) > quantile(as.numeric(CGGAmRNAseq693[,"Expression"]),0.7)] <- "High"
CGGAmRNAseq693$Group[as.numeric(CGGAmRNAseq693[,"Expression"]) < quantile(as.numeric(CGGAmRNAseq693[,"Expression"]),0.3)] <- "Low"
table(CGGAmRNAseq693$Group)
CGGAmRNAseq693 <- CGGAmRNAseq693[CGGAmRNAseq693$Group != "Median",]
table(CGGAmRNAseq693$Group)


library(tidyr)
# 使用 pivot_longer 转换数据
CGGAmRNAseq6932 <- pivot_longer(
  data = CGGAmRNAseq693[,c(Celllist,"Group","SampleNames")],
  cols = Celllist,  # 选择需要转换的列:
  names_to = "CellType",        # 新列名：存储原列名（变量名）
  values_to = "Fraction"           # 新列名：存储对应的值
)
head(CGGAmRNAseq6932)
# # A tibble: 6 × 4
  # Group SampleNames                  CellType                     Fraction
  # <chr> <chr>                        <chr>                           <dbl>

CGGAmRNAseq6932$Group <- factor(CGGAmRNAseq6932$Group,levels = c("Low","High"))
CGGAmRNAseq6932$CellType <- gsub("_CIBERSORT","",CGGAmRNAseq6932$CellType)
CGGAmRNAseq6932$CellType <- gsub("_"," ",CGGAmRNAseq6932$CellType)
head(CGGAmRNAseq6932)
CGGAmRNAseq6932$CellType <- factor(CGGAmRNAseq6932$CellType,levels = unique(CGGAmRNAseq6932$CellType))

pCGGAmRNAseq693 <- ggplot(CGGAmRNAseq6932,aes(x = CellType,y = Fraction,fill = Group)) +
       geom_boxplot(outlier.shape = NA, width = 0.8) +
       scale_fill_manual(values = c("#377EB8","#E41A1C")) +
       scale_y_continuous(expand = c(0,0),limits = c(-0.02,1),breaks = seq(0,1,0.25)) +
	   labs(x = NULL,y = 'Relative Proportion',title = "CGGA-mRNAseq693") +
       theme_bw() +
       theme(axis.text.x = element_text(angle = 30, hjust = 1, vjust = 1,size = 20), 
             axis.text.y = element_text(size = 20), 
             axis.title.x = element_blank(),
             axis.title.y = element_text(size = 20), 
			 plot.title = element_text(size = 24,hjust = 0.5),
             legend.title = element_blank(),
             legend.text = element_text(size = 22),
             legend.position = "bottom")
library(ggpubr)
pCGGAmRNAseq693 <- pCGGAmRNAseq693 + stat_compare_means(aes(group = Group,label = ..p.signif..),
                              method = "t.test",label.y = 0.9,size = 10)
pCGGAmRNAseq693

# #每组最大值——显著性符号的位置
# library(dplyr)
# Marker <- CGGAmRNAseq6932 %>% group_by(CellType,Group) %>% summarise(Max = max(Fraction))
# Marker <- Marker[order(Marker$CellType,Marker$Max,decreasing = T),]
# Marker <- Marker[!duplicated(Marker$CellType),]
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# Marker <- Marker[order(Marker$CellType,decreasing = T),]
# Marker$X <- 1:nrow(Marker)

# ##确保Marker与CGGAmRNAseq6932的顺序对应
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# Marker$CellType <- factor(Marker$CellType,levels = unique(Marker$CellType))
# pCGGAmRNAseq693 <- ggplot(CGGAmRNAseq6932,aes(x = CellType,y = Fraction,fill = Group)) +
       # geom_violin(scale = "width",alpha = 0.6,size = 0.5,width = 1)+
       # ##去除本体，仅保留两侧胡须
       # geom_boxplot(width = 0, position = position_dodge(1), 
                    # outlier.shape = NA,alpha = 0.1,show.legend = FALSE) +
       # ##中位数点
       # stat_summary(fun.y = "median",geom = "point",shape = 16, 
                    # size = 3, color = "white",position = position_dodge(1))+
       # #分组添加颜色
       # scale_fill_manual(values = c("#377EB8","#E41A1C")) +  
       # #设置纵坐标
      # # scale_y_continuous(expand = c(0,0),limits = c(0,0.75),breaks = seq(0,0.6,0.2)) +
       # #按分组进行统计检验
       # stat_compare_means(aes(group = Group), 
                          # method = "wilcox",
                          # paired = F,
                          # symnum.args = list(cutpoint = c(0,0.001,0.01,0.05,1),
                                        # symbols = c("***","**","*","NS.")),
                          # label = "p.signif",
                          # label.y = Marker$Max + 0.03,      #显著性符号的位置
                          # size = 8) +                               
       # #在显著性符号下面添加一条短线
       # geom_segment(data = Marker,
                    # aes(x = X - 0.2,y = Max,
                        # xend = X + 0.2,yend = Max),
                    # size = 0.8) +
       # labs(x = NULL,y = 'Relative Proportion',fill = NULL) +
       # theme_bw() +
       # theme(axis.text.x = element_text(angle = 30, hjust = 1, vjust = 1,size = 20), 
             # axis.text.y = element_text(size = 20), 
             # axis.title.x = element_blank(),
             # axis.title.y = element_text(size = 20), 
             # panel.border = element_rect(size = 1.2),
             # legend.title = element_blank(),
             # legend.text = element_text(size = 22),
             # legend.position = c(0.1,0.8))
# pCGGAmRNAseq693

pTCGAGBM + pTCGALGG
pCGGAmRNAseq325 + pCGGAmRNAseq693

pdf("D:/Temp/9-RARRES2 in Glioma/results/DEG-CIBERSORT-2.pdf",
     height = 6,width = 10)
pTCGAGBM
pTCGALGG
pCGGAmRNAseq325
pCGGAmRNAseq693
dev.off()	