rm(list=ls())
options(stringsAsFactors = F)
################################
################################TCGA + GTEx
################################
setwd("D:/data/UCSC Xena TCGA+TARGET+GTEx")
library(data.table)
#匹配TPM log2(TPM+0.001)与表型数据，分别提取TCGA与GTEx数据并整理使之一一对应：
####导入TPM定量数据
TPM <- fread("./TcgaTargetGtex_rsem_gene_tpm.gz",data.table = F)
TPM[1:4,1:4]
rownames(TPM) <- TPM$sample
TPM <- TPM[,-1]
library(stringr)
colnames(TPM) %>% word(sep = '-', 1) %>% table()
# GTEX  K TARGET   TCGA
# 7792  70   734  10535
####只保留GTEX与TCGA
ind <- (colnames(TPM) %>% word(sep = '-', 1)) %in% c("GTEX","TCGA")
exprSet <- TPM[,ind]
colnames(exprSet) %>% word(sep = '-', 1) %>% table()

####导入表型数据
ph <- fread("./TcgaTargetGTEX_phenotype.txt",data.table = F)
dim(ph)#[1] 19131     7
head(ph)

colnames(ph) <- gsub("_","",colnames(ph))
colnames(ph) <- gsub(" ","",colnames(ph))
#rownames(ph) <- ph$sample
table(ph$study)####只保留GTEX与TCGA
# GTEX TARGET   TCGA 
# 7862    734  10535 
ph <- ph[ph$study %in% c("GTEX","TCGA"), ]

################挑选样本
ph1 <- ph[ph$primarydiseaseortissue %in% c("Glioblastoma Multiforme"),]
ph2 <- ph[grep("Brain",ph$primarydiseaseortissue),]
ph <- rbind(ph1,ph2)


exprSet <- exprSet[,which(colnames(exprSet) %in% ph$sample)]
ph <- ph[which(ph$sample %in% colnames(exprSet)),]        
exprSet <- exprSet[,ph$sample]
gc()
# rm(list = ls())
# options(stringsAsFactors = F)
# setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
# load(file = "D:/Temp/3-Pan-cancer/data/GTEx_TCGA_Data.Rdata")
############LGG+GBM  T+N
rownames(exprSet)[grep("ENSG00000183671",rownames(exprSet))]
Data_Plot <- data.frame(Expression = as.numeric(exprSet["ENSG00000183671.12",]),
                        Group = ph$sampletype,
						SubGroup = ph$primarydiseaseortissue,
						Source = "TCGA + GTEx")
Data_Plot <- Data_Plot[Data_Plot$Group %in% c("Normal Tissue","Primary Tumor"),]

table(Data_Plot$Group)
# Normal Tissue Primary Tumor 
  # 1152           662  
table(Data_Plot$SubGroup)
# Brain - Amygdala  Brain - Anterior Cingulate Cortex (Ba24)           Brain - Caudate (Basal Ganglia)             Brain - Cerebellar Hemisphere 
# 69                                        83                                       109                                        97 
# Brain - Cerebellum                    Brain - Cortex              Brain - Frontal Cortex (Ba9)                       Brain - Hippocampus 
# 119                                       105                                       102                                        84 
# Brain - Hypothalamus Brain - Nucleus Accumbens (Basal Ganglia)       Brain - Putamen (Basal Ganglia)        Brain - Spinal Cord (Cervical C-1) 
# 82                                       104                                        81                                        60 
# Brain - Substantia Nigra         Brain Lower Grade Glioma                   Glioblastoma Multiforme 
# 57                                       509                                       153 

# Data_Plot$SubGroup2 <- "Normal\nTissue"
# Data_Plot$SubGroup2[Data_Plot$SubGroup == "Glioblastoma Multiforme"] <- "Glioblastoma\nMultiforme"
# Data_Plot$SubGroup2[Data_Plot$SubGroup == "Brain Lower Grade Glioma"] <- "Lower Grade\nGlioma"
# Data_Plot$SubGroup2 <- factor(Data_Plot$SubGroup2,levels = c("Normal\nTissue",
                                                             # "Lower Grade\nGlioma",
															 # "Glioblastoma\nMultiforme"))
Data_Plot$SubGroup2 <- "Normal"
Data_Plot$SubGroup2[Data_Plot$SubGroup == "Glioblastoma Multiforme"] <- "GBM"
Data_Plot$SubGroup2[Data_Plot$SubGroup == "Brain Lower Grade Glioma"] <- "LGG"
Data_Plot$SubGroup2 <- factor(Data_Plot$SubGroup2,levels = c("Normal","LGG","GBM"))

Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Cerebellar Hemisphere",]
Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Cerebellum",]
Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Hippocampus",]
Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Hypothalamus",]
Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Spinal Cord (Cervical C-1)",]
Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Substantia Nigra",]
# Data_Plot <- Data_Plot[Data_Plot$SubGroup %in% c("Brain - Anterior Cingulate Cortex (Ba24)",
                                                 # "Brain - Cortex","Brain - Frontal Cortex (Ba9)",
												 # "Glioblastoma Multiforme","Brain Lower Grade Glioma"),]

Data_Plot$Source <- "TCGA + GTEx"

TCGAGTEx <- Data_Plot;rm(exprSet);gc()

################################
################################GSE147352
################################
setwd("D:/Temp/9-RARRES2 in Glioma/data")
exprSet <- read.csv("./GSE147352_DESeq_normalized_counts.csv",quote = "",fill = T,
                    header = T,stringsAsFactors = F,check.names = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]
dim(exprSet)
#[1] 53731   118
exprSet[1:4,1:4]
                      # SYC64      SYC66      SYC67      SYC68
# ENSG00000000003 209.5503849 144.715159 142.586711 186.927574
# ENSG00000000005   0.7352645   6.291963   3.727757   1.153874
# ENSG00000000419 394.1017765 588.298579 500.451399 455.780197
# ENSG00000000457 436.0118535 404.782980 431.487891 390.009384

suppressMessages(library(GEOquery))
gset <- getGEO("GSE147352",destdir = ".",getGPL = FALSE)
eSet <- gset[[1]]

phenoDat <- pData(eSet)
head(phenoDat[,1:4])
###提取生存数据
colnames(phenoDat)
pd <- data.frame(SampleID = phenoDat[,1],
                 GSE = phenoDat[,2],
                 Group = phenoDat$source_name_ch1)
identical(pd$SampleID,colnames(exprSet))
plotData <- data.frame(pd,
                       Source = "GSE147352",
                       CMKLR2 = log2(as.numeric(exprSet["ENSG00000183671",])+1))
plotData$Group2 <- factor(plotData$Group,
                          levels = c("Normal brain tissues",
							         "lower grade glioma tissues",
									 "glioblastoma tissues"),
                          labels = c("Normal","LGG","GBM"))
GSE147352 <- plotData
GSE147352$Source <- "GSE147352"



################################
################################GSE16011
################################
setwd("D:/Temp/9-RARRES2 in Glioma/data")
load(file = "GSE16011.Rdata")
mat <- exprSet[c('1000',"2825"),]
meta <- pd
head(meta)
identical(colnames(mat),meta$GSE)
plotData <- cbind(meta,t(mat))
head(plotData)
colnames(plotData)[length(colnames(plotData))] <- "CMKLR2"
plotData$Source <- "GSE16011"
plotData$Group[is.na(plotData$Group)] <- "Normal"
table(plotData$Group,plotData$Grade)
plotData$Group2 <- plotData$Group
plotData$Group2[plotData$Group %in% c("OD","OA","A","PA")] <- "LGG"
table(plotData$Group2,plotData$Grade)

plotData$Group2 <- factor(plotData$Group2,
                          levels = c("Normal","LGG","GBM"),
                          labels = c("Normal","LGG","GBM"))
GSE16011 <- plotData
GSE16011$Source <- "GSE16011"

head(TCGAGTEx)
head(GSE147352)
head(GSE16011)

################################
################################画图
################################
tmp1 <- TCGAGTEx[,c("SubGroup2","Source","Expression")]
colnames(tmp1) <- c("Group2","Source","CMKLR2")
tmp1$CMKLR2 <- as.numeric(scale(tmp1$CMKLR2))

tmp2 <- GSE147352[,c("Group2","Source","CMKLR2")]
#colnames(tmp2) <- c("Group2","Source","CMKLR2")
tmp2$CMKLR2 <- as.numeric(scale(tmp2$CMKLR2))

tmp3 <- GSE16011[,c("Group2","Source","CMKLR2")]
#colnames(tmp3) <- c("Group2","Source","CMKLR2")
tmp3$CMKLR2 <- as.numeric(scale(tmp3$CMKLR2))
plotData <- rbind(tmp1,tmp2,tmp3)
table(plotData$Source,plotData$Group2)	 
            # Normal LGG GBM
  # GSE147352       15  18  85
  # GSE16011         8 117 159
  # TCGA + GTEx    653 509 153
range(plotData$CMKLR2)#[1]-1.855465  5.006458
library(ggsignif)
library(ggplot2)

mytheme <- theme(plot.title = element_blank(),
				 axis.text.x = element_text(colour = rev(c("#982b2b","#db6968","#88c4e8")),
				                            hjust = 0.5,size = 20), 
				 axis.text.y = element_text(size = 20),
				 axis.title.y = element_text(size = 20), 
				 axis.line = element_line(colour = "black",size = 1), 
				 panel.grid.minor = element_blank(),
                 panel.grid.major = element_blank(),
                 legend.position = "none")
mytheme_strip <- theme(## 分面背景更改为红色
				       strip.background = element_rect(fill = c("white")),
				       ## 分面字体更改为白色
				       strip.text = element_text(size = 20,colour = "black"))
mytheme_strip2 <- theme(strip.text = element_text(size = 20))
				 
p <- ggplot(data = plotData,aes(x = Group2, y = CMKLR2)) +
     geom_violin(aes(colour = Group2),size = 0.8,scale = 'width') +
	 geom_boxplot(aes(colour = Group2),width = 0.35,
	              outlier.shape = NA,size = 0.8,
	              position = position_dodge(0.9)) + 
	 scale_y_continuous(limits = c(-2,5.01), breaks = seq(-2,5,1),
	                    labels = seq(-2,5,1),expand = c(0,0))+
	 scale_color_manual(values = rev(c("#982b2b","#db6968","#88c4e8")))+
     theme_bw() + mytheme + mytheme_strip +
     facet_wrap(~Source,nrow = 1) +
     labs(title = NULL,x = NULL, 
		  y = "Relative Expression (Z-score)")
p2 <- p + geom_signif(comparisons = list(c("Normal", "GBM"),
                                         c("Normal", "LGG"),
										 c("LGG", "GBM")),
                      y_position = c(3.05,2.2,2.5),map_signif_level = T,
                      test = t.test,size = 1,
					  textsize = 10,tip_length = 0.015)
p2
pdf("D:/Temp/9-RARRES2 in Glioma/results/Merge-CMKLR2.pdf",width = 9,height = 6)
p2
dev.off()			   
		   
		   
