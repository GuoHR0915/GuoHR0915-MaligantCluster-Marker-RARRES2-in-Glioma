rm(list = ls())
options(stringsAsFactors = FALSE)
Gene <- "RARRES2"
Genelist1 <- c("SREBF1","SREBF2","PTEN","MTOR",
              "ACACA","FASN",
			  "FADS2","SCD","ACSL1")
Genelist2 <- c("ELOVL1","ELOVL2","ELOVL3","ELOVL4","ELOVL5","ELOVL6","ELOVL7")  
Genelist <- c(Genelist1,Genelist2)
setwd("D:/data/TCGA")
########################################################################
###############################TCGA-GBM#################################
########################################################################
load('./TCGAbiolinks-EXP/TCGA-GBM-GeneSymbol.Rdata')
exprSet <- data.frame(log2(t(exp_TPM[c(Gene,Genelist),])+1),
	                  SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
                      SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3),
                      Cancer = "TCGA-GBM")
print(table(exprSet$SampleType,exprSet$SampleType2))
exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09") & exprSet$SampleType2 == "A",]
print(table(exprSet$SampleType,exprSet$SampleType2))
	
#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(Genelist,function(x){
	GeneA <- as.numeric(exprSet[,x])
    GeneB <- as.numeric(exprSet[,Gene])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "pearson")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- Genelist
head(Correlation)
TCGAGBM <- Correlation
TCGAGBM$Cohort <- "TCGA-GBM"

########################################################################
###############################TCGA-LGG#################################
########################################################################
load('./TCGAbiolinks-EXP/TCGA-LGG-GeneSymbol.Rdata')

exprSet <- data.frame(log2(t(exp_TPM[c(Gene,Genelist),])+1),
	                  SampleType = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),1,2),
                      SampleType2 = substr(sapply(strsplit(colnames(exp_TPM),'-'),"[",4),3,3),
                      Cancer = "TCGA-LGG")
print(table(exprSet$SampleType,exprSet$SampleType2))
exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09") & exprSet$SampleType2 == "A",]
print(table(exprSet$SampleType,exprSet$SampleType2))
	
#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(Genelist,function(x){
	GeneA <- as.numeric(exprSet[,x])
    GeneB <- as.numeric(exprSet[,Gene])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "pearson")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- Genelist
head(Correlation)
TCGALGG <- Correlation
TCGALGG$Cohort <- "TCGA-LGG"

	
#################################################################
#####################CGGA-mRNAseq_325############################
#################################################################
phenoDat <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325_clinical.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
head(phenoDat)
phenoDat <- phenoDat[phenoDat$PRS_type == "Primary",]
exprSet <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325.Read_Counts-genes.20220620.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]

exprSet <- exprSet[,colnames(exprSet) %in% phenoDat$CGGA_ID]
phenoDat <- phenoDat[phenoDat$CGGA_ID %in% colnames(exprSet),]

exp_RSEM <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325.RSEM-genes.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exp_RSEM) <- exp_RSEM[,1]
exp_RSEM <- exp_RSEM[,-1]

exp_RSEM_Tumor <- exp_RSEM[rownames(exprSet),colnames(exprSet)]

exprSet <- data.frame(log2(t(exp_RSEM_Tumor[c(Gene,Genelist),])+1),
                       Cancer = "mRNAseq325")

#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(Genelist,function(x){
	GeneA <- as.numeric(exprSet[,x])
    GeneB <- as.numeric(exprSet[,Gene])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "pearson")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- Genelist
head(Correlation)
CGGA325 <- Correlation
CGGA325$Cohort <- "mRNAseq325"


#################################################################
#####################CGGA-mRNAseq_693############################
#################################################################
phenoDat <- read.table("D:/data/CGGA/mRNAseq_693/CGGA.mRNAseq_693_clinical.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
head(phenoDat)
phenoDat <- phenoDat[phenoDat$PRS_type == "Primary",]
exprSet <- read.table("D:/data/CGGA/mRNAseq_693/CGGA.mRNAseq_693.Read_Counts-genes.20220620.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]

exprSet <- exprSet[,colnames(exprSet) %in% phenoDat$CGGA_ID]
phenoDat <- phenoDat[phenoDat$CGGA_ID %in% colnames(exprSet),]

exp_RSEM <- read.table("D:/data/CGGA/mRNAseq_693/CGGA.mRNAseq_693.RSEM-genes.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exp_RSEM) <- exp_RSEM[,1]
exp_RSEM <- exp_RSEM[,-1]

exp_RSEM_Tumor <- exp_RSEM[rownames(exprSet),colnames(exprSet)]

exprSet <- data.frame(log2(t(exp_RSEM_Tumor[c(Gene,Genelist),])+1),
                       Cancer = "mRNAseq693")


#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(Genelist,function(x){
	GeneA <- as.numeric(exprSet[,x])
    GeneB <- as.numeric(exprSet[,Gene])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "pearson")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- Genelist
head(Correlation)
CGGA693 <- Correlation	
CGGA693$Cohort <- "mRNAseq693"
	
#################################################################
#####################CGGA-mRNA-array_301#########################
#################################################################
phenoDat <- read.table("D:/data/CGGA/mRNA-array_301/CGGA.mRNA_array_301_clinical.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
head(phenoDat)
phenoDat <- phenoDat[phenoDat$PRS_type == "Primary",]
exprSet <- read.table("D:/data/CGGA/mRNA-array_301/CGGA.mRNA_array_301_gene_level.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]

exprSet <- exprSet[,colnames(exprSet) %in% phenoDat$CGGA_ID]
phenoDat <- phenoDat[phenoDat$CGGA_ID %in% colnames(exprSet),]
Genelist %in% rownames(exprSet)

exprSet <- data.frame(t(exprSet[c(Gene,Genelist),]),
                       Cancer = "mRNAarray301")
head(exprSet)

#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(Genelist,function(x){
	GeneA <- as.numeric(exprSet[,x])
    GeneB <- as.numeric(exprSet[,Gene])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "pearson")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- Genelist
head(Correlation)
CGGAarray <- Correlation	
CGGAarray$Cohort <- "mRNAarray301"


#################################################################
#############################绘制热图############################
#################################################################
dft <- rbind(TCGAGBM,TCGALGG,CGGA325,CGGA693,CGGAarray)
library(dplyr)
tmp <- case_when(as.vector(dft$Pvalue) < 0.001~"****",
                 as.vector(dft$Pvalue) < 0.001~"***",
                 as.vector(dft$Pvalue) < 0.01~"**",
                 as.vector(dft$Pvalue) < 0.05~"*",
                 T~ "")
tmp
dft$label <- tmp


dft$Gene <- rep(Genelist,5)
range(dft$R)#[1] -0.5735238  0.4310495
head(dft)
                 # R      Pvalue   Cohort label   Gene
# SREBF1  0.19253111 0.019901915 TCGA-GBM     * SREBF1
# SREBF2 -0.23663040 0.004032669 TCGA-GBM    ** SREBF2
# PTEN   -0.16018914 0.053430273 TCGA-GBM         PTEN
# MTOR   -0.08541209 0.305343459 TCGA-GBM         MTOR
# ACACA  -0.13666290 0.100003452 TCGA-GBM        ACACA
# FASN   -0.17992512 0.029771041 TCGA-GBM     *   FASN
dft$Cohort <- factor(dft$Cohort,levels = unique(dft$Cohort))
dft$Gene <- factor(dft$Gene,levels = rev(Genelist))
library(ggplot2)
library(paletteer)
library(ggthemes)
theme1 <- theme_minimal()+
          theme(panel.border = element_rect(fill = NA,size = 1, linetype = "solid"),
                panel.grid = element_blank(),
                axis.ticks.y = element_blank(),
                plot.title = element_text(hjust = 0.5,size = 26),
                axis.text.x = element_text(angle = 30,hjust = 1,size = 26),
                axis.text.y = element_text(size = 26))
Heatmap <- ggplot(data = dft,aes(x = Cohort,y = Gene)) +
           geom_tile(aes(fill = R),color = "grey") +
           geom_text(aes(label = label),size = 8) +
           scale_x_discrete(expand = c(0,0)) + 
           scale_y_discrete(expand = c(0,0)) +
		   scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        name = "Correlation level",midpoint = 0,
		                        limits = c(-0.6,0.6),breaks = seq(-0.6,0.6,0.3)) + 
           # scale_fill_paletteer_c("ggthemes::Classic Red-Blue",
                                  # direction = -1,
                                  # name="Correlation level",
                                  # limits = c(-0.5,0.7),
							      # breaks = seq(-0.4,0.6,0.2)) +
		   labs(title = NULL, x = NULL, y = NULL) + theme1		 
# ####拉长图例
Heatmap2 <- Heatmap + theme(legend.position = "right",
                            legend.text = element_text(color = "black",size = 24),
                            legend.title = element_blank()) +
			guides(fill = guide_colorbar(barwidth = 1.5,barheight = 10,ticks = TRUE))    				
Heatmap2                           

pdf("./Correlation-Geneset.pdf",
     height = 8,width = 8)
Heatmap2
dev.off()			

dft$Gene <- factor(dft$Gene,levels = Genelist)
dft$Cohort <- factor(dft$Cohort,levels = rev(unique(dft$Cohort)))
Heatmap <- ggplot(data = dft,aes(x = Gene,y = Cohort)) +
           geom_tile(aes(fill = R),color = "grey") +
           geom_text(aes(label = label),size = 8) +
           scale_x_discrete(expand = c(0,0)) + 
           scale_y_discrete(expand = c(0,0)) +
		   scale_fill_gradient2(low = "#498EA4", mid = "white", high = "#E54924", 
		                        name = "Correlation level",midpoint = 0,
		                        limits = c(-0.6,0.6),breaks = seq(-0.6,0.6,0.3)) + 
           # scale_fill_paletteer_c("ggthemes::Classic Red-Blue",
                                  # direction = -1,
                                  # name="Correlation level",
                                  # limits = c(-0.5,0.7),
							      # breaks = seq(-0.4,0.6,0.2)) +
		   labs(title = NULL, x = NULL, y = NULL) + theme1		 
# ####拉长图例
Heatmap2 <- Heatmap + theme(legend.position = "right",
                            legend.text = element_text(color = "black",size = 24),
                            legend.title = element_blank()) +
			guides(fill = guide_colorbar(barwidth = 1.5,barheight = 10,ticks = TRUE))    				
Heatmap2                           

pdf("D:/Temp/9-RARRES2 in Glioma/results/Correlation-Geneset-2.pdf",
     height = 4,width = 14)
print(Heatmap2)
dev.off()			