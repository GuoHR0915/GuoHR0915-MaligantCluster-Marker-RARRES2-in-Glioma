rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/Temp/9-RARRES2 in Glioma") 
########################################################################################
######################################数据资料整理######################################
########################################################################################
############mRNAseq_325 Expression Data from STAR+RSEM (FPKM value) 
phenoDat <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325_clinical.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
head(phenoDat)
phenoDat <- phenoDat[phenoDat$PRS_type == "Primary",]

exprSet <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325.RSEM-genes.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]
exprSet[1:10,1:6]
boxplot(exprSet[,1:4])
# exprSet <- t(scale(t(exprSet)))
# boxplot(exprSet[,1:4])
#########
#########FPKM转TPM
#########
fpkmToTpm <- function(fpkm)
{
    exp(log(fpkm) - log(sum(fpkm)) + log(1e6))
}
exprSet <- apply(exprSet,2,fpkmToTpm)
boxplot(exprSet[,1:4])
exprSet <- log2(exprSet + 1)
boxplot(exprSet[,1:4])
exprSet <- exprSet[,colnames(exprSet) %in% phenoDat$CGGA_ID]


########################################################################################
########################################ESTIMATE########################################
########################################################################################
set.seed(12345)
library(estimate)
estimate <- function(dat,pro){
                input.f <-  paste0(pro,'_estimate_input.txt')
                output.f <- paste0(pro,'_estimate_gene.gct')
                output.ds <- paste0(pro,'_estimate_score.gct')
                write.table(dat,file = input.f,sep = '\t',quote = F)
                library(estimate)
                ###转换表达矩阵格式
                filterCommonGenes(input.f = input.f,output.f = output.f ,id = "GeneSymbol")
                ###计算Score
                estimateScore(input.ds = output.f,output.ds = output.ds,platform = "illumina") ## 注意platform
                scores <- read.table(output.ds,skip = 2,header = T)
                rownames(scores) <- scores[,1]
                scores <- t(scores[,3:ncol(scores)])
                return(scores)
}
ESTIMATEscores <- estimate(exprSet,pro = "mRNAseq_325")
head(ESTIMATEscores)
ESTIMATEscores <- data.frame(ESTIMATEscores)
head(ESTIMATEscores)
identical(rownames(ESTIMATEscores),colnames(exprSet))
ESTIMATEscores$Expression <- as.numeric(exprSet["RARRES2",])
cor.test(ESTIMATEscores$Expression,ESTIMATEscores$ImmuneScore,method = 'spearman')

library(ggplot2)
library(ggpmisc)
library(ggpubr)
theme <- theme_bw()+ 
         theme(plot.title = element_text(hjust = 0.5,size = 22),
               axis.text.x = element_text(hjust = 0.5,size = 20), 
               axis.text.y = element_text(hjust = 0.5,size = 20),
               axis.title.y = element_text(size = 20), 
               axis.title.x = element_text(size = 20), 
               legend.text = element_text(size = 22),
               legend.title = element_blank(),
               legend.position = c(0.15,0.8),
               legend.background = element_blank())
p1 <- ggplot(data = ESTIMATEscores, aes(x = Expression, y = ImmuneScore, group = 1)) +
      geom_point(size = 4,colour = "#c74546") +
      # scale_x_continuous(expand = c(0,0),limits = c(-7.25,1.75), breaks = seq(-7,1,2)) +
      # scale_y_continuous(expand = c(0,0),limits = c(-1500,1750), breaks = seq(-1400,1600,600)) +
	  geom_smooth(method = 'lm', formula = y ~ x, se = TRUE, show.legend = FALSE) +
	  labs(x = 'RARRES2 Relative Expression',y = "Immune Score",fill = NULL) + 
      stat_cor(aes(label = paste(..r.label.., ..p.label.., sep = '~`,`~')), 
               method = 'spearman', 
               label.x.npc = 'left', label.y.npc = 'top', size = 8) +
      theme
# pdf("./ESTIMATE-Correlation-mRNAseq_325-RARRES2.pdf",height = 5,width = 6)
# p1
# dev.off()	  


ESTIMATEscores$Expression <- as.numeric(exprSet["MDK",])
cor.test(ESTIMATEscores$Expression,ESTIMATEscores$ImmuneScore,method = 'spearman')
p1 <- ggplot(data = ESTIMATEscores, aes(x = Expression, y = ImmuneScore, group = 1)) +
      geom_point(size = 4,colour = "#c74546") +
      # scale_x_continuous(expand = c(0,0),limits = c(-7.25,1.75), breaks = seq(-7,1,2)) +
      # scale_y_continuous(expand = c(0,0),limits = c(-1500,1750), breaks = seq(-1400,1600,600)) +
	  geom_smooth(method = 'lm', formula = y ~ x, se = TRUE, show.legend = FALSE) +
	  labs(x = 'MDK Relative Expression',y = "Immune Score",fill = NULL) + 
      stat_cor(aes(label = paste(..r.label.., ..p.label.., sep = '~`,`~')), 
               method = 'spearman', 
               label.x.npc = 'left', label.y.npc = 'top', size = 8) +
      theme
pdf("./ESTIMATE-Correlation-mRNAseq_325-MDK.pdf",height = 5,width = 6)
p1
dev.off()

ESTIMATEscores$Expression <- as.numeric(exprSet["IGFBP2",])
cor.test(ESTIMATEscores$Expression,ESTIMATEscores$ImmuneScore,method = 'spearman')
p1 <- ggplot(data = ESTIMATEscores, aes(x = Expression, y = ImmuneScore, group = 1)) +
      geom_point(size = 4,colour = "#c74546") +
      # scale_x_continuous(expand = c(0,0),limits = c(-7.25,1.75), breaks = seq(-7,1,2)) +
      # scale_y_continuous(expand = c(0,0),limits = c(-1500,1750), breaks = seq(-1400,1600,600)) +
	  geom_smooth(method = 'lm', formula = y ~ x, se = TRUE, show.legend = FALSE) +
	  labs(x = 'IGFBP2 Relative Expression',y = "Immune Score",fill = NULL) + 
      stat_cor(aes(label = paste(..r.label.., ..p.label.., sep = '~`,`~')), 
               method = 'spearman', 
               label.x.npc = 'left', label.y.npc = 'top', size = 8) +
      theme
pdf("./ESTIMATE-Correlation-mRNAseq_325-IGFBP2.pdf",height = 5,width = 6)
p1
dev.off()	  