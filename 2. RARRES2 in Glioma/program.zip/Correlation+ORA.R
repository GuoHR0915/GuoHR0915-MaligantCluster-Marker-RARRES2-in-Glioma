rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/Temp/9-RARRES2 in Glioma/data")
Gene <- "RARRES2"
########################################################################
###############################TCGA-GBM#################################
########################################################################
load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-GBM-GeneSymbol.Rdata')
exprSet <- data.frame(SampleNames = colnames(exp_Count),
                      SampleType = substr(sapply(strsplit(colnames(exp_Count),'-'),"[",4),1,3))
table(exprSet$SampleType)
# 01A 01B 01C 02A 02B 11A 
# 146  10   1  12   1   5 
exprSet <- exprSet[exprSet$SampleType %in% c("01A"),]
exprSet$PatientNames <- substr(exprSet$SampleNames,1,12)
table(exprSet$SampleType)

# exp_mRNA_Count <- exp_Count[unique(ids_Gene[ids_Gene$gene_type == "protein_coding","gene_name"]),
                            # exprSet$SampleNames]
# identical(colnames(exp_mRNA_Count),exprSet$SampleNames)
# dim(exp_mRNA_Count)#[1] 19938    146

exp_mRNA_Count <- exp_Count[,exprSet$SampleNames]
minRow <- rowMeans(exp_mRNA_Count) > 1  #按平均数筛选 
minNum <- rowSums(exp_mRNA_Count > 0) > (0.8*ncol(exp_mRNA_Count)) #表达量不为0的样品个数筛选 
#minNum <- rowSums(exp_mRNA_Count > 0) >= (1*ncol(exp_mRNA_Count))
exp_mRNA_Count <- exp_mRNA_Count[minRow & minNum,]
dim(exp_mRNA_Count)#[1]27610   146

exp_TPM_Tumor <- exp_TPM[rownames(exp_mRNA_Count),colnames(exp_mRNA_Count)]
#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(rownames(exp_TPM_Tumor),function(x){
	GeneA <- as.numeric(exp_TPM_Tumor[x,])
    GeneB <- as.numeric(exp_TPM_Tumor[Gene,])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "spearman")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- rownames(exp_TPM_Tumor)
head(Correlation)
TCGAGBM <- Correlation

########################################################################
###############################TCGA-LGG#################################
########################################################################
load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-LGG-GeneSymbol.Rdata')
exprSet <- data.frame(SampleNames = colnames(exp_Count),
                      SampleType = substr(sapply(strsplit(colnames(exp_Count),'-'),"[",4),1,3))
table(exprSet$SampleType)
# 01A 01B 02A 02B 
# 505  11  14   4 
exprSet <- exprSet[exprSet$SampleType %in% c("01A"),]
exprSet$PatientNames <- substr(exprSet$SampleNames,1,12)
table(exprSet$SampleType)

# exp_mRNA_Count <- exp_Count[unique(ids_Gene[ids_Gene$gene_type == "protein_coding","gene_name"]),
                            # exprSet$SampleNames]
# identical(colnames(exp_mRNA_Count),exprSet$SampleNames)
# dim(exp_mRNA_Count)#[1] 19938    146

exp_mRNA_Count <- exp_Count[,exprSet$SampleNames]
minRow <- rowMeans(exp_mRNA_Count) > 1  #按平均数筛选 
minNum <- rowSums(exp_mRNA_Count > 0) > (0.8*ncol(exp_mRNA_Count)) #表达量不为0的样品个数筛选 
#minNum <- rowSums(exp_mRNA_Count > 0) >= (1*ncol(exp_mRNA_Count))
exp_mRNA_Count <- exp_mRNA_Count[minRow & minNum,]
dim(exp_mRNA_Count)#[1]27028   505

exp_TPM_Tumor <- exp_TPM[rownames(exp_mRNA_Count),colnames(exp_mRNA_Count)]
#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(rownames(exp_TPM_Tumor),function(x){
	GeneA <- as.numeric(exp_TPM_Tumor[x,])
    GeneB <- as.numeric(exp_TPM_Tumor[Gene,])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "spearman")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- rownames(exp_TPM_Tumor)
head(Correlation)
TCGALGG <- Correlation


#################################################################
#####################CGGA-mRNAseq_325############################
#################################################################
phenoDat <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325_clinical.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
head(phenoDat)
phenoDat <- phenoDat[phenoDat$PRS_type == "Primary",]
exprSet <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325.Read_Counts-genes.20220620.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]

exprSet <- exprSet[,colnames(exprSet) %in% phenoDat$CGGA_ID]
phenoDat <- phenoDat[phenoDat$CGGA_ID %in% colnames(exprSet),]


exp_mRNA_Count <- exprSet
dim(exp_mRNA_Count)#[1]55523   229
minRow <- rowMeans(exp_mRNA_Count) > 1  #按平均数筛选 
minNum <- rowSums(exp_mRNA_Count > 0) > (0.8*ncol(exp_mRNA_Count)) #表达量不为0的样品个数筛选 
#minNum <- rowSums(exp_mRNA_Count > 0) >= (1*ncol(exp_mRNA_Count))
exp_mRNA_Count <- exp_mRNA_Count[minRow & minNum,]
dim(exp_mRNA_Count)#[1] 21703   229

exp_RSEM <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325.RSEM-genes.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exp_RSEM) <- exp_RSEM[,1]
exp_RSEM <- exp_RSEM[,-1]

exp_RSEM_Tumor <- exp_RSEM[rownames(exp_mRNA_Count),colnames(exp_mRNA_Count)]
#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(rownames(exp_RSEM_Tumor),function(x){
	GeneA <- as.numeric(exp_RSEM_Tumor[x,])
    GeneB <- as.numeric(exp_RSEM_Tumor[Gene,])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "spearman")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- rownames(exp_RSEM_Tumor)
head(Correlation)
CGGA325 <- Correlation

#################################################################
#####################CGGA-mRNAseq_693############################
#################################################################
phenoDat <- read.table("D:/data/CGGA/mRNAseq_693/CGGA.mRNAseq_693_clinical.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
head(phenoDat)
phenoDat <- phenoDat[phenoDat$PRS_type == "Primary",]
exprSet <- read.table("D:/data/CGGA/mRNAseq_693/CGGA.mRNAseq_693.Read_Counts-genes.20220620.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]

exprSet <- exprSet[,colnames(exprSet) %in% phenoDat$CGGA_ID]
phenoDat <- phenoDat[phenoDat$CGGA_ID %in% colnames(exprSet),]


exp_mRNA_Count <- exprSet
dim(exp_mRNA_Count)#[1]55523   422
minRow <- rowMeans(exp_mRNA_Count) > 1  #按平均数筛选 
minNum <- rowSums(exp_mRNA_Count > 0) > (0.8*ncol(exp_mRNA_Count)) #表达量不为0的样品个数筛选 
#minNum <- rowSums(exp_mRNA_Count > 0) >= (1*ncol(exp_mRNA_Count))
exp_mRNA_Count <- exp_mRNA_Count[minRow & minNum,]
dim(exp_mRNA_Count)#[1]22988   422

exp_RSEM <- read.table("D:/data/CGGA/mRNAseq_693/CGGA.mRNAseq_693.RSEM-genes.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exp_RSEM) <- exp_RSEM[,1]
exp_RSEM <- exp_RSEM[,-1]

exp_RSEM_Tumor <- exp_RSEM[rownames(exp_mRNA_Count),colnames(exp_mRNA_Count)]
#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(rownames(exp_RSEM_Tumor),function(x){
	GeneA <- as.numeric(exp_RSEM_Tumor[x,])
    GeneB <- as.numeric(exp_RSEM_Tumor[Gene,])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "spearman")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- rownames(exp_RSEM_Tumor)
head(Correlation)
CGGA693 <- Correlation

#################################################################
#########################计算ORA#################################
#################################################################
library(org.Hs.eg.db)
packageVersion("org.Hs.eg.db")#[1]‘3.15.0’
Positivelist1 <- rownames(TCGAGBM)[which(TCGAGBM$R > 0.4 & TCGAGBM$Pvalue < 0.01)]
Positivelist2 <- rownames(TCGALGG)[which(TCGALGG$R > 0.4 & TCGALGG$Pvalue < 0.01)]
Positivelist3 <- rownames(CGGA325)[which(CGGA325$R > 0.4 & CGGA325$Pvalue < 0.01)]
Positivelist4 <- rownames(CGGA693)[which(CGGA693$R > 0.4 & CGGA693$Pvalue < 0.01)]

PositivelistMerge1 <- intersect(Positivelist1,Positivelist2)
PositivelistMerge2 <- intersect(Positivelist3,Positivelist4)
PositivelistMerge <- intersect(PositivelistMerge1,PositivelistMerge2)

library(clusterProfiler)
ID_entrez <- bitr(PositivelistMerge,#以上调基因为例
                  fromType = "SYMBOL",   #fromType是指你的数据ID类型是属于哪一类的
                  toType = "ENTREZID",   #toType是指你要转换成哪种ID类型，可以写多种，也可以只写一种
                  OrgDb = "org.Hs.eg.db")#Orgdb是指对应的注释包是哪个
# 'select()' returned 1:1 mapping between keys and columns
# Warning message:
# In bitr(PositivelistMerge, fromType = "SYMBOL", toType = "ENTREZID",  :
  # 2.03% of input gene IDs are fail to map...
head(ID_entrez)

Enrichment_KEGG <- enrichKEGG(gene = unique(ID_entrez$ENTREZID),
                              organism = "hsa", 
                              pvalueCutoff = 0.5,
                              qvalueCutoff = 0.5,
                              pAdjustMethod = "BH",
                              minGSSize = 5,
                              maxGSSize = 10000)
head(Enrichment_KEGG)		

Enrichment_GOBP <- enrichGO(gene = unique(ID_entrez$ENTREZID),
                            OrgDb = org.Hs.eg.db, #记得修改对应org包
                            ont = "BP", #"BP"，"MF","CC"三选一,或"ALL"合并
                            keyType = "ENTREZID",
                            pvalueCutoff = 0.1,
                            qvalueCutoff = 0.1,
                            pAdjustMethod = "BH",
                            minGSSize = 5,
                            maxGSSize = 10000,
                            readable = TRUE)
head(Enrichment_GOBP@result)
Enrichment_GOBP2 <- clusterProfiler::simplify(Enrichment_GOBP, cutoff = 0.7, 
                                              by = "p.adjust",select_fun = min)
head(Enrichment_GOBP2@result)


library(ggplot2)
mytheme <- theme(axis.text.x = element_text(hjust = 0.5,size = 20), 
                 axis.ticks.y = element_blank(), ## 删去y轴刻度线
                 axis.text.y = element_text(size = 20), 
                 axis.title.x = element_text(size = 20), 
                 axis.title.y = element_text(size = 20), 
                 axis.line = element_line(size = 1),
                 plot.margin = unit(c(1,1,1,1), "cm"),#画布边缘距离上(top)、右(right)、下(bottom)、左(left) 
                 plot.title = element_text(hjust = 0.5,size =  22),
                 legend.title = element_text(size = 22), 
                 legend.text = element_text(size = 22), 
                 legend.position = "right",
                 legend.background = element_rect(fill = 'transparent'))

dt <- Enrichment_GOBP2[order(Enrichment_GOBP2$pvalue, decreasing = F),][1:10,]
dt$Description <- factor(dt$Description,levels = rev(dt$Description)) 
dt
dt$GeneRatio <- as.numeric(dt$Count)/182
dt$richFactor <- dt$Count / as.numeric(sub("/\\d+", "", dt$BgRatio))
dt2 <- dt[order(dt$GeneRatio),]
dt2$Description <- factor(dt2$Description,levels = dt2$Description)            

library(stringr)
p3 <- ggplot(data = dt2, aes(x = Description, y = GeneRatio, fill = -log10(pvalue))) +
      geom_point(aes(size = Count), shape = 21, colour = "black") + #绘制散点
      labs(x = NULL, y = "GeneRatio", title = "KEGG Pathway Enrichment", 
           fill = bquote("-"~Log[10]~"(P value)")) +  
      scale_fill_gradientn(colours = c("#f7ca64", "#46bac2","#7e62a3")) + #更改配色
      scale_size_continuous(range = c(4, 10)) +                  
      coord_flip() + theme_bw() + mytheme +
      scale_x_discrete(labels = function(dat) str_wrap(dat,width = 30)) #通路名固定长度换行

			  
########################################################################
##############################GSEA富集分析##############################
########################################################################						
geneList <- Correlation$R
names(geneList) <- rownames(Correlation)
geneList <- sort(geneList, decreasing = T)
geneList <- geneList[geneList != 0]
library(GSEABase)
library(enrichplot)
library(clusterProfiler)
set.seed(1234)
geneset <- read.gmt("D:/data/MSigdb/human/msigdb_v2023.2.Hs_GMTs/h.all.v2023.2.Hs.symbols.gmt")
Hallmark_GSEA <- GSEA(geneList, TERM2GENE = geneset, verbose = FALSE,
                  minGSSize = 5,maxGSSize = 1000,eps = 1e-10,
                  pvalueCutoff = 0.99,pAdjustMethod = "BH")

Hallmark_GSEA_result <- Hallmark_GSEA@result[order(Hallmark_GSEA@result$NES,decreasing = T),]
# library(openxlsx)
# write.xlsx(Hallmark_GSEA_result,file = "./results/GSEA-Hallmark.xlsx",
           # colNames = TRUE,rowNames = FALSE)
Hallmark_GSEA_result[Hallmark_GSEA_result$pvalue < 0.05,2:8]
                                                                          # Description setSize enrichmentScore      NES       pvalue     p.adjust      qvalues
# HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION     200       0.6869245 2.172376 1.000000e-10 1.900000e-09 1.421053e-09
# HALLMARK_MYOGENESIS                                               HALLMARK_MYOGENESIS     187       0.6055324 1.907273 1.000000e-10 1.900000e-09 1.421053e-09
# HALLMARK_HEDGEHOG_SIGNALING                               HALLMARK_HEDGEHOG_SIGNALING      35       0.6393509 1.795278 1.915569e-05 1.213194e-04 9.073750e-05
# HALLMARK_ANGIOGENESIS                                           HALLMARK_ANGIOGENESIS      35       0.6080904 1.707499 1.555270e-04 8.442896e-04 6.314631e-04
# HALLMARK_WNT_BETA_CATENIN_SIGNALING               HALLMARK_WNT_BETA_CATENIN_SIGNALING      42       0.5796035 1.667770 1.805052e-04 8.573999e-04 6.412686e-04
# HALLMARK_APICAL_JUNCTION                                     HALLMARK_APICAL_JUNCTION     195       0.5149131 1.625025 5.738441e-10 7.268691e-09 5.436417e-09
# HALLMARK_UV_RESPONSE_DN                                       HALLMARK_UV_RESPONSE_DN     144       0.5118575 1.592482 3.283077e-07 3.118923e-06 2.332713e-06
# HALLMARK_HYPOXIA                                                     HALLMARK_HYPOXIA     197       0.4655823 1.470324 4.458797e-06 3.388686e-05 2.534474e-05
# HALLMARK_COAGULATION                                             HALLMARK_COAGULATION     132       0.4430101 1.373107 2.053414e-03 8.669969e-03 6.484464e-03
# HALLMARK_TGF_BETA_SIGNALING                               HALLMARK_TGF_BETA_SIGNALING      54       0.4540579 1.334396 3.610832e-02 1.247378e-01 9.329424e-02
# HALLMARK_ESTROGEN_RESPONSE_EARLY                     HALLMARK_ESTROGEN_RESPONSE_EARLY     197       0.3804323 1.201418 3.596404e-02 1.247378e-01 9.329424e-02

HallmarkList <- Hallmark_GSEA_result[Hallmark_GSEA_result$pvalue < 0.05,"Description"]
# HallmarkList <- c("HALLMARK_TNFA_SIGNALING_VIA_NFKB",
                  # "HALLMARK_TGF_BETA_SIGNALING",
                  # "HALLMARK_P53_PATHWAY",
				  # "HALLMARK_APOPTOSIS")
# save(HALLMARK_GSEA,Hallmark_GSEA,file = "./results/GSEA.Rdata")
library(ggsci)
Color <- pal_nejm()(8)
library(GseaVis)
p <- gseaNb(object = Hallmark_GSEA,
            geneSetID = HallmarkList[1:8],
            curveCol = Color[1:8],
            subPlot = 3,
            termWidth = 35,
            legend.position = c(0.8,0.8),
            addPval = T,pHjust = 0,
            pvalX = 0.1,pvalY = 0.1,pvalSize = 6)
p2 <- p
library(ggplot2)
library(patchwork)
p2[[1]] <- p2[[1]] + theme_bw()+
           theme(plot.title = element_blank(), 
		         axis.text.x = element_blank(), 
		         axis.text.y = element_text(size=16),
				  axis.ticks.x = element_blank(), 
			     axis.title.x = element_blank(), 
		         axis.title.y = element_text(size = 18),
			     legend.text = element_text(colour="black",size=16),
		         legend.title = element_blank(),
		         legend.position = c(0.7,0.8))
p2[[3]] <- p2[[3]] + theme_bw() +
           theme(plot.title = element_text(hjust = 0.5,size=20),
		         axis.text.x = element_text(hjust = 0.5,size=16),
		         axis.text.y = element_text(size=16),
			     axis.title.x = element_text(hjust = 0.5,size=18),
		         axis.title.y = element_text(size = 18))
p2[[1]]/p2[[2]]/p2[[3]] + plot_layout(heights = c(4,1.5,1))
p2[[1]]/plot_spacer()/p2[[2]]/plot_spacer()/p2[[3]] + plot_layout(heights = c(4,-0.25,1.5,-0.25,1))

pdf("./results/TCGA-GSEA.pdf",width = 6,height = 5)
p2[[1]]/plot_spacer()/p2[[2]] + plot_layout(heights = c(4,-0.25,1.5))
dev.off()


HallmarkList <- c("HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION",
                  "HALLMARK_APICAL_JUNCTION",
                  "HALLMARK_COAGULATION",
				  "HALLMARK_MYOGENESIS")
library(ggsci)
Color <- pal_nejm()(8)
library(GseaVis)
p <- gseaNb(object = Hallmark_GSEA,
            geneSetID = rev(HallmarkList),
            curveCol = Color[1:4],
            subPlot = 3,
            termWidth = 35,
            legend.position = c(0.8,0.8),
            addPval = T,pHjust = 0,
            pvalX = 0.1,pvalY = 0.1,pvalSize = 6)
p2 <- p
library(ggplot2)
library(patchwork)
p2[[1]] <- p2[[1]] + theme_bw()+
           theme(plot.title = element_blank(), 
		         axis.text.x = element_blank(), 
		         axis.text.y = element_text(size=16),
				  axis.ticks.x = element_blank(), 
			     axis.title.x = element_blank(), 
		         axis.title.y = element_text(size = 18),
			     legend.text = element_text(colour="black",size=16),
		         legend.title = element_blank(),
		         legend.position = c(0.7,0.8))
p2[[3]] <- p2[[3]] + theme_bw() +
           theme(plot.title = element_text(hjust = 0.5,size=20),
		         axis.text.x = element_text(hjust = 0.5,size=16),
		         axis.text.y = element_text(size=16),
			     axis.title.x = element_text(hjust = 0.5,size=18),
		         axis.title.y = element_text(size = 18))
p2[[1]]/p2[[2]]/p2[[3]] + plot_layout(heights = c(4,1.5,1))
p2[[1]]/plot_spacer()/p2[[2]]/plot_spacer()/p2[[3]] + plot_layout(heights = c(4,-0.25,1.5,-0.25,1))

pdf("./TCGA-GSEA-2.pdf",width = 6,height = 5)
p2[[1]]/plot_spacer()/p2[[2]] + plot_layout(heights = c(4,-0.25,1.5))
dev.off()




