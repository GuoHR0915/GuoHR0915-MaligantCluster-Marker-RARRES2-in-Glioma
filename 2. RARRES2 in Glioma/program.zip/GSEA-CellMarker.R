rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/Temp/9-RARRES2 in Glioma") 
Gene <- "RARRES2"
library(clusterProfiler)
set.seed(1234)
geneset <- rio::import("./data/PMID22937035-celltype.xlsx",sheet = 2)
geneset <- apply(geneset,2,function(x){return(as.character(na.omit(as.character(x))))})
lapply(geneset[1:3], head)
geneset <- do.call(cbind,geneset)
head(geneset)
geneset <- reshape2::melt(geneset)
head(geneset)
geneset <- data.frame(term = geneset[,2],
                      gene = geneset[,3])
head(geneset)
#geneset <- read.gmt("D:/data/MSigdb/human/msigdb_v2023.2.Hs_GMTs/h.all.v2023.2.Hs.symbols.gmt")
#################################################################
##########################TCGA-GBM###############################
#################################################################
load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-GBM-GeneSymbol.Rdata')
exprSet <- data.frame(SampleNames = colnames(exp_TPM),
                      Expression = as.numeric(exp_TPM[Gene,]),
                      SampleType = sapply(strsplit(colnames(exp_TPM),'-'),"[",4))
exprSet$Group <- ifelse(as.numeric(substr(exprSet$SampleType,1,2)) < 10,"Tumor","Normal")
table(exprSet$SampleType)
# 01A 01B 01C 02A 02B 11A 
# 146  10   1  12   1   5 
exprSet <- exprSet[exprSet$SampleType %in% c("01A"),]
exprSet$PatientNames <- substr(exprSet$SampleNames,1,12)
table(exprSet$SampleType)

exprSet$Group <- "Median"
quantile(as.numeric(exprSet[,"Expression"]),0.7)
exprSet$Group[as.numeric(exprSet$Expression) > quantile(exprSet$Expression,0.7)] <- "High"
exprSet$Group[as.numeric(exprSet$Expression) < quantile(exprSet$Expression,0.3)] <- "Low"
table(exprSet$Group)
exprSet <- exprSet[exprSet$Group != "Median",]
table(exprSet$Group)


minRow <- rowMeans(exp_Count) > 1  #按平均数筛选 
minNum <- rowSums(exp_Count > 0) > (0.8*ncol(exp_Count)) #表达量不为0的样品个数筛选 
#minNum <- rowSums(exp_Count > 0) >= (1*ncol(exp_Count))
exp_Count <- exp_Count[minRow & minNum,]
dim(exp_Count)#[1] 27577   176

exp_Count <- exp_Count[,exprSet$SampleNames]
dim(exp_Count)#[1] 27577   88

###分组
exprSet$Group <- ifelse(as.numeric(exprSet$Expression) > median(as.numeric(exprSet$Expression)),
                        "High","Low")
table(exprSet$Group)
group_list <- exprSet$Group

##################
#########差异分析
##################
library(limma)
library(edgeR)
design <- model.matrix(~0 + factor(group_list))
colnames(design) <- levels(factor(group_list))
rownames(design) <- colnames(exp_Count)

dge <- DGEList(counts = exp_Count)   # 将表达矩阵转换为edgeR的DGEList对象
dge <- calcNormFactors(dge)   # 进行标准化和表达量计算
v <- voom(dge, design, plot = TRUE, normalize = "quantile")   
vfit <- lmFit(v, design)
cont.matrix <- makeContrasts(contrasts = "High-Low", levels = design)
vfit <- contrasts.fit(vfit, cont.matrix)
efit <- eBayes(vfit)
DEG <- na.omit(topTable(efit, coef = "High-Low", n=Inf))
head(DEG)

##################
#########GSEA
##################
geneList <- DEG$logFC
names(geneList) <- rownames(DEG)
geneList <- sort(geneList, decreasing = T)
geneList <- geneList[geneList != 0]

set.seed(1234)
egmt <- GSEA(geneList, 
             TERM2GENE = geneset, verbose = FALSE,
             minGSSize = 3,
			 maxGSSize = 10000,
			 eps = 1e-30,
			 pvalueCutoff = 1,
			 pAdjustMethod = "BH")
head(egmt@result[,2:8])
print(dim(egmt@result[,2:8]))
TCGAGBM_Cellmark_ES  <- egmt@result

tmp <- egmt@result
tmp[tmp$qvalue < 0.05,4:8]	
               # enrichmentScore      NES       pvalue    p.adjust       qvalue
# M1 macrophages       0.5973919 2.023538 6.522757e-06 9.13186e-05 7.552667e-05
# T CD4 Naive          0.5579652 1.788550 8.668297e-04 4.84553e-03 4.007581e-03
# M2 macrophages       0.5371743 1.751375 1.038328e-03 4.84553e-03 4.007581e-03

#################################################################
##########################TCGA-LGG###############################
#################################################################
load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-LGG-GeneSymbol.Rdata')
exprSet <- data.frame(SampleNames = colnames(exp_TPM),
                      Expression = as.numeric(exp_TPM[Gene,]),
                      SampleType = sapply(strsplit(colnames(exp_TPM),'-'),"[",4))
exprSet$Group <- ifelse(as.numeric(substr(exprSet$SampleType,1,2)) < 10,"Tumor","Normal")
table(exprSet$SampleType)
# 01A 01B 02A 02B 
# 505  11  14   4
exprSet <- exprSet[exprSet$SampleType %in% c("01A"),]
exprSet$PatientNames <- substr(exprSet$SampleNames,1,12)
table(exprSet$SampleType)

exprSet$Group <- "Median"
quantile(as.numeric(exprSet[,"Expression"]),0.7)
exprSet$Group[as.numeric(exprSet$Expression) > quantile(exprSet$Expression,0.7)] <- "High"
exprSet$Group[as.numeric(exprSet$Expression) < quantile(exprSet$Expression,0.3)] <- "Low"
table(exprSet$Group)
exprSet <- exprSet[exprSet$Group != "Median",]
table(exprSet$Group)


minRow <- rowMeans(exp_Count) > 1  #按平均数筛选 
minNum <- rowSums(exp_Count > 0) > (0.8*ncol(exp_Count)) #表达量不为0的样品个数筛选 
#minNum <- rowSums(exp_Count > 0) >= (1*ncol(exp_Count))
exp_Count <- exp_Count[minRow & minNum,]
dim(exp_Count)#[1]27020   534
exp_Count <- exp_Count[,exprSet$SampleNames]
dim(exp_Count)#[1]27020   304


###分组
exprSet$Group <- ifelse(as.numeric(exprSet$Expression) > median(as.numeric(exprSet$Expression)),
                        "High","Low")
table(exprSet$Group)
group_list <- exprSet$Group

##################
#########差异分析
##################
library(limma)
library(edgeR)
design <- model.matrix(~0 + factor(group_list))
colnames(design) <- levels(factor(group_list))
rownames(design) <- colnames(exp_Count)

dge <- DGEList(counts = exp_Count)   # 将表达矩阵转换为edgeR的DGEList对象
dge <- calcNormFactors(dge)   # 进行标准化和表达量计算
v <- voom(dge, design, plot = TRUE, normalize = "quantile")   
vfit <- lmFit(v, design)
cont.matrix <- makeContrasts(contrasts = "High-Low", levels = design)
vfit <- contrasts.fit(vfit, cont.matrix)
efit <- eBayes(vfit)
DEG <- na.omit(topTable(efit, coef = "High-Low", n=Inf))
head(DEG)

##################
#########GSEA
##################
geneList <- DEG$logFC
names(geneList) <- rownames(DEG)
geneList <- sort(geneList, decreasing = T)
geneList <- geneList[geneList != 0]

set.seed(1234)
egmt <- GSEA(geneList, 
             TERM2GENE = geneset, verbose = FALSE,
             minGSSize = 3,
			 maxGSSize = 10000,
			 eps = 1e-20,
			 pvalueCutoff = 1,
			 pAdjustMethod = "BH")
head(egmt@result[,2:8])
print(dim(egmt@result[,2:8]))
TCGALGG_Cellmark_ES  <- egmt@result

tmp <- egmt@result
tmp[tmp$pvalue < 0.05,4:8]	
                               # enrichmentScore      NES       pvalue     p.adjust
# HSC (hematopoietic stem cells)       0.4271155 1.639360 3.599725e-05 0.0005039615
# T CD4 Naive                          0.5322719 1.688686 3.985489e-03 0.0278984259
# M1 macrophages                       0.4812020 1.571812 8.779931e-03 0.0409730107
                                     # qvalue
# HSC (hematopoietic stem cells) 0.0004168103
# T CD4 Naive                    0.0230738861
# M1 macrophages                 0.0338874524

#################################################################
#####################CGGA-mRNAseq_325############################
#################################################################
phenoDat <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325_clinical.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
head(phenoDat)
phenoDat <- phenoDat[phenoDat$PRS_type == "Primary",]
exprSet <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325.RSEM-genes.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]

exprSet <- exprSet[,colnames(exprSet) %in% phenoDat$CGGA_ID]
phenoDat <- phenoDat[phenoDat$CGGA_ID %in% colnames(exprSet),]
exprSet <- data.frame(SampleNames = colnames(exprSet),
                      Expression = as.numeric(exprSet[Gene,]))
head(exprSet)
dim(exprSet)

###分组
exprSet$Group <- "Median"
quantile(as.numeric(exprSet[,"Expression"]),0.7)
exprSet$Group[as.numeric(exprSet$Expression) > quantile(exprSet$Expression,0.7)] <- "High"
exprSet$Group[as.numeric(exprSet$Expression) < quantile(exprSet$Expression,0.3)] <- "Low"
table(exprSet$Group)
exprSet <- exprSet[exprSet$Group != "Median",]
table(exprSet$Group)


exp_Count <- read.table("D:/data/CGGA/mRNAseq_325/CGGA.mRNAseq_325.Read_Counts-genes.20220620.txt",
                        sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exp_Count) <- exp_Count[,1]
exp_Count <- exp_Count[,-1]
exp_Count[1:4,1:4]
dim(exp_Count)#[1]55523   325
exp_Count <- exp_Count[,exprSet$SampleNames]
dim(exp_Count)#[1] 55523   137

group_list <- exprSet$Group
table(group_list)

##################
#########差异分析
##################
library(limma)
library(edgeR)
design <- model.matrix(~0 + factor(group_list))
colnames(design) <- levels(factor(group_list))
rownames(design) <- colnames(exp_Count)

dge <- DGEList(counts = exp_Count)   # 将表达矩阵转换为edgeR的DGEList对象
dge <- calcNormFactors(dge)   # 进行标准化和表达量计算
v <- voom(dge, design, plot = TRUE, normalize = "quantile")   
vfit <- lmFit(v, design)
cont.matrix <- makeContrasts(contrasts = "High-Low", levels = design)
vfit <- contrasts.fit(vfit, cont.matrix)
efit <- eBayes(vfit)
DEG <- na.omit(topTable(efit, coef = "High-Low", n=Inf))
head(DEG)

##################
#########GSEA
##################
geneList <- DEG$logFC
names(geneList) <- rownames(DEG)
geneList <- sort(geneList, decreasing = T)
geneList <- geneList[geneList != 0]

set.seed(1234)
egmt <- GSEA(geneList, 
             TERM2GENE = geneset, verbose = FALSE,
             minGSSize = 3,
			 maxGSSize = 10000,
			 eps = 1e-20,
			 pvalueCutoff = 1,
			 pAdjustMethod = "BH")
head(egmt@result[,2:8])
print(dim(egmt@result[,2:8]))
mRNAseq_325_Cellmark_ES  <- egmt@result
tmp <- egmt@result
tmp[tmp$pvalue < 0.05,4:8]	
                                               # enrichmentScore      NES       pvalue
# GIM (glioma-infiltrating microglia/macrophage)       0.7411425 2.308240 1.408107e-16
# M1 macrophages                                       0.7819433 2.196241 4.489750e-11
# M2 macrophages                                       0.7093115 1.950663 4.202168e-06
# Monocytes                                            0.5957460 1.709368 5.080694e-04
# HSC (hematopoietic stem cells)                       0.4289482 1.426326 3.784037e-03
# T CD4 Naive                                          0.5808000 1.565637 8.994379e-03
# B Cell                                               0.5167504 1.433175 2.321924e-02
                                                   # p.adjust       qvalue
# GIM (glioma-infiltrating microglia/macrophage) 1.971350e-15 1.037552e-15
# M1 macrophages                                 3.142825e-10 1.654118e-10
# M2 macrophages                                 1.961012e-05 1.032111e-05
# Monocytes                                      1.778243e-03 9.359173e-04
# HSC (hematopoietic stem cells)                 1.059530e-02 5.576475e-03
# T CD4 Naive                                    2.098689e-02 1.104573e-02
# B Cell                                         4.643847e-02 2.444130e-02

#################################################################
#####################CGGA-mRNAseq_693############################
#################################################################
phenoDat <- read.table("D:/data/CGGA/mRNAseq_693/CGGA.mRNAseq_693_clinical.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
head(phenoDat)
phenoDat <- phenoDat[phenoDat$PRS_type == "Primary",]
exprSet <- read.table("D:/data/CGGA/mRNAseq_693/CGGA.mRNAseq_693.RSEM-genes.20200506.txt",
                       sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exprSet) <- exprSet[,1]
exprSet <- exprSet[,-1]

exprSet <- exprSet[,colnames(exprSet) %in% phenoDat$CGGA_ID]
phenoDat <- phenoDat[phenoDat$CGGA_ID %in% colnames(exprSet),]
exprSet <- data.frame(SampleNames = colnames(exprSet),
                      Expression = as.numeric(exprSet[Gene,]))
head(exprSet)
dim(exprSet)

###分组
exprSet$Group <- "Median"
quantile(as.numeric(exprSet$Expression),0.7)
exprSet$Group[as.numeric(exprSet$Expression) > quantile(exprSet$Expression,0.7)] <- "High"
exprSet$Group[as.numeric(exprSet$Expression) < quantile(exprSet$Expression,0.3)] <- "Low"
table(exprSet$Group)
exprSet <- exprSet[exprSet$Group != "Median",]
table(exprSet$Group)


exp_Count <- read.table("D:/data/CGGA/mRNAseq_693/CGGA.mRNAseq_693.Read_Counts-genes.20220620.txt",
                        sep = '\t',quote = "",fill = T,header = T,stringsAsFactors = F)
rownames(exp_Count) <- exp_Count[,1]
exp_Count <- exp_Count[,-1]
exp_Count[1:4,1:4]
dim(exp_Count)#[1]55523   693
exp_Count <- exp_Count[,exprSet$SampleNames]
dim(exp_Count)#[1]55523   254

group_list <- exprSet$Group
table(group_list)

##################
#########差异分析
##################
library(limma)
library(edgeR)
design <- model.matrix(~0 + factor(group_list))
colnames(design) <- levels(factor(group_list))
rownames(design) <- colnames(exp_Count)

dge <- DGEList(counts = exp_Count)   # 将表达矩阵转换为edgeR的DGEList对象
dge <- calcNormFactors(dge)   # 进行标准化和表达量计算
v <- voom(dge, design, plot = TRUE, normalize = "quantile")   
vfit <- lmFit(v, design)
cont.matrix <- makeContrasts(contrasts = "High-Low", levels = design)
vfit <- contrasts.fit(vfit, cont.matrix)
efit <- eBayes(vfit)
DEG <- na.omit(topTable(efit, coef = "High-Low", n=Inf))
head(DEG)

##################
#########GSEA
##################
geneList <- DEG$logFC
names(geneList) <- rownames(DEG)
geneList <- sort(geneList, decreasing = T)
geneList <- geneList[geneList != 0]

set.seed(1234)
egmt <- GSEA(geneList, 
             TERM2GENE = geneset, verbose = FALSE,
             minGSSize = 3,
			 maxGSSize = 10000,
			 eps = 1e-20,
			 pvalueCutoff = 1,
			 pAdjustMethod = "BH")
head(egmt@result[,2:8])
print(dim(egmt@result[,2:8]))
mRNAseq_693_Cellmark_ES  <- egmt@result
tmp <- egmt@result
tmp[tmp$pvalue < 0.05,4:8]	

mRNAseq_693_Cellmark_ES[mRNAseq_693_Cellmark_ES$pvalue < 0.05,1]	
mRNAseq_325_Cellmark_ES[mRNAseq_325_Cellmark_ES$pvalue < 0.05,1]	
TCGAGBM_Cellmark_ES[TCGAGBM_Cellmark_ES$pvalue < 0.05,1]	
TCGALGG_Cellmark_ES[TCGALGG_Cellmark_ES$pvalue < 0.05,1]	
intersect(intersect(mRNAseq_693_Cellmark_ES[mRNAseq_693_Cellmark_ES$pvalue < 0.05,1],
                    mRNAseq_325_Cellmark_ES[mRNAseq_325_Cellmark_ES$pvalue < 0.05,1]),
          intersect(TCGAGBM_Cellmark_ES[TCGAGBM_Cellmark_ES$pvalue < 0.05,1],
                    TCGALGG_Cellmark_ES[TCGALGG_Cellmark_ES$pvalue < 0.05,1]))
#[1] "M1 macrophages" "GIM (glioma-infiltrating microglia/macrophage)" "M2 macrophages" 

library(VennDetail)
ven <- venndetail(list(mRNAseq_693 = mRNAseq_693_Cellmark_ES[mRNAseq_693_Cellmark_ES$pvalue < 0.05,1], 
                       mRNAseq_325 = mRNAseq_325_Cellmark_ES[mRNAseq_325_Cellmark_ES$pvalue < 0.05,1],
                       TCGAGBM = TCGAGBM_Cellmark_ES[TCGAGBM_Cellmark_ES$pvalue < 0.05,1],
                       TCGALGG = TCGALGG_Cellmark_ES[TCGALGG_Cellmark_ES$pvalue < 0.05,1]))
detail(ven)
plot(ven, type = "venn",#默认type
     col = "black", 
     mycol = c("dodgerblue", "goldenrod1", "darkorange1", "seagreen3","orchid3"), 
     cat.cex = 2, #Numeric vector giving the size of the category names.
     alpha = 0.5, 
     cex = 4)

pdf("GSEA-Cellmark-Venn.pdf",width = 6,height = 6)
plot(ven, type = "venn",#默认type
     col = "black", 
     mycol = c("dodgerblue", "goldenrod1", "darkorange1", "seagreen3","orchid3"), 
     cat.cex = 2, #Numeric vector giving the size of the category names.
     alpha = 0.5, 
     cex = 4)
dev.off()



mRNAseq_693_Cellmark_ES$DataSet <-"CGGA-mRNAseq693"
mRNAseq_325_Cellmark_ES$DataSet <- "CGGA-mRNAseq325" 
TCGAGBM_Cellmark_ES$DataSet <-"TCGA-GBM"
TCGALGG_Cellmark_ES$DataSet <- "TCGA-LGG" 	

tmp <- c("M1 macrophages","GIM (glioma-infiltrating microglia/macrophage)","M2 macrophages" )
GSEA_Cellmark <- rbind(TCGAGBM_Cellmark_ES[tmp,-c(9:11)],TCGALGG_Cellmark_ES[tmp,-c(9:11)],
                       mRNAseq_325_Cellmark_ES[tmp,-c(9:11)],mRNAseq_693_Cellmark_ES[tmp,-c(9:11)])
GSEA_Cellmark
GSEA_Cellmark$Description <- factor(GSEA_Cellmark$Description,
                                    levels = c("GIM (glioma-infiltrating microglia/macrophage)",
	                                           "M1 macrophages","M2 macrophages"),
									labels = c("GIM","M1 macrophages","M2 macrophages"))
GSEA_Cellmark$DataSet <- factor(GSEA_Cellmark$DataSet,
                                levels = c("TCGA-GBM","TCGA-LGG","CGGA-mRNAseq325","CGGA-mRNAseq693"))
library(ggplot2)
mytheme <- theme(plot.title = element_text(hjust = 0.5,size = 20),
				 axis.text.x = element_text(angle = 30,hjust = 1,size = 20), 
				 axis.text.y = element_text(size = 20),
				 axis.title.y = element_text(size = 20), 
				 axis.line = element_line(colour = "black",size = 1), 
				 panel.grid.minor = element_blank(),
                 panel.grid.major = element_blank(),
				 strip.text = element_text(size = 20),
                 legend.position = "none")
Colorlist <- alpha(c("darkorange1", "seagreen3", "goldenrod1","dodgerblue"),0.7)
library(ggh4x)
class_strip <- strip_themed(background_x = elem_list_rect(fill = Colorlist))
library(stringr)
p2 <- ggplot(GSEA_Cellmark,aes(x = Description,y = NES,fill = DataSet)) +
      geom_col() +
      scale_y_continuous(expand = c(0,0),limits = c(0,2.5),breaks = seq(0,2.5,0.5)) +
	  facet_grid2(.~DataSet, scales = "free", strip = class_strip) +
	  scale_fill_manual(values = alpha(Colorlist,0.7)) +
	  scale_x_discrete(labels = function(dat) str_wrap(dat,width = 30)) +
      labs(title = NULL,x = NULL, y = "Normalized Enrichment Score") +
      theme_bw() + mytheme
p2

pdf("GSEA-Cellmark-NES Barplot.pdf",width = 15,height = 6)
p2
dev.off()


# print(dim(TCGAGBM_Cellmark_ES))
# print(dim(TCGALGG_Cellmark_ES))
# print(dim(mRNAseq_325_Cellmark_ES))
# print(dim(mRNAseq_693_Cellmark_ES))
# save(TCGAGBM_Cellmark_ES,TCGALGG_Cellmark_ES,
     # mRNAseq_325_Cellmark_ES,mRNAseq_693_Cellmark_ES,
	 # file = "./results/step8.GSEA-RARRES2-Cellmark.Rdata")