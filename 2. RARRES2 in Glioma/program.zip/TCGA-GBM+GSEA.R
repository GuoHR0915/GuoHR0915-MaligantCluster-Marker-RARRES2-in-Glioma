rm(list = ls())
setwd("D:/Temp/9-RARRES2 in Glioma") 
########################################################
#######################提取表达量########################
########################################################
Gene <- "RARRES2"
load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-GBM-GeneSymbol.Rdata')
exprSet <- data.frame(SampleNames = colnames(exp_TPM),
                      Expression = as.numeric(exp_TPM[Gene,]),
                      SampleType = sapply(strsplit(colnames(exp_TPM),'-'),"[",4))
exprSet$Group <- ifelse(as.numeric(substr(exprSet$SampleType,1,2)) < 10,"Tumor","Normal")
table(exprSet$SampleType)
# 01A 01B 01C 02A 02B 11A 
# 146  10   1  12   1   5 
table(exprSet$Group)


exprSet$ID <- substr(exprSet$SampleNames,1,12)
##仅保留肿瘤样本
exprSet <- exprSet[exprSet$Group == "Tumor",]
table(exprSet$Group)
##仅保留原发癌样本 & A
exprSet <- exprSet[exprSet$SampleType %in% c("01A"),]
table(exprSet$SampleType)
head(exprSet)


########################################################
#######################差异分析########################
########################################################
table(exprSet$SampleNames %in% colnames(exp_TPM))
exp_Count <- exp_Count[,exprSet$SampleNames]
identical(colnames(exp_Count),exprSet$SampleNames)

exprSet$Group <- ifelse(exprSet$Expression > median(exprSet$Expression),"High","Low")
table(exprSet$Group)
group_list <- exprSet$Group

minRow <- rowMeans(exp_Count) > 0  #按平均数筛选 
minNum <- rowSums(exp_Count > 0) > (0.8*ncol(exp_Count)) #表达量不为0的样品个数筛选 
exp_Count <- exp_Count[minRow & minNum,]
dim(exp_Count)#[1]27610   146

############################DESeq2
library(DESeq2)
##设置分组信息并构建dds对象
database <- exp_Count
condition <- factor(group_list, levels = c("Low","High"))
coldata <- data.frame(row.names = colnames(database), condition)
dds <- DESeqDataSetFromMatrix(countData = database, colData = coldata, design=~condition)

##使用DESeq函数估计离散度，然后差异分析获得res对象
dds <- DESeq(dds)
res <- results(dds)

#筛选差异基因
resOrdered <- res[order(res$padj),]
head(resOrdered)
DESeq2_DEG <- na.omit(as.data.frame(resOrdered))
head(DESeq2_DEG)
            # baseMean log2FoldChange     lfcSE      stat       pvalue         padj
# RARRES2   2811.36411       2.601244 0.1814534 14.335603 1.311029e-46 3.619750e-42
# TPTEP1     140.54835      -2.590788 0.2898153 -8.939445 3.911286e-19 5.399531e-15
# MME        117.02448       2.495499 0.2951041  8.456336 2.759107e-17 2.539298e-13
# CXCL13     152.95781       3.082875 0.3840289  8.027717 9.930360e-16 6.854431e-12
# LINC00514   57.39884       2.750809 0.3498899  7.861928 3.782659e-15 2.088784e-11
# KHDRBS2     25.44768      -2.033467 0.2696907 -7.539998 4.699777e-14 2.162681e-10
DEG <- DESeq2_DEG[,c(2,6)]
colnames(DEG) <- c('log2FoldChange','padj')
head(DEG)
DEG[Gene,]

########################################################
#####################GSEA富集分析#######################
########################################################
geneList <- DEG$log2FoldChange
names(geneList) <- rownames(DEG)
geneList <- sort(geneList, decreasing = T)
geneList <- geneList[geneList != 0]
library(GSEABase)
library(enrichplot)
library(clusterProfiler)

set.seed(1234)
geneset <- read.gmt("D:/data/MSigdb/human/msigdb_v2023.2.Hs_GMTs/c5.go.bp.v2023.2.Hs.symbols.gmt")

egmt <- GSEA(geneList, 
             TERM2GENE = geneset, 
			 verbose = FALSE,
             minGSSize = 5,
			 maxGSSize = 10000,
			 eps = 1e-10,
			 pvalueCutoff = 0.99,
			 pAdjustMethod = "BH")
Pathways <- c(rownames(egmt@result)[grep("FATTY",rownames(egmt@result))],
              rownames(egmt@result)[grep("SPHOLIPID",rownames(egmt@result))],
			  rownames(egmt@result)[grep("LIPID",rownames(egmt@result))],
			  rownames(egmt@result)[grep("STEROID",rownames(egmt@result))],
			  rownames(egmt@result)[grep("RETINOL",rownames(egmt@result))])
tmp <- egmt@result[unique(Pathways),]
tmp[tmp$pvalue < 0.05,3:8]
                                                  # setSize enrichmentScore       NES       pvalue     p.adjust       qvalue
# GOBP_FATTY_ACID_TRANSPORT                              95       0.4179568  1.507502 6.246449e-03 5.604262e-02 4.653225e-02
# GOBP_RESPONSE_TO_FATTY_ACID                            48       0.4562114  1.480191 2.054272e-02 1.290153e-01 1.071215e-01
# GOBP_LONG_CHAIN_FATTY_ACID_CATABOLIC_PROCESS            8       0.7506988  1.607665 2.841615e-02 1.590265e-01 1.320399e-01
# GOBP_LONG_CHAIN_FATTY_ACID_TRANSPORT                   55       0.4392303  1.461795 2.909026e-02 1.614267e-01 1.340328e-01
# GOBP_NEGATIVE_REGULATION_OF_FATTY_ACID_TRANSPORT        7       0.7694281  1.604639 2.976719e-02 1.635163e-01 1.357677e-01
# GOBP_REGULATION_OF_FATTY_ACID_METABOLIC_PROCESS        76       0.3958257  1.379531 3.684971e-02 1.901487e-01 1.578807e-01
# GOBP_UNSATURATED_FATTY_ACID_BIOSYNTHETIC_PROCESS       44       0.4535766  1.460806 4.386248e-02 2.135861e-01 1.773408e-01
# GOBP_REGULATION_OF_FATTY_ACID_TRANSPORT                26       0.5299308  1.493791 4.980080e-02 2.361979e-01 1.961154e-01
# GOBP_RESPONSE_TO_LIPID                                817       0.3757474  1.706568 1.036068e-10 1.103337e-08 9.161019e-09
# GOBP_CELLULAR_RESPONSE_TO_LIPID                       537       0.3639935  1.609887 4.715907e-07 2.112956e-05 1.754390e-05
# GOBP_LIPID_LOCALIZATION                               426       0.3350083  1.450121 4.869499e-04 7.454392e-03 6.189390e-03
# GOBP_REGULATION_OF_LIPID_LOCALIZATION                 145       0.4174840  1.604621 7.324693e-04 1.043249e-02 8.662107e-03
# GOBP_LIPID_STORAGE                                     81       0.4857112  1.713043 9.729045e-04 1.314136e-02 1.091129e-02
# GOBP_POSITIVE_REGULATION_OF_LIPID_LOCALIZATION         97       0.4548139  1.645257 1.271815e-03 1.614041e-02 1.340140e-02
# GOBP_GALACTOLIPID_METABOLIC_PROCESS                     7      -0.8160827 -1.641065 5.050262e-03 4.769836e-02 3.960400e-02
# GOBP_REGULATION_OF_PROTEIN_LIPIDATION                  10      -0.7560300 -1.703884 9.763348e-03 7.672843e-02 6.370770e-02
# GOBP_GALACTOLIPID_BIOSYNTHETIC_PROCESS                  6      -0.8234569 -1.572880 1.204114e-02 8.951271e-02 7.432250e-02
# GOBP_POSITIVE_REGULATION_OF_LIPID_TRANSPORT            77       0.4350394  1.520469 1.230890e-02 9.053635e-02 7.517244e-02
# GOBP_REGULATION_OF_LIPID_CATABOLIC_PROCESS             50       0.4843042  1.579301 1.271030e-02 9.277152e-02 7.702830e-02
# GOBP_REGULATION_OF_LIPID_TRANSPORT                    120       0.3817516  1.439801 1.663894e-02 1.105470e-01 9.178733e-02
# GOBP_REGULATION_OF_LIPID_STORAGE                       46       0.4776740  1.543972 1.760923e-02 1.150157e-01 9.549765e-02
# GOBP_LIPID_EXPORT_FROM_CELL                            41       0.4860137  1.537542 1.887575e-02 1.215057e-01 1.008863e-01
# GOBP_LIPID_PHOSPHORYLATION                             11      -0.6991482 -1.617250 2.684129e-02 1.540858e-01 1.279376e-01
# GOBP_REGULATION_OF_LIPID_METABOLIC_PROCESS            289       0.3049034  1.271766 2.866984e-02 1.595955e-01 1.325123e-01
# GOBP_RESPONSE_TO_CORTICOSTEROID                       130       0.4752415  1.799762 5.185253e-05 1.225120e-03 1.017219e-03
# GOBP_RESPONSE_TO_STEROID_HORMONE                      297       0.3402096  1.424772 2.655286e-03 2.925194e-02 2.428792e-02
# GOBP_REGULATION_OF_STEROID_METABOLIC_PROCESS           85       0.4397065  1.554345 9.086480e-03 7.304973e-02 6.065328e-02
# GOBP_CELLULAR_RESPONSE_TO_CORTICOSTEROID_STIMULUS      53       0.4771001  1.574517 1.098820e-02 8.393063e-02 6.968770e-02
# GOBP_STEROID_BIOSYNTHETIC_PROCESS                     156       0.3421609  1.318502 4.189497e-02 2.061917e-01 1.712012e-01

gsea_results <- egmt@result
gsea_results2 <- gsea_results[order(gsea_results$enrichmentScore,decreasing=T),]
gsea_results2[1:10,2:6]
# library(sjPlot)
# tab_df(title = '',gsea_results2[,2:8])

library(ggsci)
Color <- c("#BC3C29FF","#0072B5FF","#E18727FF","#20854EFF","#7876B1FF",
           "#6F99ADFF","#FFDC91FF","#EE4C97FF")
library(ggplot2)
library(patchwork)
library(GseaVis)
mytheme1 <- theme_bw() +
            theme(plot.title = element_text(hjust = 0.5,size = 18), 
		          axis.text.x = element_blank(), 
		          axis.text.y = element_text(size = 16),
				  axis.ticks.x = element_blank(), 
			      axis.title.x = element_blank(), 
		          axis.title.y = element_text(size = 18),
			      legend.text = element_text(size = 16),
		          legend.title = element_blank(),
		          legend.position = c(0.7,0.8))
mytheme2 <- theme_bw() +
            theme(plot.title = element_text(hjust = 0.5,size = 20),
		         axis.text.x = element_text(hjust = 0.5,size = 16),
		         axis.text.y = element_text(size = 16),
			     axis.title.x = element_text(hjust = 0.5,size = 18),
		         axis.title.y = element_text(size = 18))
Results <- lapply(Pathways,function(Pathway){
                      p <- gseaNb(object = egmt,
                                  geneSetID = gsea_results2[Pathway,"ID"],
                                  curveCol = "#BC3C29FF",
                                  subPlot = 3,
                                  termWidth = 35,
                                  legend.position = c(0.8,0.8),
                                  addPval = T,pHjust = 0,
                                  pvalX = 0.5,pvalY = 0.7,pvalSize = 6)
                      p2 <- p
					  p2[[1]] <- p2[[1]] + mytheme1
					  p2[[3]] <- p2[[3]] + mytheme2
					  p <- p2[[1]]/plot_spacer()/p2[[2]]/plot_spacer()/p2[[3]] + plot_layout(heights = c(4,-0.25,1.5,-0.25,1))
                      return(p)
})


# p2[[1]]/p2[[2]]/p2[[3]] + plot_layout(heights = c(4,1.5,1))
# p2[[1]]/plot_spacer()/p2[[2]]/plot_spacer()/p2[[3]] + plot_layout(heights = c(4,-0.25,1.5,-0.25,1))

p <- gseaNb(object = egmt,
            geneSetID = gsea_results2[Pathways[c(1,2)],"ID"],
            curveCol = Color,
            subPlot = 3,
            termWidth = 35,
            legend.position = c(0.8,0.8),
            addPval = T,pHjust = 0,
            pvalX = 0.1,pvalY = 0.1,pvalSize = 6)
p2 <- p
p2[[1]] <- p2[[1]] + mytheme1
p2[[3]] <- p2[[3]] + mytheme2
p <- p2[[1]]/plot_spacer()/p2[[2]]/plot_spacer()/p2[[3]] + plot_layout(heights = c(4,-0.25,1.5,-0.25,1))
p


pdf("./TCGA-GBM-GSEA.pdf",width = 6,height = 6)
Results
p
dev.off()
