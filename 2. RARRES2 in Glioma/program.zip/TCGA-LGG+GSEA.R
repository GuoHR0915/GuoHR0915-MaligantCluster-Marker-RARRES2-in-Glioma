rm(list = ls())
setwd("D:/Temp/9-RARRES2 in Glioma") 
########################################################
#######################提取表达量########################
########################################################
Gene <- "RARRES2"
load('D:/data/TCGA/TCGAbiolinks-EXP/TCGA-LGG-GeneSymbol.Rdata')
exprSet <- data.frame(SampleNames = colnames(exp_TPM),
                      Expression = as.numeric(exp_TPM[Gene,]),
                      SampleType = sapply(strsplit(colnames(exp_TPM),'-'),"[",4))
exprSet$Group <- ifelse(as.numeric(substr(exprSet$SampleType,1,2)) < 10,"Tumor","Normal")
table(exprSet$SampleType)
# 01A 01B 02A 02B 
# 505  11  14   4 
table(exprSet$Group)


exprSet$ID <- substr(exprSet$SampleNames,1,12)
##仅保留肿瘤样本
exprSet <- exprSet[exprSet$Group == "Tumor",]
table(exprSet$Group)
##仅保留原发癌样本 & A
exprSet <- exprSet[exprSet$SampleType %in% c("01A"),]
table(exprSet$SampleType)
head(exprSet)


########################################################
#######################差异分析########################
########################################################
table(exprSet$SampleNames %in% colnames(exp_TPM))
exp_Count <- exp_Count[,exprSet$SampleNames]
identical(colnames(exp_Count),exprSet$SampleNames)

exprSet$Group <- ifelse(exprSet$Expression > median(exprSet$Expression),"High","Low")
table(exprSet$Group)
group_list <- exprSet$Group

minRow <- rowMeans(exp_Count) > 0  #按平均数筛选 
minNum <- rowSums(exp_Count > 0) > (0.8*ncol(exp_Count)) #表达量不为0的样品个数筛选 
exp_Count <- exp_Count[minRow & minNum,]
dim(exp_Count)#[1]27028   505

############################DESeq2
library(DESeq2)
##设置分组信息并构建dds对象
database <- exp_Count
condition <- factor(group_list, levels = c("Low","High"))
coldata <- data.frame(row.names = colnames(database), condition)
dds <- DESeqDataSetFromMatrix(countData = database, colData = coldata, design=~condition)

##使用DESeq函数估计离散度，然后差异分析获得res对象
dds <- DESeq(dds)
res <- results(dds)

#筛选差异基因
resOrdered <- res[order(res$padj),]
head(resOrdered)
DESeq2_DEG <- na.omit(as.data.frame(resOrdered))
head(DESeq2_DEG)
         # baseMean log2FoldChange     lfcSE     stat        pvalue          padj
# RARRES2 636.34698       4.175053 0.1259438 33.15014 5.637722e-241 1.523764e-236
# PDLIM4  607.66062       3.320619 0.1256021 26.43761 5.066106e-154 6.846336e-150
# MEOX2   270.21504       5.061307 0.2018328 25.07673 8.924181e-139 8.040092e-135
# DRC1    123.19527       4.381958 0.1785849 24.53712 5.936808e-133 4.011501e-129
# TSTD1   152.34433       2.794922 0.1152007 24.26133 5.020912e-130 2.714104e-126
# AQP5     82.15306       4.413999 0.1820685 24.24361 7.721952e-130 3.478482e-126
DEG <- DESeq2_DEG[,c(2,6)]
colnames(DEG) <- c('log2FoldChange','padj')
head(DEG)
DEG[Gene,]

########################################################
#####################GSEA富集分析#######################
########################################################
geneList <- DEG$log2FoldChange
names(geneList) <- rownames(DEG)
geneList <- sort(geneList, decreasing = T)
geneList <- geneList[geneList != 0]
library(GSEABase)
library(enrichplot)
library(clusterProfiler)

set.seed(1234)
geneset <- read.gmt("D:/data/MSigdb/human/msigdb_v2023.2.Hs_GMTs/c5.go.bp.v2023.2.Hs.symbols.gmt")

egmt <- GSEA(geneList, 
             TERM2GENE = geneset, 
			 verbose = FALSE,
             minGSSize = 5,
			 maxGSSize = 10000,
			 eps = 1e-10,
			 pvalueCutoff = 0.99,
			 pAdjustMethod = "BH")
Pathways <- c(rownames(egmt@result)[grep("FATTY",rownames(egmt@result))],
              rownames(egmt@result)[grep("SPHOLIPID",rownames(egmt@result))],
			  rownames(egmt@result)[grep("LIPID",rownames(egmt@result))],
			  rownames(egmt@result)[grep("STEROID",rownames(egmt@result))],
			  rownames(egmt@result)[grep("RETINOL",rownames(egmt@result))])
tmp <- egmt@result[unique(Pathways),]
tmp[tmp$pvalue < 0.01,3:8]
                                                    # setSize enrichmentScore      NES       pvalue     p.adjust       qvalue
# GOBP_FATTY_ACID_TRANSPORT                                96       0.6119437 1.673394 1.618641e-05 4.629058e-04 3.659215e-04
# GOBP_FATTY_ACID_METABOLIC_PROCESS                       343       0.4897490 1.383814 3.732393e-05 9.513019e-04 7.519928e-04
# GOBP_LONG_CHAIN_FATTY_ACID_TRANSPORT                     55       0.6294657 1.655124 2.892090e-04 5.225907e-03 4.131017e-03
# GOBP_VERY_LONG_CHAIN_FATTY_ACID_METABOLIC_PROCESS        34       0.6691173 1.681616 9.079669e-04 1.313839e-02 1.038574e-02
# GOBP_REGULATION_OF_FATTY_ACID_METABOLIC_PROCESS          78       0.5659651 1.523268 1.359034e-03 1.778743e-02 1.406075e-02
# GOBP_FATTY_ACID_DERIVATIVE_METABOLIC_PROCESS             66       0.5673787 1.518238 3.730018e-03 3.763450e-02 2.974962e-02
# GOBP_REGULATION_OF_FATTY_ACID_BETA_OXIDATION             19       0.7048116 1.648892 6.086262e-03 5.294683e-02 4.185384e-02
# GOBP_LONG_CHAIN_FATTY_ACID_CATABOLIC_PROCESS              8       0.8445904 1.670864 8.663704e-03 6.888444e-02 5.445233e-02
# GOBP_GLYCEROPHOSPHOLIPID_METABOLIC_PROCESS              279       0.4520335 1.272353 6.878453e-03 5.823436e-02 4.603357e-02
# GOBP_LIPID_METABOLIC_PROCESS                           1215       0.4625427 1.325839 3.406447e-10 3.749156e-08 2.963663e-08
# GOBP_LIPID_LOCALIZATION                                 428       0.5109368 1.447643 5.191505e-08 3.367062e-06 2.661622e-06
# GOBP_RESPONSE_TO_LIPID                                  806       0.4683090 1.336359 6.029913e-08 3.775973e-06 2.984862e-06
# GOBP_CELLULAR_LIPID_METABOLIC_PROCESS                   886       0.4498365 1.285787 8.641985e-07 3.948137e-05 3.120955e-05
# GOBP_LIPID_CATABOLIC_PROCESS                            290       0.5026774 1.413167 1.829102e-05 5.120459e-04 4.047662e-04
# GOBP_LIPID_BIOSYNTHETIC_PROCESS                         656       0.4443496 1.264564 8.178477e-05 1.844983e-03 1.458437e-03
# GOBP_REGULATION_OF_LIPID_METABOLIC_PROCESS              289       0.4859319 1.366622 1.417049e-04 2.907753e-03 2.298544e-03
# GOBP_GLYCEROLIPID_METABOLIC_PROCESS                     349       0.4625829 1.307338 1.021662e-03 1.429933e-02 1.130345e-02
# GOBP_POSITIVE_REGULATION_OF_LIPID_LOCALIZATION           97       0.5442691 1.490206 1.289679e-03 1.709531e-02 1.351364e-02
# GOBP_CELLULAR_RESPONSE_TO_LIPID                         535       0.4325973 1.228214 2.053414e-03 2.445245e-02 1.932937e-02
# GOBP_POSITIVE_REGULATION_OF_LIPID_METABOLIC_PROCESS     124       0.5203370 1.435484 2.798958e-03 3.094616e-02 2.446257e-02
# GOBP_REGULATION_OF_LIPID_BIOSYNTHETIC_PROCESS           155       0.4988039 1.388860 2.867361e-03 3.146300e-02 2.487113e-02
# GOBP_REGULATION_OF_LIPID_CATABOLIC_PROCESS               51       0.5804096 1.518436 5.344341e-03 4.870928e-02 3.850410e-02
# GOBP_POSITIVE_REGULATION_OF_LIPID_TRANSPORT              76       0.5379164 1.446188 6.108164e-03 5.301738e-02 4.190961e-02
# GOBP_GLYCEROLIPID_BIOSYNTHETIC_PROCESS                  234       0.4567656 1.284777 8.444430e-03 6.784012e-02 5.362680e-02
# GOBP_STEROID_METABOLIC_PROCESS                          261       0.4808298 1.352504 5.357968e-04 8.496339e-03 6.716255e-03
# GOBP_RESPONSE_TO_STEROID_HORMONE                        299       0.4540504 1.276084 2.941356e-03 3.193723e-02 2.524600e-02
# GOBP_RESPONSE_TO_CORTICOSTEROID                         132       0.5022826 1.388420 5.391236e-03 4.901369e-02 3.874474e-02

gsea_results <- egmt@result
gsea_results2 <- gsea_results[order(gsea_results$enrichmentScore,decreasing = T),]
gsea_results2[1:10,2:6]
# library(sjPlot)
# tab_df(title = '',gsea_results2[,2:8])

library(ggsci)
Color <- c("#BC3C29FF","#0072B5FF","#E18727FF","#20854EFF","#7876B1FF",
           "#6F99ADFF","#FFDC91FF","#EE4C97FF")
library(ggplot2)
library(patchwork)
library(GseaVis)
mytheme1 <- theme_bw() +
            theme(plot.title = element_text(hjust = 0.5,size = 18), 
		          axis.text.x = element_blank(), 
		          axis.text.y = element_text(size = 16),
				  axis.ticks.x = element_blank(), 
			      axis.title.x = element_blank(), 
		          axis.title.y = element_text(size = 18),
			      legend.text = element_text(size = 16),
		          legend.title = element_blank(),
		          legend.position = c(0.7,0.8))
mytheme2 <- theme_bw() +
            theme(plot.title = element_text(hjust = 0.5,size = 20),
		         axis.text.x = element_text(hjust = 0.5,size = 16),
		         axis.text.y = element_text(size = 16),
			     axis.title.x = element_text(hjust = 0.5,size = 18),
		         axis.title.y = element_text(size = 18))
Results <- lapply(Pathways,function(Pathway){
                      p <- gseaNb(object = egmt,
                                  geneSetID = gsea_results2[Pathway,"ID"],
                                  curveCol = "#BC3C29FF",
                                  subPlot = 3,
                                  termWidth = 35,
                                  legend.position = c(0.8,0.8),
                                  addPval = T,pHjust = 0,
                                  pvalX = 0.5,pvalY = 0.7,pvalSize = 6)
                      p2 <- p
					  p2[[1]] <- p2[[1]] + mytheme1
					  p2[[3]] <- p2[[3]] + mytheme2
					  p <- p2[[1]]/plot_spacer()/p2[[2]]/plot_spacer()/p2[[3]] + plot_layout(heights = c(4,-0.25,1.5,-0.25,1))
                      return(p)
})


# p2[[1]]/p2[[2]]/p2[[3]] + plot_layout(heights = c(4,1.5,1))
# p2[[1]]/plot_spacer()/p2[[2]]/plot_spacer()/p2[[3]] + plot_layout(heights = c(4,-0.25,1.5,-0.25,1))

p <- gseaNb(object = egmt,
            geneSetID = gsea_results2[Pathways[c(1,2)],"ID"],
            curveCol = Color,
            subPlot = 3,
            termWidth = 35,
            legend.position = c(0.8,0.8),
            addPval = T,pHjust = 0,
            pvalX = 0.1,pvalY = 0.1,pvalSize = 6)
p2 <- p
p2[[1]] <- p2[[1]] + mytheme1
p2[[3]] <- p2[[3]] + mytheme2
p <- p2[[1]]/plot_spacer()/p2[[2]]/plot_spacer()/p2[[3]] + plot_layout(heights = c(4,-0.25,1.5,-0.25,1))
p


pdf("./TCGA-LGG-GSEA.pdf",width = 6,height = 6)
Results
p
dev.off()
