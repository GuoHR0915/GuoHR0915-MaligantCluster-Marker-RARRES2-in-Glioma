rm(list=ls())
options(stringsAsFactors = F)
setwd("D:/data/UCSC Xena TCGA+TARGET+GTEx")
library(data.table)
#匹配TPM log2(TPM+0.001)与表型数据，分别提取TCGA与GTEx数据并整理使之一一对应：
####导入TPM定量数据
TPM <- fread("./TcgaTargetGtex_rsem_gene_tpm.gz",data.table = F)
TPM[1:4,1:4]
rownames(TPM) <- TPM$sample
TPM <- TPM[,-1]
library(stringr)
colnames(TPM) %>% word(sep = '-', 1) %>% table()
# GTEX  K TARGET   TCGA
# 7792  70   734  10535
####只保留GTEX与TCGA
ind <- (colnames(TPM) %>% word(sep = '-', 1)) %in% c("GTEX","TCGA")
exprSet <- TPM[,ind]
colnames(exprSet) %>% word(sep = '-', 1) %>% table()

####导入表型数据
ph <- fread("./TcgaTargetGTEX_phenotype.txt",data.table = F)
dim(ph)#[1] 19131     7
head(ph)

colnames(ph) <- gsub("_","",colnames(ph))
colnames(ph) <- gsub(" ","",colnames(ph))
#rownames(ph) <- ph$sample
table(ph$study)####只保留GTEX与TCGA
# GTEX TARGET   TCGA 
# 7862    734  10535 
ph <- ph[ph$study %in% c("GTEX","TCGA"), ]

################挑选样本
ph1 <- ph[ph$primarydiseaseortissue %in% c("Glioblastoma Multiforme"),]
ph2 <- ph[grep("Brain",ph$primarydiseaseortissue),]
ph <- rbind(ph1,ph2)


exprSet <- exprSet[,which(colnames(exprSet) %in% ph$sample)]
ph <- ph[which(ph$sample %in% colnames(exprSet)),]        
exprSet <- exprSet[,ph$sample]
gc()
# rm(list = ls())
# options(stringsAsFactors = F)
# setwd("D:/Temp/Prognostic marker of maligant cell cluster in Glioma")
# load(file = "D:/Temp/3-Pan-cancer/data/GTEx_TCGA_Data.Rdata")
############LGG+GBM  T+N
Data_Plot <- data.frame(Expression = as.numeric(exprSet["ENSG00000106538.9",]),
                        Group = ph$sampletype,
						SubGroup = ph$primarydiseaseortissue,
						Source = "TCGA + GTEx")
Data_Plot <- Data_Plot[Data_Plot$Group %in% c("Normal Tissue","Primary Tumor"),]

table(Data_Plot$Group)
# Normal Tissue Primary Tumor 
  # 1152           662  
table(Data_Plot$SubGroup)
# Brain - Amygdala  Brain - Anterior Cingulate Cortex (Ba24)           Brain - Caudate (Basal Ganglia)             Brain - Cerebellar Hemisphere 
# 69                                        83                                       109                                        97 
# Brain - Cerebellum                    Brain - Cortex              Brain - Frontal Cortex (Ba9)                       Brain - Hippocampus 
# 119                                       105                                       102                                        84 
# Brain - Hypothalamus Brain - Nucleus Accumbens (Basal Ganglia)       Brain - Putamen (Basal Ganglia)        Brain - Spinal Cord (Cervical C-1) 
# 82                                       104                                        81                                        60 
# Brain - Substantia Nigra         Brain Lower Grade Glioma                   Glioblastoma Multiforme 
# 57                                       509                                       153 

# Data_Plot$SubGroup2 <- "Normal\nTissue"
# Data_Plot$SubGroup2[Data_Plot$SubGroup == "Glioblastoma Multiforme"] <- "Glioblastoma\nMultiforme"
# Data_Plot$SubGroup2[Data_Plot$SubGroup == "Brain Lower Grade Glioma"] <- "Lower Grade\nGlioma"
# Data_Plot$SubGroup2 <- factor(Data_Plot$SubGroup2,levels = c("Normal\nTissue",
                                                             # "Lower Grade\nGlioma",
															 # "Glioblastoma\nMultiforme"))
Data_Plot$SubGroup2 <- "Normal"
Data_Plot$SubGroup2[Data_Plot$SubGroup == "Glioblastoma Multiforme"] <- "GBM"
Data_Plot$SubGroup2[Data_Plot$SubGroup == "Brain Lower Grade Glioma"] <- "LGG"
Data_Plot$SubGroup2 <- factor(Data_Plot$SubGroup2,levels = c("Normal","LGG","GBM"))

Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Cerebellar Hemisphere",]
Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Cerebellum",]
Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Hippocampus",]
Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Hypothalamus",]
Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Spinal Cord (Cervical C-1)",]
Data_Plot <- Data_Plot[Data_Plot$SubGroup != "Brain - Substantia Nigra",]
# Data_Plot <- Data_Plot[Data_Plot$SubGroup %in% c("Brain - Anterior Cingulate Cortex (Ba24)",
                                                 # "Brain - Cortex","Brain - Frontal Cortex (Ba9)",
												 # "Glioblastoma Multiforme","Brain Lower Grade Glioma"),]

Data_Plot$Source <- "TCGA + GTEx"
library(ggsignif)
library(ggplot2)
library(ggsci)
theme <- theme_bw()+ #背景变为白色
         theme(plot.title = element_text(hjust = 0.5,size = 24), 
		       axis.text.x = element_text(hjust = 0.5,size = 24), 
		       axis.text.y = element_text(size = 24),
		       axis.title.y = element_text(size = 24), 
		       axis.line = element_line(colour = "black",size = 1), 
		       #panel.border = element_blank(),
		       strip.text = element_text(size = 24),
		       #strip.background = element_rect(fill=c("white")),
		       legend.position = "none")
p <- ggplot(Data_Plot,aes(x = SubGroup2, y = Expression,fill = SubGroup2)) + 
     geom_boxplot(width = 0.5,position = position_dodge(0.9))+
	 geom_jitter(shape = 16, position = position_jitter(0.1),size = 2)+ 
     scale_y_continuous(limits = c(-4,13), breaks = seq(-4,12,4),
	                    labels = seq(-4,12,4),expand = c(0,0))+
	 scale_fill_manual(values = rev(c("#982b2b","#db6968","#88c4e8")))+
     facet_wrap(~Source,shrink = TRUE,drop = TRUE,nrow = 1,scales = "free_x")+
	 theme + 
     #facet_wrap(~Source,shrink = TRUE,drop = TRUE,nrow = 1,scales = "free_x")+
     labs(title = NULL,x = NULL, 
	      y = bquote("Relative Expression ( "~Log[2]~" TPM )"))
p2 <- p + geom_signif(comparisons = list(c("Normal\nTissue", "Glioblastoma\nMultiforme"),
                                         c("Normal\nTissue", "Lower Grade\nGlioma")),
                      y_position = c(10.5,9),map_signif_level = T,
                      test = wilcox.test,textsize = 7.5,tip_length = 0.015)
p2

Data_Plot$Expression2 <- as.numeric(scale(Data_Plot$Expression))
p <- ggplot(Data_Plot,aes(x = SubGroup2, y = Expression2,fill = SubGroup2)) + 
     geom_boxplot(width = 0.5,position = position_dodge(0.9))+
	 geom_jitter(shape = 16, position = position_jitter(0.1),size = 2)+ 
     scale_y_continuous(limits = c(-3,4), breaks = seq(-3,3,1),
	                    labels = seq(-3,3,1),expand = c(0,0))+
	 scale_fill_manual(values = rev(c("#982b2b","#db6968","#88c4e8")))+
     facet_wrap(~Source,shrink = TRUE,drop = TRUE,nrow = 1,scales = "free_x")+
	 theme + 
     #facet_wrap(~Source,shrink = TRUE,drop = TRUE,nrow = 1,scales = "free_x")+
     labs(title = NULL,x = NULL,y = "Relative Expression (Scale)")
p2 <- p + geom_signif(comparisons = list(c("Normal", "GBM"),
                                         c("Normal", "LGG")),
                      y_position = c(3.1,2.65),map_signif_level = T,
                      test = wilcox.test,size = 1,
					  textsize = 10,tip_length = 0.015)
p2

pdf("D:/Temp/9-RARRES2 in Glioma/results/TCGA+GTEx-Glioma.pdf",
    width = 4,height = 6)
p2
dev.off()



p <- ggplot(Data_Plot,aes(x = SubGroup2, y = Expression2,fill = SubGroup2)) + 
     #geom_boxplot(width = 0.5,position = position_dodge(0.9))+
	 #boxplot上下的短横线
     stat_boxplot(geom = "errorbar",
	              position = position_dodge(width = 0.4),
	              width = 0.2) +
     #boxplot本体
     geom_boxplot(position = position_dodge(width = 0.4),
                  outlier.shape = NA) +  #离群点不单独显示
	 geom_point(aes(fill = SubGroup2),
                show.legend = F,color = "black",
                position = position_jitter(seed = 12345,
                                            width = 0.2),
                 shape = 21,size = 4)+
	 #facet_wrap(~Source,nrow = 1) +
	 scale_y_continuous(limits = c(-3,4), breaks = seq(-3,4,1),
	                    labels = seq(-3,4,1),expand = c(0,0))+
	 scale_fill_manual(values = rev(c("#982b2b","#db6968","#88c4e8"))) +
     scale_color_manual(values = rev(c("#982b2b","#db6968","#88c4e8"))) + theme +
     labs(title = "TCGA + GTEx",x = NULL,y = "Relative Expression (Scale)")
p2 <- p + geom_signif(comparisons = list(c("Normal", "GBM"),
                                         c("Normal", "LGG"),
										 c("GBM", "LGG")),
                      y_position = c(2.9,2.4,2.5),map_signif_level = T,
                      test = wilcox.test,size = 1,
					  textsize = 10,tip_length = 0.015)
p2
pdf("D:/Temp/9-RARRES2 in Glioma/results/TCGA+GTEx-Glioma.pdf",
    width = 4,height = 6)
p2
dev.off()