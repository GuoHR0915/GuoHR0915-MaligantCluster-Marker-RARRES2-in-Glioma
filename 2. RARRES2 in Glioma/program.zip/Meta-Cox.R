rm(list=ls())
options(stringsAsFactors = F)
setwd("D:/Temp/9-RARRES2 in Glioma/")
#######################################################################
################################Meta-LGG###############################
#######################################################################
MFSgroup <- read.table("./results/Cox-LGG.txt",header = T,sep = '\t')
MFSgroup$lghr <- log(MFSgroup$HR)
lglci <- log(MFSgroup$LowerCI)
lguci <- log(MFSgroup$UpperCI)
MFSgroup$selghr <- (lguci-lglci)/(2*1.96)
MFSgroup
    # DataSet       HR        se LowerCI UpperCI  P.value         lghr     selghr
# 1  TCGA-LGG 1.302340 0.0352800  1.2150   1.396 7.03e-14 0.2641626464 0.03542524
# 2 GSE107850 1.517700 0.1227000  1.1930   1.930 6.74e-04 0.4171960310 0.12271655
# 3 GSE184941 1.000298 0.0392088  0.9263   1.080 9.94e-01 0.0002982555 0.03916280

library(meta)
MFS_cox <- metagen(TE = lghr,seTE = selghr,studlab = MFSgroup$DataSet,data = MFSgroup,sm = 'HR',
                   control=list(stepadj = 0.5, maxiter = 10000))
summary(MFS_cox)
              # HR           95%-CI %W(common) %W(random)
# TCGA-LGG  1.3023 [1.2150; 1.3960]       52.6       36.6
# GSE107850 1.5177 [1.1932; 1.9304]        4.4       27.0
# GSE184941 1.0003 [0.9264; 1.0801]       43.0       36.4

# Number of studies: k = 3

                         # HR           95%-CI    z  p-value
# Common effect model  1.1704 [1.1129; 1.2308] 6.12 < 0.0001
# Random effects model 1.2330 [0.9768; 1.5565] 1.76   0.0780

# Quantifying heterogeneity (with 95%-CIs):
 # tau^2 = 0.0373 [0.0067; 1.7496]; tau = 0.1932 [0.0818; 1.3227]
 # I^2 = 93.3% [83.7%; 97.2%]; H = 3.85 [2.47; 6.00]

# Test of heterogeneity:
     # Q d.f.  p-value
 # 29.66    2 < 0.0001

# Details of meta-analysis methods:
# - Inverse variance method
# - Restricted maximum-likelihood estimator for tau^2
# - Q-Profile method for confidence interval of tau^2 and tau
# - Calculation of I^2 based on Q


#settings.meta("JAMA")
settings.meta('revman5')
forest(MFS_cox,comb.fixed = TRUE)
forest(MFS_cox,digits.pval = 4)#,comb.fixed=TRUE
pdf("./results/Meta-LGG.pdf",width = 10)
forest(MFS_cox,digits.pval = 4,weight.study = "same",just = "center")#,comb.fixed=TRUE
dev.off()


#漏斗图及Begger's及Egger's检验
funnel(MFS_cox)

# library(metafor)
# ranktest(MFS_cox)#Begg's检验#
# regtest(MFS_cox)#Egger's检验#
# #可以看出Begg's检验及Egger's 检验的结果，P值都是大于0.05的，也就意味着没有发表偏倚。
# #敏感性检验
# leavelout(MFS_cox,digits = 3)

#######################################################################
################################Meta-GBM###############################
#######################################################################
MFSgroup <- read.table("./results/Cox-GBM.txt",header = T,sep = '\t')
MFSgroup$lghr <- log(MFSgroup$HR)
lglci <- log(MFSgroup$LowerCI)
lguci <- log(MFSgroup$UpperCI)
MFSgroup$selghr <- (lguci-lglci)/(2*1.96)
MFSgroup
    # DataSet      HR      se LowerCI UpperCI  P.value       lghr     selghr
# 1  TCGA-GBM 1.06636 0.05165  0.9637   1.180 2.14e-01 0.06425098 0.05165553
# 2  GSE74187 1.15151 0.06698  1.0100   1.313 3.52e-02 0.14107412 0.06692966
# 3 GSE184941 1.19347 0.03482  1.1150   1.278 3.77e-07 0.17686503 0.03480662

library(meta)
MFS_cox <- metagen(TE = lghr,seTE = selghr,studlab = MFSgroup$DataSet,data = MFSgroup,sm = 'HR',
                   control=list(stepadj = 0.5, maxiter = 10000))
summary(MFS_cox)
            # HR       95%-CI %W(fixed) %W(random)
# TCGA-GBM  1.07 [0.96, 1.18]      26.3       31.0
# GSE74187  1.15 [1.01, 1.31]      15.7       21.7
# GSE184941 1.19 [1.11, 1.28]      58.0       47.3

# Number of studies: k = 3

                       # HR       95%-CI    z  p-value
# Fixed effect model   1.15 [1.09, 1.21] 5.34 < 0.0001
# Random effects model 1.14 [1.07, 1.23] 3.70   0.0002

# Quantifying heterogeneity (with 95%-CIs):
 # tau^2 = 0.002 [0.000, 0.144]; tau = 0.0396 [0.0000, 0.3793]
 # I^2 = 39% [0%, 81%]; H = 1.28 [1.00, 2.29]

# Test of heterogeneity:
    # Q d.f. p-value
 # 3.27    2  0.1951

# Details of meta-analysis methods:
# - Inverse variance method
# - DerSimonian-Laird estimator for tau^2
# - Jackson method for confidence interval of tau^2 and tau
# - Calculation of I^2 based on Q



#settings.meta("JAMA")
settings.meta('revman5')
forest(MFS_cox,comb.fixed = TRUE)
forest(MFS_cox,digits.pval = 4)#,comb.fixed=TRUE
pdf("./results/Meta-GBM.pdf",width = 10)
forest(MFS_cox,digits.pval = 4,weight.study = "same",just = "center")#,comb.fixed=TRUE
dev.off()


#漏斗图及Begger's及Egger's检验
funnel(MFS_cox)

# library(metafor)
# ranktest(MFS_cox)#Begg's检验#
# regtest(MFS_cox)#Egger's检验#
# #可以看出Begg's检验及Egger's 检验的结果，P值都是大于0.05的，也就意味着没有发表偏倚。
# #敏感性检验
# leavelout(MFS_cox,digits = 3)


#######################################################################
###################################Meta-Plot###########################
#######################################################################
rm(list = ls())
options(stringsAsFactors = F)
setwd("D:/Temp/9-RARRES2 in Glioma/")
library(readxl) 
forest <- read_excel("./results/Meta-Cox.xlsx",sheet = 2)
forest

forest2 <- data.frame(Cancer = forest$Dataset,
                     N = forest$N,
					 HR = forest$HR,
                     HR2 = forest$`HR (95%Cl)`,
                     P_value = forest$Pvalue,
					 HR_95L = forest$LowerCI,
					 HR_95H = forest$UpperCI,
					 Group = forest$Group)
range(forest2$HR_95H)
#[1]1.08 1.93
range(forest2$HR_95L)
#[1]0.9263 1.2150
forest2$P_value <- ifelse(as.numeric(forest2$P_value) < 0.001,"<0.001",forest2$P_value)
forest2$Cancer <- factor(forest2$Cancer,levels = rev(forest2$Cancer))
forest2$Group <- factor(forest2$Group,levels = rev(unique(forest2$Group)))

library(ggplot2)
p1 <-  ggplot(forest2,aes(x = HR, y = Cancer))+
	   geom_errorbar(aes(xmin = HR_95L , xmax = HR_95H), 
                     position = position_dodge(0.8), 
					 width = 0.4, size = 1,
					 color = "black") +
	   geom_point(aes(color = Group,fill = Group),
	              shape = 22,size = 10) +
	   scale_x_continuous(expand = c(0,0),limits = c(0.5,2),
	                      breaks = c(0.5,1,2),
	                      labels = c(0.5,1,2)) +
	   geom_vline(aes(xintercept = 1), linetype = 'dashed', color = 'black', size = 2)+
	   coord_trans(x = "log2") +
	   scale_color_manual(values = c("#ff6666","#ffc857","#119da4"))+
	   scale_fill_manual(values = c("#ff6666","#ffc857","#119da4"))+
	   labs(title = "RARRES2 Cox Analysis (PFI)", x = "Hazard Ratio (HR)",x = NULL) +
	   theme_bw() +
	   theme(plot.title = element_text(size = 26,hjust = 0.5,face = "bold"),
			 axis.text.x = element_text(size = 24), 
             axis.text.y = element_text(size = 24), 
			 axis.title.x = element_text(size = 26), 
			 axis.title.y = element_blank(), 
			 axis.ticks.y = element_blank(),
			 axis.ticks.length.x = unit(0.4,"lines"), 
			 axis.line = element_line(size = 1),
			 #axis.line.y = element_line(size = 1),
			 #panel.border = element_blank(),
			 legend.title = element_blank(), 
			 legend.text = element_text(size = 24), 
			 legend.position = "bottom",
			 legend.background = element_rect(fill = 'transparent'))
p2 <- p1 
p2 <- p2 + 
      annotate('rect', xmin = -Inf, xmax = Inf, ymin = 5-0.5, ymax = 8+0.5, 
               fill = '#f3ecec', alpha = .5) +
	  annotate('rect', xmin = -Inf, xmax = Inf, ymin = 1-0.5, ymax = 4+0.5, 
               fill = '#dfe2e2', alpha = .5)			   
p2

library(dplyr)
Sig <- case_when(as.numeric(forest$Pvalue) < 0.001~"****",
                 as.numeric(forest$Pvalue) < 0.001~"***",
                 as.numeric(forest$Pvalue) < 0.01~"**",
                 as.numeric(forest$Pvalue) < 0.05~"*",
                 T~ "")


p3 <- p2
for (i in 1:nrow(forest)){ 
    p3 <- p3 + annotate("text",x = 0.65,y = i,
	                    label = Sig[nrow(forest)-i+1],
						size = 12,hjust = 0.5)
}
p3


library(ggplot2)
p1 <-  ggplot(forest2,aes(x = HR, y = Cancer))+
	   geom_errorbar(aes(xmin = HR_95L , xmax = HR_95H), 
                     position = position_dodge(0.8), 
					 width = 0.4, size = 1,
					 color = "black") +
	   geom_point(aes(color = Group,fill = Group),
	              shape = 22,size = 10) +
	   scale_x_continuous(expand = c(0,0),limits = c(0.85,2.1),
	                      breaks = c(0.9,1,1.4,1.8),
	                      labels = c(0.9,1,1.4,1.8)) +
	   geom_vline(aes(xintercept = 1), linetype = 'dashed', color = 'black', size = 2)+
	   #coord_trans(x = "log2") +
	   scale_color_manual(values = c("#ff6666","#ffc857","#119da4"))+
	   scale_fill_manual(values = c("#ff6666","#ffc857","#119da4"))+
	   labs(title = "RARRES2 Cox Analysis (PFI)", x = "Hazard Ratio (HR)",x = NULL) +
	   theme_bw() +
	   theme(plot.title = element_text(size = 26,hjust = 0.5,face = "bold"),
			 axis.text.x = element_text(size = 24), 
             axis.text.y = element_text(size = 24), 
			 axis.title.x = element_text(size = 26), 
			 axis.title.y = element_blank(), 
			 axis.ticks.y = element_blank(),
			 axis.ticks.length.x = unit(0.4,"lines"), 
			 axis.line = element_line(size = 1),
			 #axis.line.y = element_line(size = 1),
			 #panel.border = element_blank(),
			 legend.title = element_blank(), 
			 legend.text = element_text(size = 24), 
			 legend.position = "bottom",
			 legend.background = element_rect(fill = 'transparent'))
p2 <- p1 
p2 <- p2 + 
      annotate('rect', xmin = -Inf, xmax = Inf, ymin = 5-0.5, ymax = 8+0.5, 
               fill = '#f3ecec', alpha = .5) +
	  annotate('rect', xmin = -Inf, xmax = Inf, ymin = 1-0.5, ymax = 4+0.5, 
               fill = '#dfe2e2', alpha = .5)			   
p2

library(dplyr)
Sig <- case_when(as.numeric(forest$Pvalue) < 0.001~"****",
                 as.numeric(forest$Pvalue) < 0.001~"***",
                 as.numeric(forest$Pvalue) < 0.01~"**",
                 as.numeric(forest$Pvalue) < 0.05~"*",
                 T~ "")


p4 <- p2
for (i in 1:nrow(forest)){ 
    p4 <- p4 + annotate("text",x = 1.95,y = i,
	                    label = Sig[nrow(forest)-i+1],
						size = 12,hjust = 0.5)
}
p4


pdf("./Meta-Cox-All.pdf",width = 10.5,height = 6)
p3
p4
dev.off()

