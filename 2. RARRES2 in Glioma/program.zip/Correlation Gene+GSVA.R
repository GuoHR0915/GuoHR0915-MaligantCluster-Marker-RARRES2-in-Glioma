rm(list = ls())
options(stringsAsFactors = FALSE)
Gene <- "RARRES2"
setwd("D:/data/TCGA") 
########################################################################
###############################TCGA-GBM#################################
########################################################################
load('./TCGAbiolinks-GSVA/GOBP-TCGA-GBM.Rdata')
load('./TCGAbiolinks-EXP/TCGA-GBM-GeneSymbol.Rdata')
Pathway <- rownames(GOBP_ES)[grep("FATTY_ACID",rownames(GOBP_ES))]

exprSet <- data.frame(t(GOBP_ES[Pathway,]),
                      Expression = as.numeric(exp_TPM[Gene,]),
	                  SampleType = substr(sapply(strsplit(colnames(GOBP_ES),'-'),"[",4),1,2),
                      SampleType2 = substr(sapply(strsplit(colnames(GOBP_ES),'-'),"[",4),3,3),
                      Cancer = "TCGA-GBM")
print(table(exprSet$SampleType,exprSet$SampleType2))
exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09") & exprSet$SampleType2 == "A",]
print(table(exprSet$SampleType,exprSet$SampleType2))
	
#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(Pathway,function(x){
	GeneA <- as.numeric(exprSet[,x])
    GeneB <- as.numeric(exprSet[,"Expression"])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "spearman")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- Pathway
head(Correlation)
Correlation[Pathway[grep("BIOSYNTHETIC",Pathway)],]
TCGAGBM <- Correlation

library(ggplot2)
mytheme <- theme(axis.text.x = element_text(hjust = 0.5,size = 20), 
                 axis.ticks.y = element_blank(), ## 删去y轴刻度线
                 axis.text.y = element_text(size = 20), 
                 axis.title.x = element_text(size = 20), 
                 axis.title.y = element_text(size = 20), 
                 axis.line = element_line(size = 1),
                 plot.margin = unit(c(1,1,1,1), "cm"),#画布边缘距离上(top)、右(right)、下(bottom)、左(left) 
                 plot.title = element_text(hjust = 0.5,size =  22),
                 legend.title = element_text(size = 22), 
                 legend.text = element_text(size = 22), 
                 legend.position = "right",
                 legend.background = element_rect(fill = 'transparent'))
p1 <- ggplot(data = exprSet, aes(x = log2(Expression+1), y = GOBP_LONG_CHAIN_FATTY_ACID_BIOSYNTHETIC_PROCESS)) +
      geom_point(color = "#0074b3",size = 2) +
	  labs(x = "RARRES2 Relative Expression",
	       y = "Long Chain Fatty Acid \nBiosynthetic Score",
		   title = "TCGA-GBM")+
      theme_bw() + mytheme

library(ggpubr)
pGBM <- p1 + 
        stat_cor(aes(label = paste(..r.label.., ..p.label.., sep = '~`,`~')), 
                  method = 'pearson', 
                  label.x.npc = 'left', label.y.npc = 'top', size = 8) 
pGBM				  
				  
				  
########################################################################
###############################TCGA-LGG#################################
########################################################################
load('./TCGAbiolinks-GSVA/GOBP-TCGA-LGG.Rdata')
load('./TCGAbiolinks-EXP/TCGA-LGG-GeneSymbol.Rdata')
Pathway <- rownames(GOBP_ES)[grep("FATTY_ACID",rownames(GOBP_ES))]

exprSet <- data.frame(t(GOBP_ES[Pathway,]),
                      Expression = as.numeric(exp_TPM[Gene,]),
	                  SampleType = substr(sapply(strsplit(colnames(GOBP_ES),'-'),"[",4),1,2),
                      SampleType2 = substr(sapply(strsplit(colnames(GOBP_ES),'-'),"[",4),3,3),
                      Cancer = "TCGA-LGG")
print(table(exprSet$SampleType,exprSet$SampleType2))
exprSet <- exprSet[exprSet$SampleType %in% c("01","03","09") & exprSet$SampleType2 == "A",]
print(table(exprSet$SampleType,exprSet$SampleType2))
	
#####################
###########计算相关性
#####################
library(Hmisc)
Correlation <- lapply(Pathway,function(x){
	GeneA <- as.numeric(exprSet[,x])
    GeneB <- as.numeric(exprSet[,"Expression"])
	Correlation <- rcorr(x = GeneA,y = GeneB,type = "spearman")
    return(c(Correlation$r["y","x"],Correlation$P["y","x"]))
})
Correlation <- data.frame(do.call(rbind,Correlation))
colnames(Correlation) <- c("R","Pvalue")
rownames(Correlation) <- Pathway
head(Correlation)
Correlation[Correlation$Pvalue < 0.05,]
TCGALGG <- Correlation


library(ggplot2)
mytheme <- theme(axis.text.x = element_text(hjust = 0.5,size = 20), 
                 axis.ticks.y = element_blank(), ## 删去y轴刻度线
                 axis.text.y = element_text(size = 20), 
                 axis.title.x = element_text(size = 20), 
                 axis.title.y = element_text(size = 20), 
                 axis.line = element_line(size = 1),
                 plot.margin = unit(c(1,1,1,1), "cm"),#画布边缘距离上(top)、右(right)、下(bottom)、左(left) 
                 plot.title = element_text(hjust = 0.5,size =  22),
                 legend.title = element_text(size = 22), 
                 legend.text = element_text(size = 22), 
                 legend.position = "right",
                 legend.background = element_rect(fill = 'transparent'))
p1 <- ggplot(data = exprSet, aes(x = log2(Expression+1), y = GOBP_LONG_CHAIN_FATTY_ACID_BIOSYNTHETIC_PROCESS)) +
      geom_point(color = "#0074b3",size = 2) +
	  labs(x = "RARRES2 Relative Expression",
	       y = "Long Chain Fatty Acid \nBiosynthetic Score",
		   title = "TCGA-LGG")+
      theme_bw() + mytheme

library(ggpubr)
pLGG <- p1 + 
        stat_cor(aes(label = paste(..r.label.., ..p.label.., sep = '~`,`~')), 
                  method = 'pearson', 
                  label.x.npc = 'left', label.y.npc = 'top', size = 8) 
pLGG				  

pdf()